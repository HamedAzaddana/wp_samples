<?php // Silence is golden.

