<?php

namespace LmskaranMoopress\Controllers;

use WPMVC\MVC\Controller;
use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;
use LmskaranMoopress\Controllers\Webservice\MoodleController;
use Peast\Formatter\Base;
use WPMVC\Request;

class AuthController extends Controller
{
    private $password_account = '';
    private $update_admin = false;
    private $regex_passwd =  "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d#^$@!%&*?]{5,200}$/";
    public function add_reg_wooc_fields()
    {
        woocommerce_form_field(
            'billing_first_name',
            array(
                'type'        => 'text',
                'required'    => true, // just adds an "*"
                'label'       => 'نام'
            ),
            (isset($_POST['billing_first_name']) ? $_POST['billing_first_name'] : '')
        );
        woocommerce_form_field(
            'billing_last_name',
            array(
                'type'        => 'text',
                'required'    => true, // just adds an "*"
                'label'       => 'نام خانوادگی'
            ),
            (isset($_POST['billing_last_name']) ? $_POST['billing_last_name'] : '')
        );
    }
    public function validate_register($username, $email, $errors)
    {
        if (empty($_POST['billing_first_name'])) {
            $errors->add('billing_first_name_error', 'نام نمی تواند خالی باشد !');
        }
        if (empty($_POST['billing_last_name'])) {
            $errors->add('billing_last_name_error', 'نام خانوادگی نمی تواند خالی باشد !');
        }
        //validate password
        //length 5 character, at least one of each these: 1 digit,1 lowercase,1 uppercase
        $regex_passwd = $this->regex_passwd;
        if ($_POST['password']) {
            if (!preg_match($regex_passwd, $_POST['password'])) {
                $msg_error = 'رمز عبور باید دارای شرایط زیر باشد : <br> ';
                $msg_error .= '* حداقل 5 کاراکتر <br>';
                $msg_error .= '* حداکثر 200 کاراکتر <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف کوچک <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف بزرگ <br>';
                $msg_error .= '* حداقل یک کاراکتر عددی <br>';
                $errors->add('password_error', $msg_error);
            }
        }
        $this->password_account = $_POST['password'];
    }
    public function validate_user_reg_admin(&$validation_errors, $update, $user)
    {
        if (empty($_POST['first_name'])) {
            $validation_errors->add('first_name', '<strong>خطا :</strong>' . 'نام نمی تواند خالی باشد !');
        }
        if (empty($_POST['last_name'])) {
            $validation_errors->add('last_name', '<strong>خطا :</strong>' . 'نام خانوادگی نمی تواند خالی باشد !');
        }
        if (empty($_POST['pass1']) && !$update) {
            $validation_errors->add('pass1', '<strong>خطا :</strong>' . 'رمز عبور نمی تواند خالی باشد ! !');
        }
        //validate password
        //length 5 character, at least one of each these: 1 digit,1 lowercase,1 uppercase
        $regex_passwd = $this->regex_passwd;
        if ($_POST['pass1']) {
            if (!preg_match($regex_passwd, $_POST['pass1'])) {
                $msg_error = 'رمز عبور باید دارای شرایط زیر باشد : <br> ';
                $msg_error .= '* حداقل 5 کاراکتر <br>';
                $msg_error .= '* حداکثر 200 کاراکتر <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف کوچک <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف بزرگ <br>';
                $msg_error .= '* حداقل یک کاراکتر عددی <br>';
                $validation_errors->add('pass1', '<strong>خطا :</strong>' . $msg_error);
            }
        }
        $this->password_account = $_POST['pass1'];
        $this->update_admin = $update;
    }
    public function validate_update_account($validation_errors, $user)
    {
        $user_obj = wp_get_current_user();
        $user_id = intval($user_obj->data->ID);
        $password_1 = @$_POST['password_1'];
        $this->password_account = $password_1;

        //validate password
        //length 5 character, at least one of each these: 1 digit,1 lowercase,1 uppercase
        $regex_passwd = $this->regex_passwd;
        if ($password_1) {
            if (!preg_match($regex_passwd, $password_1)) {
                $msg_error = 'رمز عبور باید دارای شرایط زیر باشد : <br> ';
                $msg_error .= '* حداقل 5 کاراکتر <br>';
                $msg_error .= '* حداکثر 200 کاراکتر <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف کوچک <br>';
                $msg_error .= '* حداقل یک کاراکتر انگلیسی با حروف بزرگ <br>';
                $msg_error .= '* حداقل یک کاراکتر عددی <br>';
                $validation_errors->add('password_1_error', $msg_error);
            }
        }
    }
    public function register_user_info($customer_id)
    {

        $password = $this->password_account;
        if (isset($_POST['billing_first_name'])) {
            update_user_meta($customer_id, 'billing_first_name', wc_clean($_POST['billing_first_name']));
            update_user_meta($customer_id, 'first_name', wc_clean($_POST['billing_first_name']));
        }
        if (isset($_POST['billing_last_name'])) {
            update_user_meta($customer_id, 'billing_last_name', wc_clean($_POST['billing_last_name']));
            update_user_meta($customer_id, 'last_name', wc_clean($_POST['billing_last_name']));
        }
        update_user_meta($customer_id, md5('pwdsaltmdl'), $password);


        //update userdata info !
        $m_lastname = get_user_meta($customer_id, 'last_name', true);
        $m_firstname = get_user_meta($customer_id, 'first_name', true);
        $passwd_raw =  get_user_meta($customer_id, md5('pwdsaltmdl'), true);
        $user_id_mdl = intval(get_user_meta($customer_id, "user_id_mdl", true));
        $user_registered = get_user_by('id', $customer_id);
        $email_registered = $user_registered->data->user_email;
        $username_registered = $user_registered->data->user_login;
        $fullname_registered = $m_firstname . " " . $m_lastname;
        // global $wpdb;
        // $wpdb->update(
        //     $wpdb->users,
        //     ['user_login' => $email_registered],
        //     ['display_name' => $fullname_registered],
        //     ['ID' => $customer_id]
        // );

        $errors_moodle = [];
        //check user info validations for moodle
        if (!$m_lastname || !$m_firstname) {
            $errors_moodle[] = "<p>نام یا نام خانوادگی خود را وارد نکرده اید !</p>";
        }
        $regex_passwd = $this->regex_passwd;
        if (!$passwd_raw) {
            $errors_moodle[] = "<p>پسورد خود را وارد در حساب کاربری خود تغییر دهید !</p>";
        }
        if ($passwd_raw && !preg_match($regex_passwd, $passwd_raw)) {
            $errors_moodle[] = "<p>پسورد خود را وارد در حساب کاربری خود تغییر دهید !</p>";
        }
        $users_moodle_by_email = MoodleController::get_users_by_field('email', [$email_registered]);


        if ($users_moodle_by_email) {
            $email_in_moodle = @$users_moodle_by_email[0]->email;
            if (($email_in_moodle == $email_registered) && !$user_id_mdl) {
                $errors_moodle[] = "<p>کاربری با ایمیل شما قبلا در سامانه مدیریت یادگیری ثبت نام کرده است. لطفا ایمیل خود را تغییر دهید !</p>";
            }
        }
        if ($errors_moodle) {
            $errors_moodle = base64_encode(serialize($errors_moodle));
            $error_url = get_site_url() . "/my-account/edit-account/?error_occurred=error_moodle&errors=" . $errors_moodle;
            header("Location: $error_url");
            die();
        }

        //register user in moodle
        $umid = MoodleController::register_user($customer_id);
        if (!$umid) {
            $errors_webservice = [
                'خطایی در وبسرویس سامانه مدیریت یادگیری رخ داد !اطلاعات خود را مجدد ویرایش کنید !'
            ];
            $errors_webservice = base64_encode(serialize($errors_webservice));
            $error_url = get_site_url() . "/my-account/edit-account/?error_occurred=error_moodle&errors=" . $errors_webservice;
            header("Location: $error_url");
            die();
        }
        BaseHelper::moopress_auth_singon_wp($customer_id);
        $user = get_user_by('id', $customer_id);
        $return_back_url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $sso_link = BaseHelper::mw_wp2moodle_generate_hyperlink('', '', '', 0, '', 0, $user);
        $sso_link_encode = base64_encode($sso_link);
        $return_back_url_encode = base64_encode($return_back_url);
        $wp_js_code = get_site_url() . "/?moopress_wp2m_login=" . $sso_link_encode . "&return_to=" . $return_back_url_encode;
        header("Location: {$wp_js_code}");
        die();
    }

    public function user_register_admin($customer_id)
    {

        $valid_data = true;
        $password = $this->password_account;
        if (empty($_POST['first_name'])) {
            $valid_data = false;
        }
        if (empty($_POST['last_name'])) {
            $valid_data = false;
        }
        if (empty($_POST['pass1']) && !$this->update_admin) {
            $valid_data = false;
        }
        //validate password
        //length 5 character, at least one of each these: 1 digit,1 lowercase,1 uppercase
        $regex_passwd = $this->regex_passwd;
        if ($_POST['pass1']) {
            if (!preg_match($regex_passwd, $_POST['pass1'])) {
                $valid_data = false;
            }
        }
        if ($valid_data) {
            update_user_meta($customer_id, 'billing_first_name', wc_clean($_POST['first_name']));
            update_user_meta($customer_id, 'first_name', wc_clean($_POST['first_name']));
            update_user_meta($customer_id, 'billing_last_name', wc_clean($_POST['last_name']));
            update_user_meta($customer_id, 'last_name', wc_clean($_POST['last_name']));
            if ($_POST['pass1']) {
                update_user_meta($customer_id, md5('pwdsaltmdl'), $password);
            }

            $m_lastname = get_user_meta($customer_id, 'last_name', true);
            $m_firstname = get_user_meta($customer_id, 'first_name', true);
            $user_registered = get_user_by('id', $customer_id);
            $email_registered = $user_registered->data->user_email;
            $username_registered = $user_registered->data->user_login;
            $fullname_registered = $m_firstname . " " . $m_lastname;

            // global $wpdb;
            // $wpdb->update(
            //     $wpdb->users,
            //     ['user_login' => $email_registered],
            //     ['display_name' => $fullname_registered],
            //     ['ID' => $customer_id]
            // );
            $umid = MoodleController::update_user($customer_id);
        }
    }
    public function update_account_info($customer_id)
    {
        $password = $this->password_account;
        if ($password) {
            update_user_meta($customer_id, md5('pwdsaltmdl'), $password);
        }

        //update user in moodle
        $umid = MoodleController::update_user($customer_id);
    }
    public function update_register_admin($customer_id)
    {
        $valid_data = true;

        if (empty($_POST['first_name'])) {
            $valid_data = false;
        }
        if (empty($_POST['last_name'])) {
            $valid_data = false;
        }

        //validate password
        //length 5 character, at least one of each these: 1 digit,1 lowercase,1 uppercase
        $regex_passwd = $this->regex_passwd;
        if ($_POST['pass1']) {
            if (!preg_match($regex_passwd, $_POST['pass1'])) {
                $valid_data = false;
            }
        }
    }
    public function after_update_register_admin($customer_id, $old_user_data)
    {
        $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

        if (strpos($current_url, 'my-account/edit-account') !== false) {
            update_user_meta($customer_id, 'billing_first_name', wc_clean($_POST['account_first_name']));
            update_user_meta($customer_id, 'first_name', wc_clean($_POST['account_first_name']));
            update_user_meta($customer_id, 'billing_last_name', wc_clean($_POST['account_last_name']));
            update_user_meta($customer_id, 'last_name', wc_clean($_POST['account_last_name']));
            if (@$_POST['password_1']) {
                update_user_meta($customer_id, md5('pwdsaltmdl'), $_POST['password_1']);
            }
            $umid = MoodleController::update_user($customer_id);
            // BaseHelper::dd($umid);
            // die;

            $current_user_id_mdl = intval(get_user_meta($customer_id, "user_id_mdl", true));
            if (!$current_user_id_mdl) {
                $errors_webservice = [
                    'خطایی در وبسرویس سامانه مدیریت یادگیری رخ داد !اطلاعات خود را مجدد ویرایش کنید !'
                ];
                $errors_webservice = base64_encode(serialize($errors_webservice));
                $error_url = get_site_url() . "/my-account/edit-account/?error_occurred=error_moodle&errors=" . $errors_webservice;
                header("Location: $error_url");
                die();
            }
        }
        if (strpos($current_url, 'wp-admin/profile.php') !== false || strpos($current_url, 'wp-admin/user-edit.php') !== false) {

            update_user_meta($customer_id, 'billing_first_name', wc_clean($_POST['first_name']));
            update_user_meta($customer_id, 'first_name', wc_clean($_POST['first_name']));
            update_user_meta($customer_id, 'billing_last_name', wc_clean($_POST['last_name']));
            update_user_meta($customer_id, 'last_name', wc_clean($_POST['last_name']));
            if (@$_POST['pass1']) {
                update_user_meta($customer_id, md5('pwdsaltmdl'), $_POST['pass1']);
            }
            $umid = MoodleController::update_user($customer_id);
        }
    }
    public function alert_reg_moodle()
    {
    }
    public function after_password_reset($user, $new_pass)
    {
        $user_id = intval($user->data->ID);
        if ($new_pass && $user_id) {
            update_user_meta($user_id, md5('pwdsaltmdl'), $new_pass);
            $this->password_account = $new_pass;
            //update password in moodle
            $umid = MoodleController::reset_passwd_user($user_id);
        }
    }
    public function add_to_cart_validation($passed, $product_id, $quantity)
    {
        $passed = true;
        $course_id_mdl = intval(get_post_meta((int)$product_id, 'course_id_mdl', true));
        if ($course_id_mdl) {
            $user = wp_get_current_user();
            $user_id = intval($user->data->ID);
            $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));
            $edit_account_wooc_link = get_site_url() . "/my-account/edit-account/";
            $return_back_url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            if (!is_user_logged_in()) {
                $_error_phrase = "برای افزودن به سبد، باید ابتدا وارد حساب خود شوید.<br>";
                $_error_phrase .= "<a style='font-weight: bold;color: green;font-size: 22px;' target='_blank' href='$edit_account_wooc_link'>حساب کاربری</a>";
                wc_add_notice(__($_error_phrase, 'woocommerce'), 'error');
                $return_back_url .= "?moopress_error_cart=" . base64_encode($_error_phrase);
                header("Location: $return_back_url");
                die();
                $passed = false;
            }

            if (is_user_logged_in() && !$user_id_mdl) {
                $_error_phrase = "حساب کاربری شما در سامانه مدیریت یادگیری ایجاد نشده است. وارد لینک زیر شوید و اطلاعات خود را ویرایش کنید. <br>";
                $_error_phrase .= "<a style='font-weight: bold;color: green;font-size: 22px;' target='_blank' href='$edit_account_wooc_link'>حساب کاربری</a>";
                wc_add_notice(__($_error_phrase, 'woocommerce'), 'error');
                $return_back_url .= "?moopress_error_cart=" . base64_encode($_error_phrase);
                header("Location: $return_back_url");
                die();
                $passed = false;
            }
            $user = wp_get_current_user();
            $user_id = intval($user->data->ID);
            $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));
            if (EnrollHelper::is_user_enrolled_in($user_id_mdl, $course_id_mdl)) {
                wc_add_notice(__('در این دوره قبلا ثبت نام شده اید !', 'woocommerce'), 'error');
            }
        }
        return $passed;
    }
    public function add_edit_moodle_link_column($column)
    {
        $column['edit_moodle_link'] = 'ویرایش کاربر در سامانه مدیریت یادگیری';
        return $column;
    }
    public function add_edit_moodle_link_column_row($val, $column_name, $user_id)
    {
        $opt = get_option("moopress_api_info", '');
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }
        if ($column_name == "edit_moodle_link") {
            $user_id_mdl = (int)get_user_meta($user_id, 'user_id_mdl', true);
            if ($user_id_mdl) {
                $user_link =  $moodle_url . "user/editadvanced.php?id=$user_id_mdl";
                return "<a target='_blank' href='$user_link'>مشاهده</a>";
            } else {
                return "کاربر در سامانه مدیریت یادگیری ثبت نشده است !";
            }
        }
        return $val;
    }
    public function change_wooc_password_policy()
    {
        return 0;
    }
    public function remove_password_policy()
    {
        wp_dequeue_script('wc-password-strength-meter');
    }

    public function sso_auth_after_login($user_login, $user)
    {
        $password_raw = @$_POST['password'];
        $userid_login_wp = (int)$user->ID;
        if ($password_raw) {
            update_user_meta($userid_login_wp, md5('pwdsaltmdl'), $password_raw);
        }
        $customer_id = $userid_login_wp;
        //update userdata info !
        $m_lastname = get_user_meta($customer_id, 'last_name', true);
        $m_firstname = get_user_meta($customer_id, 'first_name', true);
        $passwd_raw = get_user_meta($customer_id, md5('pwdsaltmdl'), true);
        $user_id_mdl = intval(get_user_meta($customer_id, "user_id_mdl", true));
        $user_registered = get_user_by('id', $customer_id);
        $email_registered = $user_registered->data->user_email;
        $username_registered = $user_registered->data->user_login;


        $errors_moodle = [];
        //check user info validations for moodle
        if (!$m_lastname || !$m_firstname) {
            $errors_moodle[] = "<p>نام یا نام خانوادگی خود را وارد نکرده اید !</p>";
        }
        $regex_passwd = $this->regex_passwd;
        if (!$passwd_raw) {
            $errors_moodle[] = "<p>پسورد خود را وارد در حساب کاربری خود تغییر دهید !</p>";
        }
        if ($passwd_raw && !preg_match($regex_passwd, $passwd_raw)) {
            $errors_moodle[] = "<p>پسورد خود را وارد در حساب کاربری خود تغییر دهید !</p>";
        }
        $users_moodle_by_email = MoodleController::get_users_by_field('email', [$email_registered]);

        if ($users_moodle_by_email) {
            $email_in_moodle = @$users_moodle_by_email[0]->email;
            if (($email_in_moodle == $email_registered) && !$user_id_mdl) {
                $errors_moodle[] = "<p>کاربری با ایمیل شما قبلا در سامانه مدیریت یادگیری ثبت نام کرده است. لطفا ایمیل خود را تغییر دهید !</p>";
            }
        }

        if ($errors_moodle) {
            $errors_moodle = base64_encode(serialize($errors_moodle));
            $error_url = get_site_url() . "/my-account/edit-account/?error_occurred=error_moodle&errors=" . $errors_moodle;
            header("Location: $error_url");
            die();
        }

        $umid = MoodleController::update_user($userid_login_wp);

        $current_user_id_mdl = intval(get_user_meta($userid_login_wp, "user_id_mdl", true));
        if (!$current_user_id_mdl) {
            $errors_webservice = [
                'خطایی در وبسرویس سامانه مدیریت یادگیری رخ داد !اطلاعات خود را مجدد ویرایش کنید !'
            ];
            $errors_webservice = base64_encode(serialize($errors_webservice));
            $error_url = get_site_url() . "/my-account/edit-account/?error_occurred=error_moodle&errors=" . $errors_webservice;
            header("Location: $error_url");
            die();
        }

        $return_back_url = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

        $sso_link = BaseHelper::mw_wp2moodle_generate_hyperlink('', '', '', 0, '', 0, $user);
        $sso_link_encode = base64_encode($sso_link);
        $return_back_url_encode = base64_encode($return_back_url);
//        $wp_js_code = get_site_url() . "?moopress_wp2m_login=" . $sso_link_encode . "&return_to=" . $return_back_url_encode;


        if (strpos($_SERVER['REQUEST_URI'], 'wp-login.php'))
        {
            $wp_js_code = admin_url() . "?moopress_wp2m_login=" . $sso_link_encode;
        }
        else
        {
            $wp_js_code = site_url($_SERVER['REQUEST_URI']) . "?moopress_wp2m_login=" . $sso_link_encode;
        }


        wp_redirect($wp_js_code);
        exit;
//        header("Location: {$wp_js_code}");
//        die();
    }
    public function redirect_2dir_login_mdl()
    {
        $login_url_admin = esc_url(wp_login_url());
        $home_front_url = get_site_url();
        $admin_back_url = get_admin_url();
        $requests = Request::all();
        $userid = get_current_user_id();
        $moopress_wp2m_login = @$requests['moopress_wp2m_login'];
        $return_to = @$requests['return_to'];
        if ($moopress_wp2m_login && $userid) {
            $moopress_wp2m_login_dec = base64_decode($moopress_wp2m_login);
            $return_to_dec = base64_decode($return_to);
            if (strpos($return_to_dec, $login_url_admin) !== false) {
                if (current_user_can('manage_options')) {
                    $return_to_dec = $admin_back_url;
                } else {
                    $return_to_dec = $home_front_url;
                }
            }
            $view_html = $this->view->get('redirect_2dir_login_mdl', [
                'moopress_wp2m_login_dec' => $moopress_wp2m_login_dec,
                'return_to_dec' => $return_to_dec,
            ]);
            echo  $view_html;
        }
    }
    public function delete_user_wp($UserID)
    {
        $user_id_mdl = intval(get_user_meta((int)$$UserID, "user_id_mdl", true));
        MoodleController::delete_user($user_id_mdl);
    }
    
}
