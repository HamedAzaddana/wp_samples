<?php

namespace LmskaranMoopress\Controllers\Helpers;

class Course
{

  public static function getCourseBytitle($title)
  {
    $posts = get_posts([
      'post_type'  => 'product',
      'title' => $title,
    ]);
    return $posts;
  }
  public static function getCourseByMdlId($mdl_id)
  {

    $posts = get_posts(array(
      'numberposts'   => -1,
      'post_type'     => 'product',
      'meta_key'      => 'course_id_mdl',
      'meta_value'    => "$mdl_id"
    ));
    return $posts;
  }
}
