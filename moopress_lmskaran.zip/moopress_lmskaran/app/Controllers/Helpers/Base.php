<?php

namespace LmskaranMoopress\Controllers\Helpers;

class Base
{

  public static function curl_request($url, $method, $data, $headers)
  {

    $fields_string = http_build_query($data);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    $response_object = json_decode(preg_replace('/\s+/', ' ', $response));
    return [
      'object' => $response_object,
      'status_code' => $status_code,
      'error' => $error,
    ];
  }
  public static function make_en_str($str)
  {
    $replace_pairs = array(
      '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
      '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9'
    );
    return strtr($str, $replace_pairs);
  }
  public static function dd($data)
  {

    echo "********<br><pre style='direction:ltr;'>";
    echo var_dump($data);
    echo "</pre><br>********";
  }
  public static function rdd($data)
  {
    echo var_dump($data);
    exit;
  }
  public static function random_hash($l = 10)
  {
    return mt_rand(1000, 999999) . bin2hex(random_bytes($l)) . time();
  }
  public static function random_hash_file($l = 4)
  {
    return bin2hex(random_bytes($l)) . "-" . bin2hex(random_bytes($l)) . "-" . bin2hex(random_bytes($l)) . "-" . bin2hex(random_bytes($l)) . "-" . time();
  }
  public static function get_request_headers()
  {
    $headers = array();
    foreach ($_SERVER as $key => $value) {
      if (substr($key, 0, 5) <> 'HTTP_') {
        continue;
      }
      $header = str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))));
      $headers[$header] = $value;
    }
    return $headers;
  }
  public static function upload_file_by_url($image_url)
  {

    //get last file attachment id by source url

    $posts = get_posts(array(
      'numberposts'   => -1,
      'post_type'     => 'attachment',
      'meta_key'      => 'main_file_url',
      'post_status'    => 'any',
      'meta_value'    => "$image_url"
    ));
    $last_attachment_post = @$posts[0];
    if ($last_attachment_post) {
      return $last_attachment_post->ID;
    }
    // it allows us to use download_url() and wp_handle_sideload() functions
    require_once(ABSPATH . 'wp-admin/includes/file.php');

    // download to temp dir
    $temp_file = download_url($image_url);

    if (is_wp_error($temp_file)) {
      return false;
    }

    // move the temp file into the uploads directory
    $file = array(
      'name'     => basename($image_url),
      'type'     => mime_content_type($temp_file),
      'tmp_name' => $temp_file,
      'size'     => filesize($temp_file),
    );
    $sideload = wp_handle_sideload(
      $file,
      array(
        'test_form'   => false // no needs to check 'action' parameter
      )
    );

    if (!empty($sideload['error'])) {
      // you may return error message if you want
      return false;
    }

    // it is time to add our uploaded image into WordPress media library
    $attachment_id = wp_insert_attachment(
      array(
        'guid'           => $sideload['url'],
        'post_mime_type' => $sideload['type'],
        'post_title'     => basename($sideload['file']),
        'post_content'   => '',
        'post_status'    => 'inherit',
      ),
      $sideload['file']
    );

    if (is_wp_error($attachment_id) || !$attachment_id) {
      return false;
    }
    update_post_meta((int)$attachment_id, "main_file_url", $image_url);

    // update medatata, regenerate image sizes
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    wp_update_attachment_metadata(
      $attachment_id,
      wp_generate_attachment_metadata($attachment_id, $sideload['file'])
    );

    $file = get_attached_file($attachment_id);
    $path = pathinfo($file);

    $newfilename = self::random_hash_file(5);
    $newfile = $path['dirname'] . "/" . $newfilename . "." . $path['extension'];

    rename($file, $newfile);
    update_attached_file($attachment_id, $newfile);

    return $attachment_id;
  }
  public static function url_exists($url)
  {
    set_time_limit(20);
    return curl_init($url) !== false;
  }
  public static function mw_wp2moodle_generate_hyperlink($cohort, $group, $course, $activity = 0, $url = null, $cmid = 0, $current_user)
  {


    $update = get_option('wp2m_update_details') ?: "true";

    $enc = array(
      "offset" => rand(1234, 5678),                        // just some junk data to mix into the encryption
      "stamp" => time(),                                    // unix timestamp so we can check that the link isn't expired
      "firstname" => $current_user->user_firstname,        // first name
      "lastname" => $current_user->user_lastname,            // last name
      "email" => $current_user->user_email,                // email
      "username" => $current_user->user_login,            // username
      "passwordhash" => $current_user->user_pass,            // hash of password (we don't know/care about the raw password)
      "idnumber" => $current_user->ID,                    // int id of user in this db (for user matching on services, etc)
      "cohort" => $cohort,                                // string containing cohort to enrol this user into
      "group" => $group,                                    // string containing group to enrol this user into
      "course" => $course,                                // string containing course id, optional
      "activity" => $activity,                            // index of first [visible] activity to go to, if auto-open is enabled in moodle
      "cmid" => $cmid,                                    // coursemodule id
      "url" => rawurlencode($url)                            // url to open after logon
    );

    // encode array as querystring
    $details = http_build_query($enc);
    // encryption = 3des using shared_secret
    return rtrim(get_option('wp2m_moodle_url'), "/") . WP2M_MOODLE_PLUGIN_URL . encrypt_string($details, get_option('wp2m_shared_secret'));
    //return get_option('wp2m_moodle_url').WP2M_MOODLE_PLUGIN_URL.'=>'.$details;
  }
  public static function moopress_auth_singon_wp($user_id)
  {
    $secure_cookie = is_ssl();
    global $auth_secure_cookie;
    $auth_secure_cookie = $secure_cookie;
    wp_set_auth_cookie($user_id, false, $secure_cookie);
    return $user_id;
  }
  public static function get_elementor_library_templates()
  {
    $posts = get_posts(array(
      'numberposts'   => -1,
      'post_type'     => 'elementor_library',
    ));
    return $posts;
  }
}
