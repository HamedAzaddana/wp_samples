<?php

namespace LmskaranMoopress\Controllers\Helpers;

use LmskaranMoopress\Controllers\Webservice\MoodleController;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;



class Enroll
{

  public static function enroll_user_in_course($user_wp_id, $course_wp_id, $role_id, $role_title, $order_id)
  {
    //enroll in moodle webservice
    $user_id_mdl = (int)get_user_meta($user_wp_id, "user_id_mdl", true);
    $course_mdl_id = (int)get_post_meta($course_wp_id, 'course_id_mdl', true);
    if (!$user_id_mdl || !$course_mdl_id) {
      return false;
    }
    MoodleController::enroll_user_course($user_id_mdl, $course_mdl_id, $role_id);
    //enroll in wp table
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    $sql_uniques = $wpdb->prepare(
      "SELECT * FROM $tn 
    WHERE `user_moodle_id` = %d AND `course_moodle_id` = %d AND `role_moodle_id` = %d",
      $user_id_mdl,
      $course_mdl_id,
      $role_id,
    );
    $results_unique = $wpdb->get_results($sql_uniques, ARRAY_A);
    if (!$results_unique) {
      $data_wp = [
        'user_moodle_id' => $user_id_mdl,
        'course_moodle_id' => $course_mdl_id,
        'role_moodle_id' => $role_id,
        'role_moodle_title' => $role_title,
        'order_id' => $order_id,
        'created_at' => date("Y-m-d H:i:s"),
      ];
      $wpdb->insert("$tn", $data_wp);
      $response_id = $wpdb->insert_id;
      return true;
    }
  }
  public static function enroll_user_in_course__moodle($user_id_mdl, $course_mdl_id, $role_id, $role_title, $order_id)
  {
    //enroll in moodle webservice
    if (!$user_id_mdl || !$course_mdl_id) {
      return false;
    }
    MoodleController::enroll_user_course($user_id_mdl, $course_mdl_id, $role_id);
    //enroll in wp table
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    $sql_uniques = $wpdb->prepare(
      "SELECT * FROM $tn 
    WHERE `user_moodle_id` = %d AND `course_moodle_id` = %d",
      $user_id_mdl,
      $course_mdl_id,
      $role_id,
    );
    $results_unique = $wpdb->get_results($sql_uniques, ARRAY_A);
    if (!$results_unique) {
      $data_wp = [
        'user_moodle_id' => $user_id_mdl,
        'course_moodle_id' => $course_mdl_id,
        'role_moodle_id' => $role_id,
        'role_moodle_title' => $role_title,
        'order_id' => $order_id,
        'created_at' => date("Y-m-d H:i:s"),
      ];
      $wpdb->insert("$tn", $data_wp);
      $response_id = $wpdb->insert_id;
      return true;
    } else {
      $data_wp = [
        'role_moodle_id' => $role_id,
        'role_moodle_title' => $role_title,
        'order_id' => $order_id,
        'created_at' => date("Y-m-d H:i:s"),
      ];
      $where__s = [
        'user_moodle_id' => $user_id_mdl,
        'course_moodle_id' => $course_mdl_id,
      ];
      $wpdb->update("$tn", $data_wp, $where__s);
    }
  }
  public static function unenroll_user_from_course($user_id_mdl, $course_mdl_id, $role_id)
  {
    //unenroll in moodle webservice
    MoodleController::unenroll_user_course($user_id_mdl, $course_mdl_id, $role_id);
    //unenroll in wp table
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    $wpdb->query(
      $wpdb->prepare(
        "DELETE  FROM  $tn 
           WHERE `user_moodle_id` = %d AND `course_moodle_id` = %d AND `role_moodle_id` = %d",
        $user_id_mdl,
        $course_mdl_id,
        $role_id,
      )
    );
  }
  public static function get_participants_course_moodle($course_mdl_id = 0, $search = '', $user_id = 0)
  {
    $participants = [];
    $user_id_mdl_selected = 0;
    if ($user_id) {
      $user_id_mdl_selected = (int)get_user_meta($user_id, 'user_id_mdl', true);
    }
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    if ($course_mdl_id) {
      $pivot_records = $wpdb->prepare(
        "SELECT * FROM $tn 
      WHERE `course_moodle_id` = %d ORDER BY `created_at` DESC",
        $course_mdl_id,
      );
    } else {
      $pivot_records = $wpdb->prepare(
        "SELECT * FROM $tn ORDER BY `created_at` DESC"
      );
    }

    $results_pivot_records = $wpdb->get_results($pivot_records, ARRAY_A);
    foreach ($results_pivot_records as $pv_record) {
      $user_id_mdl = (int)$pv_record['user_moodle_id'];
      $order_id = (int)$pv_record['order_id'];
      $course_moodle_id = (int)$pv_record['course_moodle_id'];
      $order = get_post($order_id);
      $course = CourseApiModel::getCourseByMdlId($course_moodle_id);
      $user_fetch = UserApiModel::getUserByMdlId($user_id_mdl);
      if (!$user_fetch) {
        continue;
      }
      $role_title = $pv_record['role_moodle_title'];
      $role_id = (int)$pv_record['role_moodle_id'];
      $created_at = (string)$pv_record['created_at'];
      $created_at_tmp = strtotime($created_at);
      $date = moopress_jdate("Y/m/d - H:i", $created_at_tmp);
      if ($course_mdl_id) {
        $participant = [
          'user_info' => $user_fetch,
          'order_info' => $order,
          'role_title' => $role_title,
          'role_id' => $role_id,
          'created_at_jalali' => $date,
        ];
      } else {
        $participant = [
          'user_info' => $user_fetch,
          'order_info' => $order,
          'course_info' => $course,
          'role_title' => $role_title,
          'role_id' => $role_id,
          'created_at_jalali' => $date,
        ];
      }
      if ($user_id_mdl_selected && $user_id_mdl !=$user_id_mdl_selected) {
        continue;
      }
      if (!$search) {
        $participants[(int)$pv_record['id']] = $participant;
      } else {
        $username = $user_fetch->data->user_login;
        $display_name = $user_fetch->data->display_name;
        $first_name = get_user_meta($user_fetch->ID, 'first_name', true);
        $last_name = get_user_meta($user_fetch->ID, 'last_name', true);
        if (
          strpos($username, $search) !== false
          || strpos($first_name, $search) !== false
          || strpos($last_name, $search) !== false
          || strpos($display_name, $search) !== false
        ) {
          $participants[(int)$pv_record['id']] = $participant;
        }
      }
    }
    return $participants;
  }
  public static function is_user_enrolled_in($user_id_mdl, $course_mdl_id)
  {
    if (!get_current_user_id()) {
      return false;
    }
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    $pivot_records = $wpdb->prepare(
      "SELECT * FROM $tn 
WHERE `user_moodle_id` = %d AND `course_moodle_id` = %d",
      $user_id_mdl,
      $course_mdl_id,
    );
    $results_pivot_records = $wpdb->get_results($pivot_records, ARRAY_A);
    return count($results_pivot_records) ? true : false;
  }
  public static function get_courses_user($user_id_mdl)
  {
    $courses = [];
    global $wpdb;
    $tn = $wpdb->prefix . 'moopress_enrolment';
    $pivot_records = $wpdb->prepare(
      "SELECT * FROM $tn 
WHERE `user_moodle_id` = %d ORDER BY `created_at` DESC",
      $user_id_mdl,
    );
    $results_pivot_records = $wpdb->get_results($pivot_records, ARRAY_A);
    foreach ($results_pivot_records as $pv_record) {
      $course_moodle_id = (int)$pv_record['course_moodle_id'];
      $course_post = CourseApiModel::getCourseByMdlId($course_moodle_id);
      $role_title = $pv_record['role_moodle_title'];
      $created_at = (string)$pv_record['created_at'];
      $created_at_tmp = strtotime($created_at);
      $date = moopress_jdate("Y/m/d - H:i", $created_at_tmp);
      $course = [
        'course_post' => $course_post,
        'role_title' => $role_title,
        'created_at_jalali' => $date,
      ];
      $courses[(int)$pv_record['id']] = $course;
    }

    return  $courses;
  }
}
