<?php

namespace LmskaranMoopress\Controllers\Ajax;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Webservice\MoodleController;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;

class AjaxController extends Controller
{
    public function add_manual_participant_course()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $role = $requests['role'];
        $user_id = (int)$requests['user_id'];
        $course_id = (int)$requests['course_wp_id'];
        $role_segments = explode("___", $role);
        $role_id = (int)@$role_segments[0];
        $role_title = @$role_segments[1];
        if (!$user_id) {
            wp_send_json_error('کاربری انتخاب نشده است !', 422);
        }
        if (!$role_id) {
            wp_send_json_error('نقش کاربری انتخاب نشده است !', 422);
        }
        EnrollHelper::enroll_user_in_course($user_id, $course_id, $role_id, $role_title, 0);
        wp_send_json_success("عملیات انجام شد. ", 200);
    }
    public function unenroll_participants_moodle()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $role_id = (int)$requests['role_id'];
        $user_id = (int)$requests['user_id'];
        $course_id = (int)$requests['course_id'];
        EnrollHelper::unenroll_user_from_course($user_id, $course_id, $role_id);
        wp_send_json_success("عملیات انجام شد. ", 200);
    }
    public function get_course_participants_moodle()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['KeyWord'])) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $course_moodle_id = (int)$requests['course_moodle_id'];
        $user_id_selected = (int)@$requests['user_id_selected'];
        $paged_num = (int)$requests['paged_num'];
        $KeyWord = $requests['KeyWord'] ? sanitize_text_field($requests['KeyWord']) : "";
        $participants_all = EnrollHelper::get_participants_course_moodle($course_moodle_id, $KeyWord, $user_id_selected);

        $cnt_results = count($participants_all);
        $per_page = 50;
        $links_num = ceil($cnt_results / $per_page);
        $paged_num = isset($_POST['paged_num']) ? intval($_POST['paged_num']) : 1;
        $last_num_paged =  $links_num;
        $participants_table = array_slice($participants_all, ($paged_num - 1) * $per_page, $per_page);
        echo $this->view->get('get_course_participants_ajax', [
            'participants' => $participants_table,
            'cnt_results' => $cnt_results,
            'links_num' => $links_num,
            'paged_num' => $paged_num,
            'KeyWord' => $KeyWord,
            'course_moodle_id' => $course_moodle_id,
            'last_num_paged' => $last_num_paged,
        ]);
        die;
    }
    public function get_course_modules_front()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $cidm = (int)$requests['cid'];
        //check user bought product via cid
        $user = wp_get_current_user();
        $user_id = intval($user->data->ID);
        $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));

        $course_modules = MoodleController::get_course_details($cidm, $user_id_mdl);
        $percentage_complete = MoodleController::get_course_complete_percentages($cidm, $user_id_mdl);
        $is_enrolled_course = EnrollHelper::is_user_enrolled_in($user_id_mdl, $cidm);

        $view_html = $this->view->get('course_modules_ajax', [
            'course_id_mdl' => $cidm,
            'course_modules' => $course_modules,
            'percentage_complete' => $percentage_complete,
            'is_enrolled_course' => $is_enrolled_course,
        ]);
        echo $view_html;
        die;
    }
    public function sync_product_from_moodle()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_options') || !isset($requests['moopress_csrf_token'])) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $product_id = (int)$requests['product_id'];
        $course_mdl_id = (int)get_post_meta($product_id, 'course_id_mdl', true);
        if (!$course_mdl_id) {
            wp_send_json_error('دوره در مودل ثبت نشده است !', 401);
        }
        $course_moodle = (array)MoodleController::get_courses($course_mdl_id);
        $pid_out = CourseApiModel::syncCourse_single($course_moodle, $product_id, $course_mdl_id);
        if ($pid_out) {
            wp_send_json_success("همگام سازی با موفقیت انجام شد !", 200);
        } else {
            wp_send_json_error("خطایی رخ داد !", 403);
        }
    }
    public function sync_product_to_moodle_force()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_options') || !isset($requests['moopress_csrf_token'])) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }
        $product_id = (int)$requests['product_id'];
        $moodle_response = MoodleController::update_create_course($product_id);
        $errors = @$moodle_response->warnings;
        if (!$errors) {
            $course_mdl_id = (int)get_post_meta($product_id, 'course_id_mdl', true);
            if ($course_mdl_id) {
                $course_moodle = (array)MoodleController::get_courses($course_mdl_id);
                $pid_out = CourseApiModel::sync_custom_fields($course_moodle, $product_id, $course_mdl_id);
            }
            wp_send_json_success("همگام سازی با موفقیت انجام شد !", 200);
        } else {
            $_errors = "<b>" . "خطایی رخ داد ! <br>" . "</b>";
            foreach ($errors as $error) {
                $_errors .= "<p style='color: #F44336;direction: ltr;'><b>" . $error->message . "</b></p>";
            }
            wp_send_json_error($_errors, 401);
        }
    }
    public function test_moodle_connection()
    {
        $requests = Request::all();
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }
        if (!current_user_can('manage_options') || !isset($requests['moopress_csrf_token'])) {
            wp_send_json_error("به این بخش دسترسی ندارید !", 403);
        }

        $msg = $this->validate_csrf($requests);
        if ($msg) {
            wp_send_json_error($msg, 403);
        }

        $report = MoodleController::test_connection();
        if ($report) {
            wp_send_json_success("اتصال شما با مودل برقرار شد !", 200);
        } else {
            wp_send_json_error("اتصال با مودل برقرار نشد !", 403);
        }
        wp_die();
    }
    private function validate_csrf($requests)
    {
        $user_ip = $_SERVER['REMOTE_ADDR'];
        $salt_nonce_moopress = "csrf_of_moopress" . $user_ip . "OUIHJfvudgf*@&^#";
        $csrf_moopress_post = $requests['moopress_csrf_token'];
        $is_verified_nonce = wp_verify_nonce($csrf_moopress_post, $salt_nonce_moopress);
        if (!$is_verified_nonce) {
            return "لطفا صفحه را مجدد رفرش کنید !";
        } else {
            return '';
        }
    }
}
