<?php

namespace LmskaranMoopress\Controllers;

use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;
use WPMVC\MVC\Controller;
use LmskaranMoopress\Controllers\Webservice\MoodleController;

class OrderController extends Controller
{
    public function enrol_user_after_order($order_id)
    {
        // ini_set('display_startup_errors', 1);
        // error_reporting(E_ALL);
        $order_id = (int)$order_id;
        $order = wc_get_order($order_id);
        $user_id = $order->get_user_id();
        $user_id_mdl = intval(get_user_meta($user_id, 'user_id_mdl', true));
        if ($user_id_mdl) {
            $roles = MoodleController::get_roles();
            $role_student = [];
            foreach ($roles as $role) {
                $role = (array)$role;
                if ($role['shortname'] == "student") {
                    $role_student = $role;
                }
            }
            foreach ($order->get_items() as $item_id => $item) {
                $product_id = $item->get_product_id();
                $course_id_mdl = intval(get_post_meta($product_id, "course_id_mdl", true));
                if ($course_id_mdl) {
                    EnrollHelper::enroll_user_in_course(
                        $user_id,
                        $product_id,
                        $role_student['id'],
                        $role_student['shortname'],
                        $order_id
                    );
                }
            }
        }
    }
    public function enrol_user_after_any_order($order_id, $order)
    {
        $opt = get_option("moopress_api_info", '');
        $settings = $opt ? unserialize(base64_decode($opt)) : [];
        $order_enrol_status = @$settings['order_enrol_status'] ? $settings['order_enrol_status'] : 'wc-completed';
        $order_id = (int)$order_id;
        $order = wc_get_order($order_id);
        $order_status = "wc-" . @$order->status;
        $user_id = $order->get_user_id();
        $user_id_mdl = intval(get_user_meta($user_id, 'user_id_mdl', true));
        if ($user_id_mdl && $order_status == $order_enrol_status) {
            $roles = MoodleController::get_roles();
            $role_student = [];
            foreach ($roles as $role) {
                $role = (array)$role;
                if ($role['shortname'] == "student") {
                    $role_student = $role;
                }
            }
            foreach ($order->get_items() as $item_id => $item) {
                $product_id = $item->get_product_id();
                $course_id_mdl = intval(get_post_meta($product_id, "course_id_mdl", true));
                if ($course_id_mdl) {
                    EnrollHelper::enroll_user_in_course(
                        $user_id,
                        $product_id,
                        $role_student['id'],
                        $role_student['shortname'],
                        $order_id
                    );
                }
            }
        }
    }
    public function enrol_user_after_change_order($order_id, $old_status, $new_status)
    {
        $opt = get_option("moopress_api_info", '');
        $settings = $opt ? unserialize(base64_decode($opt)) : [];
        $order_enrol_status = @$settings['order_enrol_status'] ? $settings['order_enrol_status'] : 'wc-completed';
        $order_id = (int)$order_id;
        $order = wc_get_order($order_id);
        $order_status = "wc-" . @$new_status;
        $user_id = $order->get_user_id();
        $user_id_mdl = intval(get_user_meta($user_id, 'user_id_mdl', true));
        if ($user_id_mdl && $order_status == $order_enrol_status) {
            $roles = MoodleController::get_roles();
            $role_student = [];
            foreach ($roles as $role) {
                $role = (array)$role;
                if ($role['shortname'] == "student") {
                    $role_student = $role;
                }
            }
            foreach ($order->get_items() as $item_id => $item) {
                $product_id = $item->get_product_id();
                $course_id_mdl = intval(get_post_meta($product_id, "course_id_mdl", true));
                if ($course_id_mdl) {
                    EnrollHelper::enroll_user_in_course(
                        $user_id,
                        $product_id,
                        $role_student['id'],
                        $role_student['shortname'],
                        $order_id
                    );
                }
            }
        }
    }
}
