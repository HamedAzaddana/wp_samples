<?php

namespace LmskaranMoopress\Controllers;

use WPMVC\MVC\Controller;


class EnqueuConrtoller extends Controller
{
   
    public function admin()
    {
        wp_enqueue_script('moopress-admin-js',$this->plugins_url('assets/js/admin.js'),array('jquery','wp-color-picker'),"1.0.0",true);
        wp_enqueue_style('moopress-admin-css',$this->plugins_url('assets/css/admin.css'),array(),"1.0.0");
    }

    public function front()
    {
        wp_enqueue_script('moopress-front-js',$this->plugins_url('assets/js/front.js'),array('jquery'),"1.0.0",true);
        wp_enqueue_style('moopress-front-css',$this->plugins_url('assets/css/front.css'),array(),"1.0.0");


    }
    public function plugins_url($url)
    {
        return plugins_url('moopress_lmskaran/' . $url);
    }
}
