<?php

namespace LmskaranMoopress\Controllers;

use LmskaranMoopress\Controllers\Helpers\Base;
use WPMVC\MVC\Controller;
use LmskaranMoopress\Controllers\Webservice\MoodleController;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;
use WPMVC\Request;

class ProductController extends Controller
{

    public function moodle_fields()
    {
        $categories_mdl = MoodleController::get_categories();
        $options_questions = array(
            '2' => 'پیش فرض',
            '1' => 'بله',
            '0' => 'خیر',
        );
        $cmb2_box = new_cmb2_box(array(
            'id'            => 'moodle_cmb2_metabox',
            'title'          => __('اطلاعات دوره مودل', 'cmb2'),
            'object_types'   => array('product'), // Post type
        ));
        $cmb2_box_customs = new_cmb2_box(array(
            'id'            => 'moodle_cmb2_customs_metabox',
            'title'          => __('فیلد های دلخواه دوره در مودل', 'cmb2'),
            'object_types'   => array('product'), // Post type
        ));
        $cmb2_box_settings = new_cmb2_box(array(
            'id'            => 'moodle_cmb2_settings_metabox',
            'title'          => __('تنظیمات دوره', 'cmb2'),
            'object_types'   => array('product'), // Post type
        ));
        $cmb2_box->add_field(array(
            'id'   => 'course_id_mdl',
            'type' => 'hidden',
        ));
        $cmb2_box->add_field(array(
            'name' => 'آدرس دوره در مودل',
            'desc' => '',
            'type' => 'text_url',
            'id'   => 'course_moodle_url'
        ));

        $cmb2_box->add_field(array(
            'name'    => 'نام کوتاه دوره',
            'desc'    => 'این فیلد در سایدبار دانش آموز نشان داده شده و در ایمیل ها نیز با این عنوان دوره نشان داده می شود.<br><strong>نباید با  نام کوتاه دیگر محصولات، یکی باشد.</strong>',
            'default' => "",
            'id'      => 'short_name_course_mdl',
            'type'    => 'text',
        ));
        $cmb2_box->add_field(array(
            'name'    => 'تاریخ شروع دوره',
            'desc'    => '',
            'default' => '',
            'id'      => 'begin_date_course_mdl_jalali',
            'type'    => 'text',
            'attributes'  => array(
                'jdp' => 'jdp',
            ),
        ));
        $cmb2_box->add_field(array(
            'name'    => 'تاریخ پایان دوره',
            'desc'    => '',
            'default' => '',
            'id'      => 'end_date_course_mdl_jalali',
            'type'    => 'text',
            'attributes'  => array(
                'jdp' => 'jdp',
            ),
        ));
        $cmb2_box->add_field(array(
            'name'             => 'دسته بندی دوره',
            'desc'             => '',
            'id'               => 'category_course_mdl',
            'type'             => 'select',
            'show_option_none' => true,
            'default'          => "0",
            'options'          => $categories_mdl,
        ));

        $group_field_id_low = $cmb2_box_customs->add_field(array(
            'id'          => 'custom_fields_low_moodle',
            'type'        => 'group',
            'description' => 'فیلد های کوتاه دلخواه کاربران',
            // 'repeatable'  => false, // use false if you want non-repeatable group
            'options'     => array(
                'group_title'       => __('Entry {#}', 'cmb2'), // since version 1.1.4, {#} gets replaced by row number
                'add_button'        => __('Add Another Entry', 'cmb2'),
                'remove_button'     => __('Remove Entry', 'cmb2'),
                'sortable'          => true,
                // 'closed'         => true, // true to have the groups closed by default
                // 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
            ),
        ));
        $group_field_id_high = $cmb2_box_customs->add_field(array(
            'id'          => 'custom_fields_high_moodle',
            'type'        => 'group',
            'description' => 'فیلد های متنی دلخواه کاربران',
            // 'repeatable'  => false, // use false if you want non-repeatable group
            'options'     => array(
                'group_title'       => __('Entry {#}', 'cmb2'), // since version 1.1.4, {#} gets replaced by row number
                'add_button'        => __('Add Another Entry', 'cmb2'),
                'remove_button'     => __('Remove Entry', 'cmb2'),
                'sortable'          => true,
                // 'closed'         => true, // true to have the groups closed by default
                // 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
            ),
        ));
        $group_field_id_date = $cmb2_box_customs->add_field(array(
            'id'          => 'custom_fields_date_moodle',
            'type'        => 'group',
            'description' => 'فیلد های نوع تاریخ دلخواه کاربران',
            // 'repeatable'  => false, // use false if you want non-repeatable group
            'options'     => array(
                'group_title'       => __('Entry {#}', 'cmb2'), // since version 1.1.4, {#} gets replaced by row number
                'add_button'        => __('Add Another Entry', 'cmb2'),
                'remove_button'     => __('Remove Entry', 'cmb2'),
                'sortable'          => true,
                // 'closed'         => true, // true to have the groups closed by default
                // 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
            ),
        ));


        // Id's for group's fields only need to be unique for the group. Prefix is not needed.
        $cmb2_box_customs->add_group_field($group_field_id_low, array(
            'name' => 'کلید فیلد دلخواه',
            'id'   => 'key_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_low, array(
            'name' => 'عنوان فیلد',
            'id'   => 'title_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_low, array(
            'name' => 'مقدار فیلد دلخواه',
            'id'   => 'value_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_low, array(
            'name' => 'مقدار مودلی فیلد دلخواه(غیر قابل ویرایش)',
            'id'   => 'value_mdl_custom_fld',
            'type' => 'text',
            'attributes' => array(
                'readonly' => 'readonly',
            )
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        // Id's for group's fields only need to be unique for the group. Prefix is not needed.
        $cmb2_box_customs->add_group_field($group_field_id_high, array(
            'name' => 'کلید فیلد دلخواه',
            'id'   => 'key_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_high, array(
            'name' => 'عنوان فیلد',
            'id'   => 'title_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_high, array(
            'name' => 'مقدار فیلد دلخواه',
            'id'   => 'value_custom_fld',
            'type' => 'wysiwyg',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_high, array(
            'name' => 'مقدار مودلی فیلد دلخواه(غیر قابل ویرایش)',
            'id'   => 'value_mdl_custom_fld',
            'type' => 'text',
            'attributes' => array(
                'readonly' => 'readonly',
            )
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        // Id's for group's fields only need to be unique for the group. Prefix is not needed.
        $cmb2_box_customs->add_group_field($group_field_id_date, array(
            'name' => 'کلید فیلد دلخواه',
            'id'   => 'key_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_date, array(
            'name' => 'عنوان فیلد',
            'id'   => 'title_custom_fld',
            'type' => 'text',
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_date, array(
            'name' => 'مقدار فیلد دلخواه',
            'id'   => 'value_custom_fld',
            'type' => 'text',
            'attributes'  => array(
                'jdp' => 'jdp',
            ),
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_customs->add_group_field($group_field_id_date, array(
            'name' => 'مقدار مودلی فیلد دلخواه(غیر قابل ویرایش)',
            'id'   => 'value_mdl_custom_fld',
            'type' => 'text',
            'attributes' => array(
                'readonly' => 'readonly',
            )
            // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
        ));
        $cmb2_box_settings->add_field(array(
            'name'             => 'دوره بعد حذف از طرف مودل، در وردپرس هم حذف شود ؟',
            'desc'             => '',
            'id'               => 'force_delete_course',
            'type'             => 'select',
            'show_option_none' => true,
            'default'          => "2",
            'options'          => $options_questions,
        ));
        $cmb2_box_settings->add_field(array(
            'name'             => ' محتوای دوره در وردپرس، بعد از تغییر مقدار آن در مودل و یا در حین همگام سازی از مودل به وردپرس، در وردپرس هم تغییر کند ؟',
            'desc'             => '',
            'id'               => 'force_content_course',
            'type'             => 'select',
            'show_option_none' => true,
            'default'          => "2",
            'options'          => $options_questions,
        ));
        $cmb2_box_settings->add_field(array(
            'name'             => ' عنوان دوره در وردپرس، بعد از تغییر مقدار آن در مودل و یا در حین همگام سازی از مودل به وردپرس، در وردپرس هم تغییر کند ؟',
            'desc'             => '',
            'id'               => 'force_title_course',
            'type'             => 'select',
            'show_option_none' => true,
            'default'          => "2",
            'options'          => $options_questions,
        ));
    }
    public function save_product_handle($post_id, $post)
    {
        if (get_post_type($post_id) == 'product') {
            //update thumbnail url meta
            $thumbnail_img = @wp_get_attachment_image_src(get_post_thumbnail_id($post_id), 'single-post-thumbnail')[0];
            if ($thumbnail_img && !Base::url_exists($thumbnail_img)) {
                $thumbnail_img = '';
            }
            update_post_meta($post_id, 'real_url_img_moodle_path', $thumbnail_img);
        }
    }
    public function add_sync_btn_moodle($post_obj)
    {
        global $post;
        if ($post->post_type == 'product') {
            $requests = Request::all();
            $action_param = @$requests['action'];
            $_moodle_icon_img = get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/moodle_icon_black.png";
            $pid = (int)$post->ID;
            $course_mdl_id = (int)get_post_meta($pid, 'course_id_mdl', true);
            if ($course_mdl_id && $action_param == "edit") {
                echo '<button data-pid="' . $pid . '" id="moopress_sync_single_product" type="button" class="btn-moopress-success"> <i class="fa fa-refresh"></i> همگام سازی از مودل <img style="width: 22px;height: 15px;"  src="' . $_moodle_icon_img . '"> </button><br>';
            }
            if ($action_param == "edit") {
                echo '<button data-pid="' . $pid . '" id="moopress_sync_single_product_to_moodle" type="button" class="btn-moopress-success" style="background:#FF5722 !important;"><i class="fa fa-refresh"></i>  همگام سازی به مودل <img style="width: 22px;height: 15px;"  src="' . $_moodle_icon_img . '"></button><br>';
            }
            $user_ip = $_SERVER['REMOTE_ADDR'];
            $salt_nonce_moopress = "csrf_of_moopress" . $user_ip . "OUIHJfvudgf*@&^#";
            wp_nonce_field($salt_nonce_moopress, 'Moopress_Csrf_Token');
        }
        $ajax_url_wp = admin_url('admin-ajax.php');
        $view_html_submitbox = $this->view->get('load_js_moopress_submitbox_misc_actions', [
            'ajax_url_wp' => $ajax_url_wp
        ]);
        echo $view_html_submitbox;
    }
    public function register_columns($defaults)
    {
        // $defaults['sync-btn'] = 'همگام سازی';
        // return $defaults;
    }
    public function handle_new_columns($column_name, $post_id)
    {
        $post_obj = get_post($post_id);
        if ($column_name == 'name') {
            // echo '<button data-title="'.$post_obj->post_title.'" data-pid="' . $post_id . '" style="display:flex;" type="button" class="btn-moopress-success moopress_sync_table_product"> <i class="fa fa-refresh"></i>  همگام سازی از مودل </button>';
        }
    }
    public function add_bulk_action_sync($actions)
    {
        $actions['sync_from_moodle'] = 'همگام سازی از مودل';
        return $actions;
    }
    public function handle_product_bulk_actions($redirect_to, $doaction, $post_ids)
    {
        if ($doaction == 'sync_from_moodle') {
            if ($post_ids) {

                foreach ($post_ids as $product_id) {
                    $course_mdl_id = (int)get_post_meta($product_id, 'course_id_mdl', true);
                    if ($course_mdl_id) {
                        $course_moodle = (array)MoodleController::get_courses($course_mdl_id);
                        $pid_out = CourseApiModel::syncCourse_single($course_moodle, $product_id, $course_mdl_id);
                        // echo $pid_out . "<br>";
                    }
                }
            }
        }
        wp_redirect($redirect_to);
        die;
    }
    public function add_course_elementor_templates($content)
    {
        $_header_html = "";
        $_footer_html = "";
        if (is_singular('product')) {
            $opt = get_option("moopress_api_info", '');
            if ($opt) {
                $settings = unserialize(base64_decode($opt));
                $elementor_library_header_id = (int)@$settings['elementor_library_header_id'];
                $elementor_library_footer_id = (int)@$settings['elementor_library_footer_id'];
            }

            $product_id = get_the_ID();
            $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $product_permalink = get_permalink($product_id);
            if (strpos(urldecode($current_url), urldecode($product_permalink)) !== false) {
                if ($elementor_library_header_id) {
                    if (class_exists("\\Elementor\\Plugin")) {
                        $pluginElementor = \Elementor\Plugin::instance();
                        $_header_html = $pluginElementor->frontend->get_builder_content($elementor_library_header_id);
                    } else {
                        $_header_html = do_shortcode(get_post_field('post_content', $elementor_library_header_id));
                    }
                }
                if ($elementor_library_footer_id) {
                    if (class_exists("\\Elementor\\Plugin")) {
                        $pluginElementor = \Elementor\Plugin::instance();
                        $_footer_html = $pluginElementor->frontend->get_builder_content($elementor_library_footer_id);
                    } else {
                        $_footer_html = do_shortcode(get_post_field('post_content', $elementor_library_footer_id));
                    }
                }
            }
        }
        return $_header_html . $content . $_footer_html;
    }
    public function show_participants_course()
    {
        add_meta_box('moodle_participants_course', "شرکت کنندگان دوره", array($this, 'show_participants_course_view'), 'product', 'advanced', 'high');
    }
    public function show_participants_course_view($post)
    {
        $post_id = $post->ID;
        $course_id_mdl = get_post_meta($post_id, "course_id_mdl", true);

        $users_moodle = UserApiModel::getUsersMoodle();
        $roles = MoodleController::get_roles();

        echo $this->view->get('show_participants_course', [
            'course_id_mdl' => $course_id_mdl,
            'course_id_wp' => $post_id,
            'users_moodle' => $users_moodle,
            'roles' => $roles,
        ]);
    }
    public function load_my_courses_enrolled()
    {

        $user = wp_get_current_user();
        $user_id = intval($user->data->ID);
        $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));
        $courses_user = EnrollHelper::get_courses_user($user_id_mdl);
        $view_html = $this->view->get('shortcodes.my_courses_enrolled', [
            'user_id_mdl' => $user_id_mdl,
            'user_id' => $user_id,
            'user' => $user,
            'courses_user' => $courses_user,
        ]);
        ob_start();
        echo $view_html;
        $output = ob_get_clean();
        return $output;
    }
    public function load_course_participants_role_id($atts = array(), $content = null)
    {
        global $post;
        $role_id = (int)$atts['role_id'];
        $course_id = (int)$post->ID;
        $course_mdl_id = (int)get_post_meta($course_id, 'course_id_mdl', true);
        if ($course_id && $course_mdl_id && $role_id) {
            $participants_all = EnrollHelper::get_participants_course_moodle($course_mdl_id, '');
            $_participants = [];
            foreach ($participants_all as $participant) {
                if ($participant['role_id'] == $role_id) {
                    $_participants[] = $participant;
                }
            }
            $view_html = $this->view->get('shortcodes.course_participants_role_id', [
                'participants' => $_participants,
            ]);
            ob_start();
            echo $view_html;
            $output = ob_get_clean();
            return $output;
        }
    }
    public function load_course_modules_sections($atts = array(), $content = null)
    {
        global $post;
        $course_id = (int)$post->ID;
        $course_mdl_id = (int)get_post_meta($course_id, 'course_id_mdl', true);
        $view_html = $this->view->get('shortcodes.load_course_modules_sections', [
            'course_id_mdl' => $course_mdl_id,
        ]);
        ob_start();
        echo $view_html;
        $output = ob_get_clean();
        return $output;
    }
    public function load_moodle_quiz($atts = array(), $content = null)
    {
        $requests = Request::all();
        $frame_url =  @$requests['frame_url'] ? base64_decode($requests['frame_url']) : "";
        $view_html = $this->view->get('shortcodes.load_moodle_quiz', [
            'frame_url' => $frame_url,
        ]);
        ob_start();
        echo $view_html;
        $output = ob_get_clean();
        return $output;
    }
}
