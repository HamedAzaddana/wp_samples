<?php

namespace LmskaranMoopress\Controllers\Api;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;
use LmskaranMoopress\Controllers\Webservice\MoodleController;

class CourseController extends Controller
{
    private $namespace;
    private $resource_name;
    // Here initialize our namespace and resource name.
    public function __construct()
    {
        $this->namespace     = '/moopress/v1';
        $this->resource_name = 'course';
    }

    // Register our routes.
    public function register_routes()
    {
        //local routes
        register_rest_route($this->namespace, '/' . 'sync/course', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'create_sync_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . 'sync/category', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'create_sync_category'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        //remote moodle routes
        register_rest_route($this->namespace, '/' . $this->resource_name, array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'create_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . $this->resource_name . '/update', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'update_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . $this->resource_name . '/update/cost', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'update_course_cost'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . $this->resource_name . '/delete', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'delete_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . "test_connection", array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'test_connection'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . "user/course/role_assign", array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'role_assign_user_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . "user/course/role_unassign", array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'role_unassign_user_course'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        // register_rest_route('jk', '/' . 'test', array(
        //     array(
        //         'methods'   => 'GET',
        //         'callback'  => array($this, 'test'),
        //         'permission_callback' => '__return_true',
        //     )
        // ));
    }

    public function test()
    {
        $requests = Request::all();
        $headers = BaseHelper::get_request_headers();
        $img = @$requests['url'];
        if ($img) {
            $pid =  BaseHelper::upload_file_by_url($img);
            $post = get_post($pid);

            return $post;
        }
        return 'no url !';
    }

    public function authenticate_simple_token()
    {
        error_reporting(0);
        $opt = get_option("moopress_api_info", '');
        $wordpress_token = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $wordpress_token = @$settings['wordpress_token'];
        }
        $headers = BaseHelper::get_request_headers();
        $wp_auth_token = $headers['Wp-Auth-Token'];
        if ($wordpress_token != $wp_auth_token) {
            return new \WP_Error('rest_forbidden', esc_html__('You are not authenticated !'), array('status' => 401));
        }
        return true;
    }
    public function test_connection()
    {
        error_reporting(0);
        return true;
    }
    public function delete_course()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        if (
            !$data['course_id']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $last_course = CourseApiModel::getCourseByMdlId($data['course_id']);
        if ($last_course) {
            $post_wp_id = CourseApiModel::deleteCourse((int)$data['course_id']);
            return $post_wp_id;
        }
    }

    public function update_course()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));

        //validate data
        if (
            !$data['course_id'] ||
            !$data['course_name'] ||
            !$data['category'] ||
            !$data['course_shortname'] ||
            !$data['startdate'] ||
            !$data['enddate'] 
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $last_course = CourseApiModel::getCourseByMdlId($data['course_id']);
        $last_course_trashed = CourseApiModel::getCourseByMdlId($data['course_id'], true);
        $data['course_name'] = trim($data['course_name']);
        if ($last_course_trashed) {
            if (CourseApiModel::getCourseBytitle($data['course_name'])) {
                return new \WP_Error('rest_process_data', esc_html__('The course name is registered before !'), array('status' => 422));
            }
            $post_wp_id = CourseApiModel::updateCourse($data, (int)$data['course_id'], true);
            return $post_wp_id;
        } elseif (!$last_course) {
            if (CourseApiModel::getCourseBytitle($data['course_name'])) {
                return new \WP_Error('rest_process_data', esc_html__('The course name is registered before !'), array('status' => 422));
            }
            $post_wp_id = CourseApiModel::createCourse($data);
            return $post_wp_id;
        } else {
            $last_title = trim($last_course->post_title);

            if (CourseApiModel::getCourseBytitle($data['course_name']) && $data['course_name'] != $last_title) {
                return new \WP_Error('rest_process_data', esc_html__('The course name is registered before !'), array('status' => 422));
            }
            $post_wp_id = CourseApiModel::updateCourse($data, (int)$data['course_id']);
            return $post_wp_id;
        }
    }
    public function update_course_cost()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        if (
            !$data['course_id'] ||
            !$data['cost']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $last_course = CourseApiModel::getCourseByMdlId($data['course_id']);
        if ($last_course) {
            $product_id = $last_course->ID;
            $post_wp_id = CourseApiModel::updateCourseCost((int)$data['cost'], (int)$product_id);
            return $post_wp_id;
        } else {
            return 0;
        }
    }
    public function role_assign_user_course()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        //validate data
        if (
            !$data['course_moodle_id'] ||
            !$data['role_moodle_id'] ||
            !$data['user']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $user_assigned = (array)$data['user'];
        $role_moodle_title = "";
        $course_moodle_id = (int)$data['course_moodle_id'];
        $role_moodle_id = (int)$data['role_moodle_id'];
        $user_moodle_id = (int)$user_assigned['id'];
        //create user if not exists
        $rpt_user = UserApiModel::createUserInWpViaMoodle($user_assigned);
        //get roles to get posted role title 
        $roles = (array)MoodleController::get_roles();
        foreach ($roles as $role_item) {
            $role_item = (array)$role_item;
            if ((int)$role_item['id'] == $role_moodle_id) {
                $role_moodle_title = $role_item['shortname'];
            }
        }
        //enrol user record
        EnrollHelper::enroll_user_in_course__moodle($user_moodle_id, $course_moodle_id, $role_moodle_id, $role_moodle_title, 0);
        return true;
    }
    public function role_unassign_user_course()
    {
        error_reporting(0);
        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
         //validate data
         if (
            !$data['course_moodle_id'] ||
            !$data['role_moodle_id'] ||
            !$data['user']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $user_assigned = (array)$data['user'];
        $course_moodle_id = (int)$data['course_moodle_id'];
        $role_moodle_id = (int)$data['role_moodle_id'];
        $user_moodle_id = (int)$user_assigned['id'];
        //unenrol user
        EnrollHelper::unenroll_user_from_course($user_moodle_id, $course_moodle_id, $role_moodle_id);
        return true;
    }
    public function create_course()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        //validate data
        if (
            !$data['course_id'] ||
            !$data['course_name'] ||
            !$data['category'] ||
            !$data['course_shortname'] ||
            !$data['startdate'] ||
            !$data['enddate'] 
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        //unique validation
        if (CourseApiModel::getCourseByMdlId($data['course_id'])) {
            return new \WP_Error('rest_process_data', esc_html__('This Moodle Course is registered before !'), array('status' => 422));
        }
        if (CourseApiModel::getCourseBytitle($data['course_name'])) {
            return new \WP_Error('rest_process_data', esc_html__('The course name is registered before !'), array('status' => 422));
        }
        $post_wp_id = CourseApiModel::createCourse($data);
        return $post_wp_id;
    }
    
    //methods for sync buttons !
    public function create_sync_course()
    {
        // error_reporting(0);
        // $headers = BaseHelper::get_request_headers();
        // $data = (array)unserialize(base64_decode($headers['Wp-Local-Data']));
        // $course_title = $data['fullname'];
        // $course_id = (int)$data['id'];
        // $course_mdl_id = $course_id;
        // $course_fetch = CourseApiModel::getCourseByMdlId($course_id);
        // $course_fetch_trashed = CourseApiModel::getCourseByMdlId($course_id, true);
        // $product_id = 0;

        // if ($course_fetch) {
        //     $product_id = $course_fetch->ID;
        //     $product_id = CourseApiModel::syncCourse_single($data, $product_id, $course_mdl_id);
        // } elseif ($course_fetch_trashed) {
        //     $product_id = $course_fetch->ID;
        //     $course_post = array(
        //         'ID'           => $product_id,
        //         'post_type' => 'product',
        //         'post_status' => 'draft',
        //     );
        //     wp_update_post($course_post);
        //     $product_id = CourseApiModel::syncCourse_single($data, $product_id, $course_mdl_id);
        // } else {
        //     $product_id = CourseApiModel::createCourse_local($data);
        // }

        // if ($product_id) {
        //     wp_send_json_success([
        //         'message' => "دوره <strong>$course_title</strong> همگام سازی شد ! "
        //     ], 200);
        // } else {
        //     wp_send_json_error([
        //         'message' => "دوره <strong>$course_title</strong> همگام سازی نشد ! "
        //     ], 500);
        // }
    }
    public function create_sync_category()
    {
        // error_reporting(0);
        // $headers = BaseHelper::get_request_headers();
        // $data = unserialize(base64_decode($headers['Wp-Local-Data']));
        // $cate_title =  $data['v'];
        // $cate_mdl_id =  $data['k'];
        // $term_id = CourseApiModel::createCourseCategoty($cate_title, '', $cate_mdl_id);
        // if ($term_id) {
        //     wp_send_json_success([
        //         'message' => "دسته بندی <strong>$cate_title</strong> همگام سازی شد ! "
        //     ], 200);
        // } else {
        //     wp_send_json_error([
        //         'message' => "دسته بندی <strong>$cate_title</strong> همگام سازی نشد ! "
        //     ], 500);
        // }
    }
}
