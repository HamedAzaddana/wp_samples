<?php

namespace LmskaranMoopress\Controllers\Api;

use WPMVC\MVC\Controller;


class ApiController extends Controller
{
    public function register_routes()
    {
        $course_api = new CourseController();
        $user_api = new UserController();
        $course_api->register_routes();
        $user_api->register_routes();
    }
}