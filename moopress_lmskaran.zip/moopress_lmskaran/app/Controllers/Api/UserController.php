<?php

namespace LmskaranMoopress\Controllers\Api;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;
use LmskaranMoopress\Controllers\Webservice\MoodleController;

class UserController extends Controller
{
    private $namespace;
    private $resource_name;
    // Here initialize our namespace and resource name.
    public function __construct()
    {
        $this->namespace     = '/moopress/v1';
        $this->resource_name = 'user';
    }

    // Register our routes.
    public function register_routes()
    {

        //remote moodle routes
        register_rest_route($this->namespace, '/' . $this->resource_name, array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'create_user'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
        register_rest_route($this->namespace, '/' . $this->resource_name . '/update', array(
            array(
                'methods'   => 'POST',
                'callback'  => array($this, 'update_user'),
                'permission_callback' => array($this, 'authenticate_simple_token'),
            )
        ));
    }

    public function authenticate_simple_token()
    {
        error_reporting(0);
        $opt = get_option("moopress_api_info", '');
        $wordpress_token = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $wordpress_token = @$settings['wordpress_token'];
        }
        $headers = BaseHelper::get_request_headers();
        $wp_auth_token = $headers['Wp-Auth-Token'];
        if ($wordpress_token != $wp_auth_token) {
            return new \WP_Error('rest_forbidden', esc_html__('You are not authenticated !'), array('status' => 401));
        }
        return true;
    }
    public function create_user()
    {
        error_reporting(0);

        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        //validate data
        if (
            !$data['user_mdl_id'] ||
            !$data['username'] ||
            !$data['firstname'] ||
            !$data['lastname'] ||
            !$data['email'] ||
            !$data['password']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        //unique validation
        if (UserApiModel::getUserByMdlId($data['user_mdl_id'])) {
            return new \WP_Error('rest_process_data', esc_html__('This Moodle User is registered before !'), array('status' => 422));
        }
        if (UserApiModel::getUserByUsername($data['username'])) {
            return new \WP_Error('rest_process_data', esc_html__('The User `username` is registered before !'), array('status' => 422));
        }
        if (UserApiModel::getUserByEmail($data['email'])) {
            return new \WP_Error('rest_process_data', esc_html__('The User `email` is registered before !'), array('status' => 422));
        }
        $user_wp_id = UserApiModel::createUserInWpViaMoodleApi($data);
        return $user_wp_id;
    }
    public function update_user()
    {
        error_reporting(0);
        $requests = Request::all();
        $data = unserialize(urldecode(base64_decode($requests['data'])));
        //validate data
        if (
            !$data['user_mdl_id'] ||
            !$data['username'] ||
            !$data['firstname'] ||
            !$data['lastname'] ||
            !$data['email']
        ) {
            return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
        }
        $last_user = UserApiModel::getUserByMdlId($data['user_mdl_id']);

        if (!$last_user) {
            //unique validation
            if (UserApiModel::getUserByUsername($data['username'])) {
                return new \WP_Error('rest_process_data', esc_html__('The User `username` is registered before !'), array('status' => 422));
            }
            if (UserApiModel::getUserByEmail($data['email'])) {
                return new \WP_Error('rest_process_data', esc_html__('The User `email` is registered before !'), array('status' => 422));
            }
            if (!$data['password']) {
                return new \WP_Error('rest_process_data', esc_html__('You missed some required data !'), array('status' => 422));
            }
            $user_wp_id = UserApiModel::createUserInWpViaMoodleApi($data);
            return $user_wp_id;
        } else {
            $last_username = $last_user->data->user_login;
            $last_email = $last_user->data->user_email;
            $last_user__mdl_id = (int)@$last_user->ID;
            if (UserApiModel::getUserByUsername($data['username'])  && $data['username'] != $last_username) {
                return new \WP_Error('rest_process_data', esc_html__('The User `username` is registered before !'), array('status' => 422));
            }
            if (UserApiModel::getUserByEmail($data['email']) && $data['email'] != $last_email) {
                return new \WP_Error('rest_process_data', esc_html__('The User `email` is registered before !'), array('status' => 422));
            }
            $user_wp_id = UserApiModel::updateUserInWpViaMoodleApi($data);
            return $user_wp_id;
        }
    }
}
