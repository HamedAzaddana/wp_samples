<?php

namespace LmskaranMoopress\Controllers\Webservice;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Helpers\Base;

class BaseController extends Controller
{

    public static function test_connection()
    {
        $criteria = [];
        $data = array('criteria' => array($criteria));
        $responce = self::request_moodle($data, "core_course_get_categories");
        if (!isset($responce->errorcode) && $responce) {
            return true;
        } else {
            return false;
        }
    }


    private static function request_moodle($data, $function_name)
    {
        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        $moodle_token = '';
        $role_id_student = 5;

        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
            $moodle_token = @$settings['moodle_token'];
            $role_id_student = @$settings['role_id_student'] ? @$settings['role_id_student'] : $role_id_student;
        }
        $domainname = $moodle_url;
        $token = $moodle_token;
        $restformat = 'json';
        $functionname = $function_name;
        $serverurl = $domainname . 'webservice/rest/server.php' . '?wstoken=' . $token . '&wsfunction=' . $functionname;
        $restformat = ($restformat == 'json') ? '&moodlewsrestformat=' . $restformat : '';
        $handler = curl_init();
        ob_start();
        curl_setopt($handler, CURLOPT_URL, $serverurl . $restformat);
        curl_setopt($handler, CURLOPT_POST, true);
        curl_setopt($handler, CURLOPT_POSTFIELDS, http_build_query($data));
        $response = curl_exec($handler);
        curl_close($handler);
        $cont = ob_get_contents();
        ob_end_clean();
        $body_echo = json_decode($cont);
        return $body_echo;
    }
}
