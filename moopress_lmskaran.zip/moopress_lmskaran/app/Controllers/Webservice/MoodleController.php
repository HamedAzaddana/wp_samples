<?php

namespace LmskaranMoopress\Controllers\Webservice;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Helpers\Base;

class MoodleController extends Controller
{

    public static function test_connection()
    {
        $criteria = [];
        $data = array('criteria' => array($criteria));
        $responce = self::request_moodle($data, "core_course_get_categories");
        if (!isset($responce->errorcode) && $responce) {
            return true;
        } else {
            return false;
        }
    }
    public static function register_user($user_wp_id)
    {
        $user_wp = get_user_by('id', $user_wp_id);

        $user = new \stdClass();

        $user->username = $user_wp->data->user_login;
        $user->email = $user_wp->data->user_email;
        $user->lastname = get_user_meta($user_wp_id, 'last_name', true);
        $user->firstname = get_user_meta($user_wp_id, 'first_name', true);
        $user->password = get_user_meta($user_wp_id, md5('pwdsaltmdl'), true);
        $user = array($user);
        $data = array('users' => $user);
        $responce = self::request_moodle($data, "core_user_create_users");
        if (!isset($responce->errorcode)) {
            $user_mdl_id = $responce[0]->id;
            update_user_meta($user_wp_id, 'user_id_mdl', sanitize_text_field($user_mdl_id));
            return $user_mdl_id;
        } else {
            return 0;
        }
    }
    public static function update_user($user_wp_id)
    {
        $user_wp = get_user_by('id', $user_wp_id);

        $user = new \stdClass();
        $user_id_mdl = (int)get_user_meta($user_wp_id, 'user_id_mdl', true);
        if ($user_id_mdl) {
            $user->id = $user_id_mdl;
            $function_name = "core_user_update_users";
        } else {
            $function_name = "core_user_create_users";
        }
        $b_lastname = get_user_meta($user_wp_id, 'billing_last_name', true);
        $b_firstname = get_user_meta($user_wp_id, 'billing_first_name', true);

        $m_lastname = get_user_meta($user_wp_id, 'last_name', true);
        $m_firstname = get_user_meta($user_wp_id, 'first_name', true);

        $user->username = $user_wp->data->user_login;
        $user->email = $user_wp->data->user_email;
        $user->lastname = $m_lastname ? $m_lastname : $b_lastname;
        $user->firstname = $m_firstname ? $m_firstname : $b_firstname;
        $user->password = get_user_meta($user_wp_id, md5('pwdsaltmdl'), true);
        $user = array($user);
        $data = array('users' => $user);

        $responce = self::request_moodle($data, $function_name);
        // Base::dd($responce);
        // Base::dd($function_name);
        // Base::dd($data);
        // die;

        if ($function_name == 'core_user_update_users') {
            if (!isset($responce->errorcode)) {
                return $user_id_mdl;
            } else {
                return 0;
            }
        } else {
            if (!isset($responce->errorcode)) {
                $user_mdl_id = $responce[0]->id;
                update_user_meta($user_wp_id, 'user_id_mdl', sanitize_text_field($user_mdl_id));
                return $user_mdl_id;
            } else {
                return 0;
            }
        }
    }
    public static function reset_passwd_user($user_wp_id)
    {
        $user_wp = get_user_by('id', $user_wp_id);

        $user = new \stdClass();
        $user_id_mdl = (int)get_user_meta($user_wp_id, 'user_id_mdl', true);
        if ($user_id_mdl) {
            $user->id = $user_id_mdl;
            $function_name = "core_user_update_users";
        } else {
            $function_name = "core_user_create_users";
        }

        $user->password = get_user_meta($user_wp_id, md5('pwdsaltmdl'), true);
        $user = array($user);
        $data = array('users' => $user);
        $responce = self::request_moodle($data, $function_name);
        if ($function_name == 'core_user_update_users') {
            if (!isset($responce->errorcode)) {
                return 1;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
    public static function get_categories()
    {
        $criteria = [];
        $data = array('criteria' => array($criteria));
        $responce = self::request_moodle($data, "core_course_get_categories");
        $cates = [];
        $cates["0"] = "هیچ یک";
        if (!isset($responce->errorcode) && $responce) {
            foreach ($responce as $item) {
                $key = $item->id;
                $cates["$key"] = $item->name;
            }
        }
        return  $cates;
    }
    public static function get_courses($cid = 0)
    {

        $data = [];
        $courses = self::request_moodle($data, "core_course_get_courses");
        if ($cid) {
            $course = [];
            foreach ($courses as $course_item) {
                $course_item = (array)$course_item;
                if ((int)$course_item['id'] == (int)$cid) {
                    $course = $course_item;
                }
            }
            return $course;
        }
        return  $courses;
    }
    public static function get_course_details($cid = 0, $uid = 0)
    {
        $function_name = "moojla_get_course_contents";
        $data = array('courseid' => $cid);
        if ($uid) {
            $data['userid'] = $uid;
        }
        $responce = self::request_moodle($data, $function_name);
        return $responce;
    }
    public static function delete_user($uid)
    {
        $function_name = "core_user_delete_users";
        $data = array('userids' => [$uid]);
        $responce = self::request_moodle($data, $function_name);
        return $responce;
    }
    public static function get_courses_moojla($cid = 0)
    {
        $function_name = "moojla_get_courses";
        $data = array();
        $courses = self::request_moodle($data, $function_name);
        if ($cid) {
            $course = [];
            foreach ($courses as $course_item) {
                $course_item = (array)$course_item;
                if ((int)$course_item['id'] == (int)$cid) {
                    $course = $course_item;
                }
            }
            return $course;
        }
        return $courses;
    }
    public static function get_users_by_field($fld, $val)
    {
        $function_name = "moojla_user_get_users_by_field";
        $data = array(
            'field' => $fld,
            'values' => $val,
        ); //\'id\' or \'idnumber\' or \'username\' or \'email\'
        $users = self::request_moodle($data, $function_name);

        return $users;
    }
    public static function get_roles()
    {
        $function_name = "local_wsgetroles_get_roles";
        $data = array();
        $roles = self::request_moodle($data, $function_name);

        return $roles;
    }
    public static function get_course_participants_ids($cid)
    {
        $function_name = "moojla_get_multiple_course_users";
        $data = array(
            'courseids' => array(
                array("id" => $cid)
            )
        );
        $roles = self::request_moodle($data, $function_name);

        return $roles;
    }
    public static function get_course_complete_percentages($cid = 0, $uid = 0)
    {
        $function_name = "moojla_get_course_progress_percentage";
        $data = array(
            'courseid' => $cid,
            'userid' => $uid,
        );
        $responce = self::request_moodle($data, $function_name);
        return (int)$responce->percentage;
    }
    public static function enroll_user_course($userid, $courseid, $roleid)
    {
        $function_name = "moojla_enrol_user";
        $enrolment = new \stdClass();
        $enrolment->roleid = $roleid;
        $enrolment->userid = $userid;
        $enrolment->courseid = $courseid;
        $enrolments = array($enrolment);
        $data = array('enrolments' => $enrolments);
        $r = self::request_moodle($data, $function_name);
        return $r;
    }
    public static function unenroll_user_course($userid, $courseid, $roleid)
    {
        $function_name = "moojla_unenrol_user_enrolment";
        $data = array(
            'userid' => $userid,
            'courseid' => $courseid,
            'roleid' => $roleid,
        );
        $r = self::request_moodle($data, $function_name);
        return $r;
    }
    public static function update_create_course($post_id)
    {
        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }

        $data = [];
        $_action_moodle = "";
        $course_mdl_id = (int)get_post_meta($post_id, 'course_id_mdl', true);
        if ($course_mdl_id) {
            $_action_moodle = "core_course_update_courses";
        } else {
            $_action_moodle = "core_course_create_courses";
        }
        $function_name = $_action_moodle;
        $product_wp   = get_post($post_id);
        $fullname = $product_wp->post_title;
        $shortname = get_post_meta($post_id, 'short_name_course_mdl', true);
        $categoryid = (int)get_post_meta($post_id, 'category_course_mdl', true);
        $summary = strip_shortcodes($product_wp->post_content);
        $begin_date_course_mdl_jalali = get_post_meta($post_id, 'begin_date_course_mdl_jalali', true);
        $end_date_course_mdl_jalali = get_post_meta($post_id, 'end_date_course_mdl_jalali', true);

        $begin_date_course_mdl_pers_ymd = explode("/", $begin_date_course_mdl_jalali);
        $end_date_course_mdl_pers_ymd = explode("/", $end_date_course_mdl_jalali);

        if (
            $begin_date_course_mdl_pers_ymd 
        ) {
            $begin_ymd = moopress_jalali_to_gregorian(
                $begin_date_course_mdl_pers_ymd[0],
                $begin_date_course_mdl_pers_ymd[1],
                $begin_date_course_mdl_pers_ymd[2]
            );
        }

        if (
            $end_date_course_mdl_pers_ymd
        ) {
            $end_ymd = moopress_jalali_to_gregorian(
                $end_date_course_mdl_pers_ymd[0],
                $end_date_course_mdl_pers_ymd[1],
                $end_date_course_mdl_pers_ymd[2]
            );
        }

        $begin_timestamp = strtotime("$begin_ymd[0]-$begin_ymd[1]-$begin_ymd[2] 0:0:1");
        $end_timestamp = strtotime("$end_ymd[0]-$end_ymd[1]-$end_ymd[2] 3:0:1");
        update_post_meta($post_id, 'begin_date_course_mdl_timestamp', $begin_timestamp);
        update_post_meta($post_id, 'end_date_course_mdl_timestamp', $end_timestamp);

        $customfields = [];
        $cfd1 = get_post_meta($post_id, 'custom_fields_low_moodle', true);
        $cfd2 = get_post_meta($post_id, 'custom_fields_high_moodle', true);
        $cfd3 = get_post_meta($post_id, 'custom_fields_date_moodle', true);
        $all_cfds = array_merge($cfd1, $cfd2, $cfd3);
        // foreach ($all_cfds as $_cfd) {
        //     $customfields[] = [
        //         'shortname' => $_cfd['key_custom_fld'],
        //         'value' => $_cfd['value_custom_fld'],
        //     ];
        // }
        $course = new \stdClass();
        $course->fullname = sanitize_text_field($fullname);
        $course->shortname = sanitize_text_field($shortname);
        $course->categoryid = sanitize_text_field($categoryid);
        $course->summary = ($summary);
        $course->startdate = $begin_timestamp;
        $course->enddate = $end_timestamp;
        $course->customfields = $customfields;
        // return $course;

        if ($_action_moodle == "core_course_create_courses") {
            $course = array($course);
            $data = array('courses' => $course);
            $r = self::request_moodle($data, $function_name);
            if (!isset($r->errorcode) && $r) {
                $course_id_mdl = $r[0]->id;
                $course_moodle_url = $moodle_url . "course/view.php?id=" . $course_id_mdl;
                update_post_meta($post_id, 'course_id_mdl', $course_id_mdl);
                update_post_meta($post_id, 'course_moodle_url', $course_moodle_url);
            }
            return $r;
        }
        if ($_action_moodle == "core_course_update_courses") {
            $course->id = $course_mdl_id;
            $course = array($course);
            $data = array('courses' => $course);
            $r = self::request_moodle($data, $function_name);
            return $r;
        }
    }
    //utility functions
    private static function url_exists($url)
    {
        set_time_limit(20);
        return curl_init($url) !== false;
    }
    private static function request_moodle($data, $function_name)
    {
        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        $moodle_token = '';
        $role_id_student = 5;

        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
            $moodle_token = @$settings['moodle_token'];
            $role_id_student = @$settings['role_id_student'] ? @$settings['role_id_student'] : $role_id_student;
        }

        $domainname = $moodle_url;
        $token = $moodle_token;

        if (!self::url_exists($domainname)) {
            return false;
        }

        $restformat = 'json';
        $functionname = $function_name;
        $serverurl = $domainname . 'webservice/rest/server.php' . '?wstoken=' . $token . '&wsfunction=' . $functionname;
        $restformat = ($restformat == 'json') ? '&moodlewsrestformat=' . $restformat : '';
        $handler = curl_init();
        ob_start();
        curl_setopt($handler, CURLOPT_URL, $serverurl . $restformat);
        curl_setopt($handler, CURLOPT_POST, true);
        curl_setopt($handler, CURLOPT_POSTFIELDS, http_build_query($data));
        $response = curl_exec($handler);
        curl_close($handler);
        $cont = ob_get_contents();
        ob_end_clean();
        $body_echo = json_decode($cont);
        return $body_echo;
    }
}
