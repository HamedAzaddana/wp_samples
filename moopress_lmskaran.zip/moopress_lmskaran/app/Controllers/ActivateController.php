<?php

namespace LmskaranMoopress\Controllers;

use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use WPMVC\MVC\Controller;

class ActivateController
{
    public function init()
    {
        error_reporting(0);
        register_activation_hook(MOOPRESS_PLUGIN_FILE_MAIN,  [$this, 'moopress_daneh_activation']);
        register_deactivation_hook(MOOPRESS_PLUGIN_FILE_MAIN,  [$this, 'moopress_daneh_deactivation']);
    }
    public function moopress_daneh_activation()
    {
        $this->make_tables();
        $this->make_pages();
        flush_rewrite_rules();
    }
    public function moopress_daneh_deactivation()
    {
        flush_rewrite_rules();
    }
    public function make_pages()
    {
        //Make Quiz Moodle page
        $title_page= 'صفحه برگزاری آزمون - موپرس';
        $page_post = array(
            'post_title'    => ($title_page),
            'post_content'  => '[moopress_moodle_quiz_hold]',
            'post_status'   => 'publish',
            "post_name" => "moopress_moodle_quiz_hold",
            'post_author'   => 0,
            'post_type'     => 'page',
        );
        if (!post_exists($title_page, '', '', '')) {
            wp_insert_post($page_post, true);
        }
    }
    public function make_tables()
    {
        error_reporting(0);
        global $wpdb;
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        //moopress_enrolment 
        $tn = $wpdb->prefix . 'moopress_enrolment';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS `$tn`(
            `id`  BIGINT NOT NULL AUTO_INCREMENT,
            `user_moodle_id` BIGINT NOT NULL , 
            `course_moodle_id` BIGINT NOT NULL , 
            `role_moodle_id` BIGINT NOT NULL , 
            `role_moodle_title` VARCHAR(255) NOT NULL,
            `order_id` BIGINT NOT NULL , 
            `created_at` TIMESTAMP NULL DEFAULT NULL , 
            PRIMARY KEY (`id`),
            INDEX  (`user_moodle_id`),
            INDEX  (`course_moodle_id`),
            INDEX  (`role_moodle_id`)
            ) $charset_collate;";
        dbDelta($sql);
    }
}
