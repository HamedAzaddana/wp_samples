<?php

namespace LmskaranMoopress\Controllers;

use WPMVC\MVC\Controller;
use WPMVC\Request;
use LmskaranMoopress\Controllers\Helpers\Base;
use LmskaranMoopress\Controllers\Webservice\MoodleController;
use LmskaranMoopress\Models\CourseApi as CourseApiModel;
use LmskaranMoopress\Models\UserApi as UserApiModel;
use LmskaranMoopress\Controllers\Helpers\Enroll as EnrollHelper;

class AdminMenuController extends Controller
{
    public function show_menu()
    {
        add_menu_page(
            "موپرس",
            'موپرس',
            'manage_options',
            'lmskaran_moopress_settings',
            array($this, 'show_menu_view'),
            MOOPRSSS_APP_URL . "assets/img/menu-icon.png",
            6
        );
        add_submenu_page(
            'lmskaran_moopress_settings',
            'کاربران ثبت نام شده',
            'کاربران ثبت نام شده',
            'manage_options',
            'lmskaran_moopress_enrollments',
            array($this, 'show_menu_enrollments'),
        );
    }
    public function show_menu_enrollments()
    {
        $users_moodle = UserApiModel::getUsersMoodle();
        $this->view->show('show_menu_enrollments', [
            'users_moodle' => $users_moodle,
        ]);
    }

    public function sync_categories_handle($categories, $nextStartCountRate)
    {

        $requests = Request::all();
        $refresh_rate_process = 0;
        $offset_segment_into_slice = 0;
        $count_segment_into_slice = 0;
        $pause = (int)@$requests['pause'];
        $continue = (int)@$requests['continue'];

        if ($nextStartCountRate) {
            $categories_be_process = ($categories);
            $refresh_rate_process = (int)get_option('moopress_refresh_rate_process', 0);
            $offset_segment_into_slice = $nextStartCountRate;
            $count_segment_into_slice = $refresh_rate_process;
        } else {
            $offset_process = (int)@$requests['offset_process'];
            $count_process = (int)@$requests['count_process'];
            $refresh_rate_process = (int)@$requests['refresh_rate_process'];
            update_option('moopress_offset_process', $offset_process);
            update_option('moopress_count_process', $count_process);
            update_option('moopress_refresh_rate_process', $refresh_rate_process);
            update_option('moopress_completed_process_count', 0);
            $categories_be_process = array_slice($categories, $offset_process, $count_process);
            update_option('categories_be_process', $categories_be_process);
            $offset_segment_into_slice = 0;
            $count_segment_into_slice = $refresh_rate_process;
        }

        $categories_segment_from_slice = array_slice($categories_be_process, $offset_segment_into_slice, $count_segment_into_slice);
        $nextStepOffsetSegment = $nextStartCountRate + $count_segment_into_slice;

        if (!$pause && !$continue) {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0) + $count_segment_into_slice;
            update_option('moopress_completed_process_count', $new_completed_process);
        } else {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0);
        }


        $count_all_progress = count($categories_be_process);
        $completed_all_progress = ($new_completed_process);
        $sync_percentage = 0;
        if ($count_all_progress) {
            $sync_percentage = ($completed_all_progress * 100) / ($count_all_progress);
        }

        $link_cancel = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&view=sync_tables";
        if (!$pause && $sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-info notice-sync-progressing' style='padding:10px ;'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#020080;'></i>" . "<strong style='color: #ef4b4b;padding: 25px;'>فرایند همگام سازی در حال اجرا است ...</strong>" . "</div><br>";
        }

        if ($sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-warning'>" . "<i class='fa fa-hourglass-half' style='text-align: center;color:#00800c;'></i>" . "<strong style='color: #4b61ef;padding: 20px;'>تعداد انجام شده : $completed_all_progress</strong>" . "</div><br>";
            echo   "<div class='moopress-progress-sync-parent'><progress class='moopress-progress-sync' value='$sync_percentage' max='100'></progress></div>";
        } else {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-success'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#009688;'></i>" . "<strong style='color: #3f51b5;padding: 25px;'>در حال اتمام همگام سازی ...</strong>" . "</div><br>";
        }


        $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&nextStartCountRate=" . $nextStepOffsetSegment;
        $next_url .= "&type_sync_param=categories";
        $next_url .= "&view=sync_tables";
        $next_url .= "&all_cnt=$count_all_progress";
        $next_url .= "&cmpl_cnt=$completed_all_progress";
        $paused_url = $next_url . "&pause=1";
        $continue_url = $next_url . "&continue=1";
        if (!$pause) {
            echo   "<div style=''>" . "<strong>" . " 
            <button nc-url='$continue_url' bc-url='$paused_url' id='moopress_pause_sync_btn'  type='button'> <i class='fa fa-pause-circle-o'></i> توقف </button>
            " . "</strong>" . "</div><br>";
        }
        if ($pause) {
            echo   "<div style=''>" . "<strong>" . " 
        <button id='moopress_continue_sync_btn'  type='button'> <i class='fa fa-play-circle'></i> ادامه </button>
        " . "</strong>" . "</div><br>";
        }

        echo   "<div style=''>" . "<strong>" . " 
        <button bc-url='$link_cancel' id='moopress_cancel_sync_btn' style='padding: 10px;font-size: 15px;' type='button' class='btn-moopress-danger'> <i class='fa fa-stop-circle'></i> خروج </button>
        " . "</strong>" . "</div><br>";
        if (!$pause) {
            if ($categories_segment_from_slice) {
                foreach ($categories_segment_from_slice as $cate_item) {
                    $cate_title =  $cate_item['title'];
                    $cate_mdl_id =  (int)$cate_item['moodle_id'];
                    $term_id = CourseApiModel::createCourseCategoty($cate_title, '', $cate_mdl_id);
                    if ($term_id) {
                        echo   "<div class='notice notice-success is-dismissible' style='padding:10px ;'>" . "دسته بندی <strong>$cate_title</strong> همگام سازی شد !" . "</div><br>";
                    } else {
                        echo  "<div class='notice notice-error is-dismissible' style='padding:10px ;'>" . "دسته بندی <strong>$cate_title</strong> همگام سازی نشد !" . "</div><br>";
                    }
                }
                header("Refresh:2; url=$next_url");
            } else {
                $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings";
                $next_url .= "&view=sync_tables";
                $next_url .= "&all_cnt=$count_all_progress";
                $next_url .= "&cmpl_cnt=$completed_all_progress";
                header("Refresh:2; url=$next_url");
            }
        }
    }
    public function sync_courses_handle($courses, $nextStartCountRate)
    {
        $requests = Request::all();
        $view_type = @$requests['view'] ? $requests['view'] : "auth_webservice";
        $refresh_rate_process = 0;
        $offset_segment_into_slice = 0;
        $count_segment_into_slice = 0;
        $pause = (int)@$requests['pause'];
        $continue = (int)@$requests['continue'];
        if ($nextStartCountRate) {
            $courses_be_process = ($courses);
            $refresh_rate_process = (int)get_option('moopress_refresh_rate_process', 0);
            $offset_segment_into_slice = $nextStartCountRate;
            $count_segment_into_slice = $refresh_rate_process;
        } else {
            $offset_process = (int)@$requests['offset_process'];
            $count_process = (int)@$requests['count_process'];
            $refresh_rate_process = (int)@$requests['refresh_rate_process'];
            update_option('moopress_offset_process', $offset_process);
            update_option('moopress_count_process', $count_process);
            update_option('moopress_refresh_rate_process', $refresh_rate_process);
            update_option('moopress_completed_process_count', 0);
            $courses_be_process = array_slice($courses, $offset_process, $count_process);
            update_option('courses_be_process', $courses_be_process);
            $offset_segment_into_slice = 0;
            $count_segment_into_slice = $refresh_rate_process;
        }

        $courses_segment_from_slice = array_slice($courses_be_process, $offset_segment_into_slice, $count_segment_into_slice);
        $nextStepOffsetSegment = $nextStartCountRate + $count_segment_into_slice;

        if (!$pause && !$continue) {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0) + $count_segment_into_slice;
            update_option('moopress_completed_process_count', $new_completed_process);
        } else {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0);
        }

        $count_all_progress = count($courses_be_process);
        $completed_all_progress = ($new_completed_process);
        $sync_percentage = 0;
        if ($count_all_progress) {
            $sync_percentage = ($completed_all_progress * 100) / ($count_all_progress);
        }

        $link_cancel = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&view=sync_tables";
        if (!$pause && $sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-info notice-sync-progressing' style='padding:10px ;'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#020080;'></i>" . "<strong style='color: #ef4b4b;padding: 25px;'>فرایند همگام سازی در حال اجرا است ...</strong>" . "</div><br>";
        }

        if ($sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-warning'>" . "<i class='fa fa-hourglass-half' style='text-align: center;color:#00800c;'></i>" . "<strong style='color: #4b61ef;padding: 20px;'>تعداد انجام شده : $completed_all_progress</strong>" . "</div><br>";
            echo   "<div class='moopress-progress-sync-parent'><progress class='moopress-progress-sync' value='$sync_percentage' max='100'></progress></div>";
        } else {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-success'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#009688;'></i>" . "<strong style='color: #3f51b5;padding: 25px;'>در حال اتمام همگام سازی ...</strong>" . "</div><br>";
        }


        $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&nextStartCountRate=" . $nextStepOffsetSegment;
        $next_url .= "&type_sync_param=courses";
        $next_url .= "&view=sync_tables";
        $next_url .= "&all_cnt=$count_all_progress";
        $next_url .= "&cmpl_cnt=$completed_all_progress";
        $paused_url = $next_url . "&pause=1";
        $continue_url = $next_url . "&continue=1";
        if (!$pause) {
            echo   "<div style=''>" . "<strong>" . " 
            <button nc-url='$continue_url' bc-url='$paused_url' id='moopress_pause_sync_btn'  type='button'> <i class='fa fa-pause-circle-o'></i> توقف </button>
            " . "</strong>" . "</div><br>";
        }
        if ($pause) {
            echo   "<div style=''>" . "<strong>" . " 
        <button id='moopress_continue_sync_btn'  type='button'> <i class='fa fa-play-circle'></i> ادامه </button>
        " . "</strong>" . "</div><br>";
        }

        echo   "<div style=''>" . "<strong>" . " 
        <button bc-url='$link_cancel' id='moopress_cancel_sync_btn' style='padding: 10px;font-size: 15px;' type='button' class='btn-moopress-danger'> <i class='fa fa-stop-circle'></i> خروج </button>
        " . "</strong>" . "</div><br>";
        if (!$pause) {
            if ($courses_segment_from_slice) {
                foreach ($courses_segment_from_slice as $course_item) {
                    $course_item = (array)$course_item;

                    $course_title = $course_item['fullname'];
                    $course_id = (int)$course_item['id'];
                    $course_mdl_id = $course_id;
                    $course_fetch = CourseApiModel::getCourseByMdlId($course_id);
                    $course_fetch_trashed = CourseApiModel::getCourseByMdlId($course_id, true);
                    $product_id = 0;

                    if ($course_fetch) {
                        $product_id = $course_fetch->ID;
                        $product_id = CourseApiModel::syncCourse_single($course_item, $product_id, $course_mdl_id);
                    } elseif ($course_fetch_trashed) {
                        $product_id = $course_fetch->ID;
                        $course_post = array(
                            'ID'           => $product_id,
                            'post_type' => 'product',
                            'post_status' => 'draft',
                        );
                        wp_update_post($course_post);
                        $product_id = CourseApiModel::syncCourse_single($course_item, $product_id, $course_mdl_id);
                    } else {
                        $product_id = CourseApiModel::createCourse_local($course_item);
                    }

                    if ($product_id) {
                        echo   "<div class='notice notice-success is-dismissible' style='padding:10px ;'>" . "دوره <strong>$course_title</strong> همگام سازی شد ! " . "</div><br>";
                    } else {
                        echo  "<div class='notice notice-error is-dismissible' style='padding:10px ;'>" . "دوره <strong>$course_title</strong> همگام سازی نشد ! " . "</div><br>";
                    }
                }

                header("Refresh:2; url=$next_url");
            } else {
                $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings";
                $next_url .= "&view=sync_tables";
                $next_url .= "&all_cnt=$count_all_progress";
                $next_url .= "&cmpl_cnt=$completed_all_progress";
                header("Refresh:2; url=$next_url");
            }
        }
    }
    public function sync_users_handle($users, $nextStartCountRate)
    {
        $requests = Request::all();
        $view_type = @$requests['view'] ? $requests['view'] : "auth_webservice";
        $refresh_rate_process = 0;
        $offset_segment_into_slice = 0;
        $count_segment_into_slice = 0;
        $pause = (int)@$requests['pause'];
        $continue = (int)@$requests['continue'];

        if ($nextStartCountRate) {
            $users_be_process = ($users);
            $refresh_rate_process = (int)get_option('moopress_refresh_rate_process', 0);
            $offset_segment_into_slice = $nextStartCountRate;
            $count_segment_into_slice = $refresh_rate_process;
        } else {
            $offset_process = (int)@$requests['offset_process'];
            $count_process = (int)@$requests['count_process'];
            $refresh_rate_process = (int)@$requests['refresh_rate_process'];
            update_option('moopress_offset_process', $offset_process);
            update_option('moopress_count_process', $count_process);
            update_option('moopress_refresh_rate_process', $refresh_rate_process);
            update_option('moopress_completed_process_count', 0);
            $users_be_process = array_slice($users, $offset_process, $count_process);
            update_option('users_be_process', $users_be_process);
            $offset_segment_into_slice = 0;
            $count_segment_into_slice = $refresh_rate_process;
        }

        $users_segment_from_slice = array_slice($users_be_process, $offset_segment_into_slice, $count_segment_into_slice);
        $nextStepOffsetSegment = $nextStartCountRate + $count_segment_into_slice;


        if (!$pause && !$continue) {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0) + $count_segment_into_slice;
            update_option('moopress_completed_process_count', $new_completed_process);
        } else {
            $new_completed_process = (int)get_option('moopress_completed_process_count', 0);
        }

        $count_all_progress = count($users_be_process);
        $completed_all_progress = ($new_completed_process);
        $sync_percentage = 0;
        if ($count_all_progress) {
            $sync_percentage = ($completed_all_progress * 100) / ($count_all_progress);
        }
        $link_cancel = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&view=sync_tables";
        if (!$pause && $sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-info notice-sync-progressing' style='padding:10px ;'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#020080;'></i>" . "<strong style='color: #ef4b4b;padding: 25px;'>فرایند همگام سازی در حال اجرا است ...</strong>" . "</div><br>";
        }
        if ($sync_percentage < 100) {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-warning'>" . "<i class='fa fa-hourglass-half' style='text-align: center;color:#00800c;'></i>" . "<strong style='color: #4b61ef;padding: 20px;'>تعداد انجام شده : $completed_all_progress</strong>" . "</div><br>";
            echo   "<div class='moopress-progress-sync-parent'><progress class='moopress-progress-sync' value='$sync_percentage' max='100'></progress></div>";
        } else {
            echo   "<div style='padding: 20px;font-size: 20px;' class='notice notice-success'>" . "<i class='fa fa-spin fa-refresh' style='text-align: center;color:#009688;'></i>" . "<strong style='color: #3f51b5;padding: 25px;'>در حال اتمام همگام سازی ...</strong>" . "</div><br>";
        }


        $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings&nextStartCountRate=" . $nextStepOffsetSegment;
        $next_url .= "&type_sync_param=users";
        $next_url .= "&view=sync_tables";
        $next_url .= "&all_cnt=$count_all_progress";
        $next_url .= "&cmpl_cnt=$completed_all_progress";
        $paused_url = $next_url . "&pause=1";
        $continue_url = $next_url . "&continue=1";
        if (!$pause) {
            echo   "<div style=''>" . "<strong>" . " 
            <button nc-url='$continue_url' bc-url='$paused_url' id='moopress_pause_sync_btn'  type='button'> <i class='fa fa-pause-circle-o'></i> توقف </button>
            " . "</strong>" . "</div><br>";
        }
        if ($pause) {
            echo   "<div style=''>" . "<strong>" . " 
        <button id='moopress_continue_sync_btn'  type='button'> <i class='fa fa-play-circle'></i> ادامه </button>
        " . "</strong>" . "</div><br>";
        }

        echo   "<div style=''>" . "<strong>" . " 
        <button bc-url='$link_cancel' id='moopress_cancel_sync_btn' style='padding: 10px;font-size: 15px;' type='button' class='btn-moopress-danger'> <i class='fa fa-stop-circle'></i> خروج </button>
        " . "</strong>" . "</div><br>";
        if (!$pause) {
            if ($users_segment_from_slice) {
                foreach ($users_segment_from_slice as $user_item) {
                    $user_wp_id = $user_item->ID;
                    $user_lastname = get_user_meta($user_wp_id, 'last_name', true);
                    $user_firstname = get_user_meta($user_wp_id, 'first_name', true);
                    $fullname = $user_firstname . " " . $user_lastname;
                    $uid = UserApiModel::syncUser_single($user_wp_id);


                    if ($uid) {
                        echo   "<div class='notice notice-success is-dismissible' style='padding:10px ;'>" . "کاربر <strong>$fullname</strong> همگام سازی شد ! " . "</div><br>";
                    } else {
                        echo  "<div class='notice notice-error is-dismissible' style='padding:10px ;'>" . "کاربر <strong>$fullname</strong> همگام سازی نشد ! " . "</div><br>";
                    }
                }

                header("Refresh:2; url=$next_url");
            } else {
                $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings";
                $next_url .= "&view=sync_tables";
                $next_url .= "&all_cnt=$count_all_progress";
                $next_url .= "&cmpl_cnt=$completed_all_progress";
                header("Refresh:2; url=$next_url");
            }
        }
    }
    public function show_menu_view()
    {

        //save setitings for moopress connection
        $requests = Request::all();
        if (
            $_SERVER['REQUEST_METHOD'] === 'POST'
            && !@$requests['type_sync_param']
        ) {
            $this->show_menu_handle($requests);
        }
        //start sync loop
        if (
            @$requests['type_sync_param'] == "categories"
        ) {
            // $token = @$requests['wordpress_token_local'];

            $nextStartCountRate = (int)@$requests['nextStartCountRate'];
            $categories = [];
            if ($nextStartCountRate) {
                $categories_save = get_option('categories_be_process', []);
            } else {
                $categories = MoodleController::get_categories();
                $categories_save = [];
                foreach ($categories as $cate_k => $cate_v) {
                    $cateArray = [];
                    $cateArray['title'] = $cate_v;
                    $cateArray['moodle_id'] = (int)$cate_k;
                    $categories_save[] = $cateArray;
                }
            }

            $this->sync_categories_handle($categories_save, $nextStartCountRate);
        }
        if (
            @$requests['type_sync_param'] == "courses"
        ) {
            // $token = @$requests['wordpress_token_local'];
            $nextStartCountRate = (int)@$requests['nextStartCountRate'];
            if ($nextStartCountRate) {
                $courses_save = get_option('courses_be_process', []);
            } else {
                $courses_save = MoodleController::get_courses();
            }

            $this->sync_courses_handle($courses_save, $nextStartCountRate);
        }
        if (
            @$requests['type_sync_param'] == "users"
        ) {
            // $token = @$requests['wordpress_token_local'];
            $nextStartCountRate = (int)@$requests['nextStartCountRate'];
            if ($nextStartCountRate) {
                $users_save = get_option('users_be_process', []);
            } else {
                $users_save = get_users();
            }

            $this->sync_users_handle($users_save, $nextStartCountRate);
        }

        $view_type = @$requests['view'] ? $requests['view'] : "auth_webservice";
        $nextStartCountRate = @$requests['nextStartCountRate'] ? (int)$requests['nextStartCountRate'] : 0;
        $begin_sync = @$requests['begin_sync'] ? (int)$requests['begin_sync'] : 0;

        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        $moodle_token = '';
        $wordpress_token = '';
        $role_id_student = 5;
        $force_delete_api = 0;
        $force_content_api = 0;
        $force_title_api = 0;
        $force_course_published = 0;
        $order_enrol_status = '';
        $elementor_library_header_id = 0;
        $elementor_library_footer_id = 0;

        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
            $moodle_token = @$settings['moodle_token'];
            $wordpress_token = @$settings['wordpress_token'];
            $role_id_student = @$settings['role_id_student'] ? @$settings['role_id_student'] : $role_id_student;
            $force_delete_api = (int)@$settings['force_delete_api'] ? 1 : 0;
            $force_content_api = (int)@$settings['force_content_api'] ? 1 : 0;
            $force_title_api = (int)@$settings['force_title_api'] ? 1 : 0;
            $force_course_published = (int)@$settings['force_course_published'] ? 1 : 0;
            $order_enrol_status = @$settings['order_enrol_status'] ? $settings['order_enrol_status'] : '';
            $elementor_library_header_id = (int)@$settings['elementor_library_header_id'];
            $elementor_library_footer_id = (int)@$settings['elementor_library_footer_id'];


        }
        $token_be = Base::random_hash(15);
        $moodle_url_settings = $moodle_url . "admin/settings.php?section=authsettingmoojla";

        $elementor_library_templates = Base::get_elementor_library_templates();

     


        $this->view->show('show_menu_moopress', [
            'moodle_url' => $moodle_url,
            'view_type' => $view_type,
            'moodle_token' => $moodle_token,
            'wordpress_token' => $wordpress_token,
            'moodle_url_settings' => $moodle_url_settings,
            'role_id_student' => $role_id_student,
            'token_be' => $token_be,
            'force_delete_api' => $force_delete_api,
            'force_content_api' => $force_content_api,
            'force_title_api' => $force_title_api,
            'force_course_published' => $force_course_published,
            'order_enrol_status' => $order_enrol_status,
            'elementor_library_header_id' => $elementor_library_header_id,
            'elementor_library_footer_id' => $elementor_library_footer_id,
            'nextStartCountRate' => $nextStartCountRate,
            'begin_sync' => $begin_sync,
            'elementor_library_templates' => $elementor_library_templates,
        ]);
    }

    public function show_menu_handle($requests)
    {
        $opt = get_option("moopress_api_info", '');
        $moodle_url_last = '';
        $moodle_token_last = '';
        $wordpress_token_last = '';
        $role_id_student_last = 5;
        $force_delete_api_last = 0;
        $force_content_api_last = 0;
        $force_title_api_last = 0;
        $force_course_published_last = 0;
        $order_enrol_status = '';
        $elementor_library_header_id = 0;
        $elementor_library_footer_id = 0;

        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url_last = @$settings['moodle_url'];
            $moodle_token_last = @$settings['moodle_token'];
            $wordpress_token_last = @$settings['wordpress_token'];
            $role_id_student_last = @$settings['role_id_student'] ? @$settings['role_id_student'] : $role_id_student_last;
            $force_delete_api_last = (int)@$settings['force_delete_api'] ? 1 : 0;
            $force_content_api_last = (int)@$settings['force_content_api'] ? 1 : 0;
            $force_title_api_last = (int)@$settings['force_title_api'] ? 1 : 0;
            $force_course_published_last = (int)@$settings['force_course_published'] ? 1 : 0;
            $order_enrol_status_last = @$settings['order_enrol_status'] ? $settings['order_enrol_status'] : '';
            $elementor_library_header_id_last = (int)@$settings['elementor_library_header_id'];
            $elementor_library_footer_id_last = (int)@$settings['elementor_library_footer_id'];
        }


        $view_type = @$requests['view'] ? $requests['view'] : "auth_webservice";

        if ($view_type == "auth_webservice") {
            $moodle_url = @$requests['moodle_url'];
            $moodle_token = @$requests['moodle_token'];
            $wordpress_token = @$requests['wordpress_token'];
        } else {
            $moodle_url =  $moodle_url_last;
            $moodle_token =  $moodle_token_last;
            $wordpress_token =  $wordpress_token_last;
        }

        if ($view_type == "other_settings") {
            $role_id_student = (int)@$requests['role_id_student'];
            $force_delete_api = (int)@$requests['force_delete_api'] ? 1 : 0;
            $force_content_api = (int)@$requests['force_content_api'] ? 1 : 0;
            $force_title_api = (int)@$requests['force_title_api'] ? 1 : 0;
            $force_title_api = (int)@$requests['force_title_api'] ? 1 : 0;
            $force_course_published = (int)@$requests['force_course_published'] ? 1 : 0;
            $order_enrol_status = @$requests['order_enrol_status'] ? $requests['order_enrol_status'] : '';
            $elementor_library_header_id = (int)@$requests['elementor_library_header_id'];
            $elementor_library_footer_id = (int)@$requests['elementor_library_footer_id'];

        } else {
            $role_id_student =  $role_id_student_last;
            $force_delete_api = $force_delete_api_last;
            $force_content_api =  $force_content_api_last;
            $force_title_api = $force_title_api_last;
            $force_course_published = $force_course_published_last;
            $force_course_published = $force_course_published_last;
            $order_enrol_status = $order_enrol_status_last;
            $elementor_library_header_id = $elementor_library_header_id_last;
            $elementor_library_footer_id = $elementor_library_footer_id_last;
        }

        $moopress_api_info = base64_encode(serialize([
            'moodle_url' => $moodle_url,
            'moodle_token' => $moodle_token,
            'wordpress_token' => $wordpress_token,
            'role_id_student' => $role_id_student,
            'force_delete_api' => $force_delete_api,
            'force_content_api' => $force_content_api,
            'force_title_api' => $force_title_api,
            'force_course_published' => $force_course_published,
            'order_enrol_status' => $order_enrol_status,
            'elementor_library_header_id' => $elementor_library_header_id,
            'elementor_library_footer_id' => $elementor_library_footer_id,
        ]));
        update_option('moopress_api_info', $moopress_api_info);
    }


    public function check_woocommerce()
    {

        if (!class_exists('WooCommerce')) {
            add_action('admin_notices',  array($this, 'lmskaran_moopress_error_notices'));
        }
    }
    public function lmskaran_moopress_error_notices()
    {
        $class = 'notice notice-error';
        $message = "افزونه Moopress کار نمی کند . افزونه ووکامرس باید فعال باشد .";

        printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
    }

    public function load_csrf_token()
    {

        $user_ip = $_SERVER['REMOTE_ADDR'];
        $salt_nonce_moopress = "csrf_of_moopress" . $user_ip . "OUIHJfvudgf*@&^#";

        wp_nonce_field($salt_nonce_moopress, 'Moopress_Csrf_Token');
    }
    public function swal_show_messages()
    {
        $requests = Request::all();
        $this->view->show('swal_show_messages', [
            'params' => $requests
        ]);
    }
}
