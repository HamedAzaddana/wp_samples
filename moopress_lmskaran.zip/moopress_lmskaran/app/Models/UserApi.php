<?php

namespace LmskaranMoopress\Models;

use WPMVC\MVC\Traits\FindTrait;
use WPMVC\MVC\Models\PostModel as Model;
use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Controllers\Webservice\MoodleController;


class UserApi extends Model
{
    use FindTrait;
    public static function syncUser_single($user_wp_id)
    {
        return MoodleController::update_user((int)$user_wp_id);
    }
    public static function getUserByMdlId($mdl_id)
    {

        $users = get_users(array(
            'meta_key' => 'user_id_mdl',
            'meta_value' => $mdl_id
        ));

        return @$users[0];
    }
    public static function getUserByUsername($username)
    {
        return get_user_by('login', $username);
    }
    public static function getUserByEmail($email)
    {
        return get_user_by('email', $email);
    }
    public static function getUsersMoodle()
    {
        $users = get_users(array(
            'meta_key' => 'user_id_mdl'
        ));
        return $users;
    }
    public static function createUserInWpViaMoodle($user)
    {
        $user = (array)$user;
        $user_id_mdl = (int)$user['id'];
        $db__user = self::getUserByMdlId($user_id_mdl);
        if (!$db__user) {
            $password = $user['username'];
            $user_id_wp = wp_create_user($user['username'], $password, $user['email']);
            update_user_meta((int)$user_id_wp, 'user_id_mdl', $user_id_mdl);
            update_user_meta((int)$user_id_wp, 'billing_first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'billing_last_name', $user['lastname']);
            update_user_meta((int)$user_id_wp, 'last_name', $user['lastname']);
            // update_user_meta((int)$user_id_wp, md5('pwdsaltmdl'), $password_raw);
            return (int)$user_id_wp;
        } else {
            return -1;
        }
    }
    public static function createUserInWpViaMoodleApi($user)
    {
        $user = (array)$user;
        $user_id_mdl = (int)$user['user_mdl_id'];
        $db__user = self::getUserByMdlId($user_id_mdl);
        if (!$db__user) {
            $password = @$user['password'];
            $user_id_wp = wp_create_user($user['username'], $password, $user['email']);
            update_user_meta((int)$user_id_wp, 'user_id_mdl', $user_id_mdl);
            update_user_meta((int)$user_id_wp, 'billing_first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'billing_last_name', $user['lastname']);
            update_user_meta((int)$user_id_wp, 'last_name', $user['lastname']);
            update_user_meta((int)$user_id_wp, md5('pwdsaltmdl'), $password);
            return (int)$user_id_wp;
        } else {
            return -1;
        }
    }
    public static function updateUserInWpViaMoodleApi($user)
    {
        $user = (array)$user;
        $user_id_mdl = (int)$user['user_mdl_id'];
        $db__user = self::getUserByMdlId($user_id_mdl);
        if ($db__user) {
            $user_id_wp = $db__user->ID;
            $password = @$user['password'];
            wp_update_user(array(
                'ID' => (int)$user_id_wp,
                'user_email' => $user['email'],
                'user_login' => $user['username'],
            ));
            if ($password) {
                wp_set_password( $password, (int)$user_id_wp );
                update_user_meta((int)$user_id_wp, md5('pwdsaltmdl'), $password);
            } 

            update_user_meta((int)$user_id_wp, 'billing_first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'first_name', $user['firstname']);
            update_user_meta((int)$user_id_wp, 'billing_last_name', $user['lastname']);
            update_user_meta((int)$user_id_wp, 'last_name', $user['lastname']);
            return (int)$user_id_wp;
        } else {
            return -1;
        }
    }
}
