<?php

namespace LmskaranMoopress\Models;

use WPMVC\MVC\Traits\FindTrait;
use WPMVC\MVC\Models\PostModel as Model;
use LmskaranMoopress\Controllers\Helpers\Base as BaseHelper;
use LmskaranMoopress\Controllers\Webservice\MoodleController;

class CourseApi extends Model
{
    use FindTrait;
    public static function getCourseBytitle($title, $is_trash = false)
    {
        $posts = get_posts([
            'post_type'  => 'product',
            'post_status'    => 'any',
            'title' => $title,
        ]);
        if ($is_trash) {
            $posts = get_posts([
                'post_type'  => 'product',
                'post_status'    => 'trash',
                'title' => $title,
            ]);
        }
        return @$posts[0];
    }
    public static function getCourseByMdlId($mdl_id, $is_trash = false)
    {

        $posts = get_posts(array(
            'numberposts'   => -1,
            'post_type'     => 'product',
            'meta_key'      => 'course_id_mdl',
            'post_status'    => 'any',
            'meta_value'    => "$mdl_id"
        ));
        if ($is_trash) {
            $posts = get_posts(array(
                'numberposts'   => -1,
                'post_type'     => 'product',
                'meta_key'      => 'course_id_mdl',
                'post_status'    => 'trash',
                'meta_value'    => "$mdl_id"
            ));
        }
        return @$posts[0];
    }
    public static function deleteCourse($course_id_mdl, $is_trash = false)
    {
        $opt = get_option("moopress_api_info", '');
        $force_delete_api = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_delete_api_default = (int)@$settings['force_delete_api'] ? 1 : 0;
        }

        if ($is_trash) {
            $last_course = self::getCourseByMdlId($course_id_mdl, true);
        } else {
            $last_course = self::getCourseByMdlId($course_id_mdl);
        }
        $post_wp_id = $last_course->ID;
        $force_delete_course_post = (int)get_post_meta($post_wp_id, 'force_delete_course', true);
        $force_delete_api = $force_delete_course_post == 2 ? $force_delete_api_default : $force_delete_course_post;

        if ($force_delete_api) {
            $post_status =  'trash';
            $course_post = array(
                'ID'           => $post_wp_id,
                'post_type' => 'product',
                'post_status' => $post_status,
            );
            // Update the post into the database
            wp_update_post($course_post);
            $product = wc_get_product($post_wp_id);
            $product->set_status($post_status);
            $post_wp_id = $product->save();
        }

        return $post_wp_id;
    }
    public static function createCourse($data)
    {

        $course_moodle = (array)MoodleController::get_courses_moojla((int)$data['course_id']);
        $custom_fields = @$course_moodle['customfields'];
       

        $opt = get_option("moopress_api_info", '');
        $force_course_published = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_course_published = (int)@$settings['force_course_published'] ? 1 : 0;
        }
        $status_post = "draft";
        if ($force_course_published) {
            $status_post = "publish";
        }
        $imgurl  = @$data['imgurl']; //Must save separately !
        $post_id = wp_insert_post(array(
            'post_title' => $data['course_name'],
            'post_type' => 'product',
            'post_status' => $status_post,
            'post_content' => $data['summary'],
        ));
        $cate_prod_id = self::createCourseCategoty($data['category_name'], $data['category_desc'], $data['category']);
        $product = wc_get_product($post_id);
        $slug = str_replace(" ", "-", $data['course_name']);
        $slug = str_replace("‌", "-", $slug);
        $product->set_category_ids(array($cate_prod_id));
        $product->set_name($data['course_name']);
        $product->set_slug($slug);
        $product->set_description($data['summary']);
        if ($imgurl) {
            $attachment_id = BaseHelper::upload_file_by_url($imgurl);
            $product->set_image_id($attachment_id);
        }
        $product->set_status($status_post);
        $post_wp_id = $product->save();
        // $customs_low_txt = @$data['custom_inputs']['txt_low'];
        // $customs_high_txt = @$data['custom_inputs']['txt_high'];
        // $customs_date_txt = @$data['custom_inputs']['txt_date'];
        $custom_fields_moodle_low = [];
        $custom_fields_moodle_high = [];
        $custom_fields_moodle_date = [];
        if ($custom_fields) {
            foreach ($custom_fields as $csf_item) {
                $item_custom = [];
                $csf_item = (array)$csf_item;
                $csf_type = $csf_item['type'];
                $csf_key = $csf_item['shortname'];
                $csf_title = $csf_item['name'];
                $csf_value = $csf_item['value'];
                $csf_valueraw = $csf_item['valueraw'];
                $item_custom['key_custom_fld'] = $csf_key;
                $item_custom['title_custom_fld'] = $csf_title;
                $item_custom['value_mdl_custom_fld'] = $csf_value;
                if ($csf_type == "date") {
                    $item_custom['value_custom_fld'] =  BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$csf_valueraw));
                    $custom_fields_moodle_date[] = $item_custom;
                } elseif ($csf_type == "textarea") {
                    $item_custom['value_custom_fld'] = $csf_valueraw;
                    $custom_fields_moodle_high[] = $item_custom;
                } else {
                    $_v = $csf_valueraw;
                    if ($csf_type == "select") {
                        $_v = $csf_value;
                    }
                    $item_custom['value_custom_fld'] = $_v;
                    $custom_fields_moodle_low[] = $item_custom;
                }
            }
        }
        // if ($customs_low_txt) {
        //     foreach ($customs_low_txt as $cs_fld_k => $cs_fld_v) {
        //         $item_custom = [];
        //         $item_custom['key_custom_fld'] = $cs_fld_k;
        //         $item_custom['value_custom_fld'] = $cs_fld_v;
        //         $custom_fields_moodle_low[] = $item_custom;
        //     }
        // }
        // if ($customs_high_txt) {
        //     foreach ($customs_high_txt as $cs_fld_k => $cs_fld_v) {
        //         $item_custom = [];
        //         $item_custom['key_custom_fld'] = $cs_fld_k;
        //         $item_custom['value_custom_fld'] = $cs_fld_v;
        //         $custom_fields_moodle_high[] = $item_custom;
        //     }
        // }
        // if ($customs_date_txt) {
        //     foreach ($customs_date_txt as $cs_fld_k => $cs_fld_v) {
        //         $item_custom = [];
        //         $item_custom['key_custom_fld'] = $cs_fld_k;
        //         //must convert to jalali date
        //         $item_custom['value_custom_fld'] = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$cs_fld_v));
        //         $custom_fields_moodle_date[] = $item_custom;
        //     }
        // }
        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }
        $course_moodle_url = $moodle_url . "course/view.php?id=" . $data['course_id'];
        $start_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['startdate']));
        $end_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['enddate']));
        update_post_meta($post_wp_id, 'course_id_mdl', $data['course_id']);

        update_post_meta($post_wp_id, 'category_name', $data['category_name']);
        update_post_meta($post_wp_id, 'category_desc', $data['category_desc']);

        update_post_meta($post_wp_id, 'course_moodle_url', $course_moodle_url);
        update_post_meta($post_wp_id, 'real_url_img_moodle_path', $imgurl);
        update_post_meta($post_wp_id, 'short_name_course_mdl', $data['course_shortname']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_timestamp', $data['startdate']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_jalali', $start_date_jalali);
        update_post_meta($post_wp_id, 'end_date_course_mdl_timestamp', $data['enddate']);
        update_post_meta($post_wp_id, 'end_date_course_mdl_jalali', $end_date_jalali);
        update_post_meta($post_wp_id, 'category_course_mdl', $data['category']);
        update_post_meta($post_wp_id, 'custom_fields_low_moodle', $custom_fields_moodle_low);
        update_post_meta($post_wp_id, 'custom_fields_high_moodle', $custom_fields_moodle_high);
        update_post_meta($post_wp_id, 'custom_fields_date_moodle', $custom_fields_moodle_date);

        update_post_meta($post_wp_id, 'force_delete_course', '2');
        update_post_meta($post_wp_id, 'force_content_course', '2');
        update_post_meta($post_wp_id, 'force_title_course', '2');


        return $post_wp_id;
    }
    public static function createCourse_local($data)
    {

        $course_moojla = MoodleController::get_courses_moojla((int)$data['id']);
        $imgurl  = @$course_moojla['imgurl']; //Must save separately !
        $custom_fields = @$course_moojla['customfields'];

        $opt = get_option("moopress_api_info", '');
        $force_course_published = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_course_published = (int)@$settings['force_course_published'] ? 1 : 0;
        }
        $status_post = "draft";
        if ($force_course_published) {
            $status_post = "publish";
        }

        $post_id = wp_insert_post(array(
            'post_title' => $data['fullname'],
            'post_type' => 'product',
            'post_status' => $status_post,
            'post_content' => $data['summary'],
        ));
        $cate_mdl_id = (int)$data['categoryid'];
        $cate_obj = self::getCategoryByMdlId($cate_mdl_id);

        $cate_name = '';
        $cate_desc = '';
        $cate_wp_id = 0;
        if ($cate_obj) {
            $cate_name = $cate_obj['name'];
            $cate_desc = $cate_obj['description'];
            $cate_wp_id = (int)$cate_obj['term_id'];
        }
        $product = wc_get_product($post_id);
        $slug = str_replace(" ", "-", $data['fullname']);
        $slug = str_replace("‌", "-", $slug);
        if ($cate_wp_id) {
            $product->set_category_ids(array($cate_wp_id));
        }
        $product->set_name($data['fullname']);
        $product->set_slug($slug);
        $product->set_description($data['summary']);
        $product->set_status($status_post);



        $imgurl_moodle = get_post_meta($post_id, 'real_url_img_moodle_path', true);
        if ($imgurl_moodle && !BaseHelper::url_exists($imgurl_moodle)) {
            $imgurl_moodle = '';
        }
        if ($imgurl) {
            if ($imgurl_moodle) {
                if ($imgurl != $imgurl_moodle) {
                    $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                    $product->set_image_id($attachment_id);
                }
            } else {
                $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                $product->set_image_id($attachment_id);
            }
        }


        $post_wp_id = $product->save();
        // $custom_fields = $data['customfields'];
        $custom_fields_moodle_low = [];
        $custom_fields_moodle_high = [];
        $custom_fields_moodle_date = [];
        if ($custom_fields) {
            foreach ($custom_fields as $csf_item) {
                $item_custom = [];
                $csf_item = (array)$csf_item;
                $csf_type = $csf_item['type'];
                $csf_key = $csf_item['shortname'];
                $csf_title = $csf_item['name'];
                $csf_value = $csf_item['value'];
                $csf_valueraw = $csf_item['valueraw'];
                $item_custom['key_custom_fld'] = $csf_key;
                $item_custom['title_custom_fld'] = $csf_title;
                $item_custom['value_mdl_custom_fld'] = $csf_value;
                if ($csf_type == "date") {
                    $item_custom['value_custom_fld'] =  BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$csf_valueraw));
                    $custom_fields_moodle_date[] = $item_custom;
                } elseif ($csf_type == "textarea") {
                    $item_custom['value_custom_fld'] = $csf_valueraw;
                    $custom_fields_moodle_high[] = $item_custom;
                } else {
                    $_v = $csf_valueraw;
                    if ($csf_type == "select") {
                        $_v = $csf_value;
                    }
                    $item_custom['value_custom_fld'] = $_v;
                    $custom_fields_moodle_low[] = $item_custom;
                }
            }
        }


        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }
        $course_moodle_url = $moodle_url . "course/view.php?id=" . $data['id'];
        $start_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['startdate']));
        $end_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['enddate']));


        update_post_meta($post_wp_id, 'course_id_mdl', $data['id']);

        update_post_meta($post_wp_id, 'category_name', $cate_name);
        update_post_meta($post_wp_id, 'category_desc', $cate_desc);

        update_post_meta($post_wp_id, 'course_moodle_url', $course_moodle_url);
        update_post_meta($post_wp_id, 'real_url_img_moodle_path', '');
        update_post_meta($post_wp_id, 'short_name_course_mdl', $data['shortname']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_timestamp', $data['startdate']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_jalali', $start_date_jalali);
        update_post_meta($post_wp_id, 'end_date_course_mdl_timestamp', $data['enddate']);
        update_post_meta($post_wp_id, 'end_date_course_mdl_jalali', $end_date_jalali);
        update_post_meta($post_wp_id, 'category_course_mdl', $data['categoryid']);
        update_post_meta($post_wp_id, 'custom_fields_low_moodle', $custom_fields_moodle_low);
        update_post_meta($post_wp_id, 'custom_fields_high_moodle', $custom_fields_moodle_high);
        update_post_meta($post_wp_id, 'custom_fields_date_moodle', $custom_fields_moodle_date);

        update_post_meta($post_wp_id, 'force_delete_course', '2');
        update_post_meta($post_wp_id, 'force_content_course', '2');
        update_post_meta($post_wp_id, 'force_title_course', '2');


        return $post_wp_id;
    }
    public static function syncCourse_single($data, $product_id, $course_mdl_id)
    {
        $course_moojla = MoodleController::get_courses_moojla((int)$course_mdl_id);
        $imgurl  = @$course_moojla['imgurl']; //Must save separately !
        $custom_fields = @$course_moojla['customfields'];

        $opt = get_option("moopress_api_info", '');
        $force_content_api = 0;
        $force_title_api = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_content_api_default = (int)@$settings['force_content_api'] ? 1 : 0;
            $force_title_api_default = (int)@$settings['force_title_api'] ? 1 : 0;
        }

        $post_wp_id = $product_id;

        $force_content_course_post = (int)get_post_meta($post_wp_id, 'force_content_course', true);
        $force_title_course_post = (int)get_post_meta($post_wp_id, 'force_title_course', true);

        $force_content_api = $force_content_course_post == 2 ? $force_content_api_default : $force_content_course_post;
        $force_title_api = $force_title_course_post == 2 ? $force_title_api_default : $force_title_course_post;
        $last_course = self::getCourseByMdlId($course_mdl_id);

        $slug = urldecode($last_course->post_name);
        $title = $last_course->post_title;
        $content = $last_course->post_content;
        $post_status = $last_course->post_status;
        $post_status = ($post_status == 'trash') ? "draft" : $post_status;

        if ($force_title_api) {
            $title = $data['fullname'];
        }
        if ($force_content_api) {
            $content = $data['summary'];
        }
        $course_post = array(
            'ID'           => $post_wp_id,
            'post_title' => $title,
            'post_type' => 'product',
            'post_status' => $post_status,
            'post_content' => $content,
        );
        $cate_mdl_id = (int)$data['categoryid'];
        $cate_obj = self::getCategoryByMdlId($cate_mdl_id);

        $cate_name = '';
        $cate_desc = '';
        $cate_wp_id = 0;
        if ($cate_obj) {
            $cate_name = $cate_obj['name'];
            $cate_desc = $cate_obj['description'];
            $cate_wp_id = (int)$cate_obj['term_id'];
        }
        wp_update_post($course_post);
        $product = wc_get_product($post_wp_id);
        if ($cate_wp_id) {
            $product->set_category_ids(array($cate_wp_id));
        }
        $product->set_name($title);
        $product->set_description($content);

        $product->set_slug($slug);
        $product->set_status($post_status);

        $imgurl_moodle = get_post_meta($post_wp_id, 'real_url_img_moodle_path', true);
        if ($imgurl_moodle && !BaseHelper::url_exists($imgurl_moodle)) {
            $imgurl_moodle = '';
        }
        if ($imgurl) {
            if ($imgurl_moodle) {
                if ($imgurl != $imgurl_moodle) {
                    $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                    $product->set_image_id($attachment_id);
                }
            } else {
                $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                $product->set_image_id($attachment_id);
            }
        }

        $post_wp_id = $product->save();


        // $custom_fields = $data['customfields'];
        $custom_fields_moodle_low = [];
        $custom_fields_moodle_high = [];
        $custom_fields_moodle_date = [];
        if ($custom_fields) {
            foreach ($custom_fields as $csf_item) {
                $item_custom = [];
                $csf_item = (array)$csf_item;
                $csf_type = $csf_item['type'];
                $csf_key = $csf_item['shortname'];
                $csf_title = $csf_item['name'];
                $csf_value = $csf_item['value'];
                $csf_valueraw = $csf_item['valueraw'];
                $item_custom['key_custom_fld'] = $csf_key;
                $item_custom['title_custom_fld'] = $csf_title;
                $item_custom['value_mdl_custom_fld'] = $csf_value;
                if ($csf_type == "date") {
                    $item_custom['value_custom_fld'] =  BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$csf_valueraw));
                    $custom_fields_moodle_date[] = $item_custom;
                } elseif ($csf_type == "textarea") {
                    $item_custom['value_custom_fld'] = $csf_valueraw;
                    $custom_fields_moodle_high[] = $item_custom;
                } else {
                    $_v = $csf_valueraw;
                    if ($csf_type == "select") {
                        $_v = $csf_value;
                    }
                    $item_custom['value_custom_fld'] = $_v;
                    $custom_fields_moodle_low[] = $item_custom;
                }
            }
        }
        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }
        $course_moodle_url = $moodle_url . "course/view.php?id=" . $data['id'];
        $start_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['startdate']));
        $end_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['enddate']));

        update_post_meta($post_wp_id, 'real_url_img_moodle_path', $imgurl);
        update_post_meta($post_wp_id, 'category_name', $cate_name);
        update_post_meta($post_wp_id, 'category_desc', $cate_desc);
        update_post_meta($post_wp_id, 'course_moodle_url', $course_moodle_url);
        update_post_meta($post_wp_id, 'short_name_course_mdl', $data['shortname']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_timestamp', $data['startdate']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_jalali', $start_date_jalali);
        update_post_meta($post_wp_id, 'end_date_course_mdl_timestamp', $data['enddate']);
        update_post_meta($post_wp_id, 'end_date_course_mdl_jalali', $end_date_jalali);
        update_post_meta($post_wp_id, 'category_course_mdl', $data['categoryid']);
        update_post_meta($post_wp_id, 'custom_fields_low_moodle', $custom_fields_moodle_low);
        update_post_meta($post_wp_id, 'custom_fields_high_moodle', $custom_fields_moodle_high);
        update_post_meta($post_wp_id, 'custom_fields_date_moodle', $custom_fields_moodle_date);
        return $post_wp_id;
    }
    public static function sync_custom_fields($data, $product_id, $course_mdl_id)
    {
        $course_moojla = MoodleController::get_courses_moojla((int)$course_mdl_id);
        $imgurl  = @$course_moojla['imgurl']; //Must save separately !
        $custom_fields = @$course_moojla['customfields'];

        $opt = get_option("moopress_api_info", '');
        $force_content_api = 0;
        $force_title_api = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_content_api_default = (int)@$settings['force_content_api'] ? 1 : 0;
            $force_title_api_default = (int)@$settings['force_title_api'] ? 1 : 0;
        }

        $post_wp_id = $product_id;

        $force_content_course_post = (int)get_post_meta($post_wp_id, 'force_content_course', true);
        $force_title_course_post = (int)get_post_meta($post_wp_id, 'force_title_course', true);

        $force_content_api = $force_content_course_post == 2 ? $force_content_api_default : $force_content_course_post;
        $force_title_api = $force_title_course_post == 2 ? $force_title_api_default : $force_title_course_post;
        $last_course = self::getCourseByMdlId($course_mdl_id);

        $slug = urldecode($last_course->post_name);
        $title = $last_course->post_title;
        $content = $last_course->post_content;
        $post_status = $last_course->post_status;
        $post_status = ($post_status == 'trash') ? "draft" : $post_status;

        // $custom_fields = $data['customfields'];
        $custom_fields_moodle_low = [];
        $custom_fields_moodle_high = [];
        $custom_fields_moodle_date = [];
        if ($custom_fields) {
            foreach ($custom_fields as $csf_item) {
                $item_custom = [];
                $csf_item = (array)$csf_item;
                $csf_type = $csf_item['type'];
                $csf_key = $csf_item['shortname'];
                $csf_title = $csf_item['name'];
                $csf_value = $csf_item['value'];
                $csf_valueraw = $csf_item['valueraw'];
                $item_custom['key_custom_fld'] = $csf_key;
                $item_custom['title_custom_fld'] = $csf_title;
                $item_custom['value_mdl_custom_fld'] = $csf_value;
                if ($csf_type == "date") {
                    $item_custom['value_custom_fld'] =  BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$csf_valueraw));
                    $custom_fields_moodle_date[] = $item_custom;
                } elseif ($csf_type == "textarea") {
                    $item_custom['value_custom_fld'] = $csf_valueraw;
                    $custom_fields_moodle_high[] = $item_custom;
                } else {
                    $_v = $csf_valueraw;
                    if ($csf_type == "select") {
                        $_v = $csf_value;
                    }
                    $item_custom['value_custom_fld'] = $_v;
                    $custom_fields_moodle_low[] = $item_custom;
                }
            }
        }
 
        update_post_meta($post_wp_id, 'custom_fields_low_moodle', $custom_fields_moodle_low);
        update_post_meta($post_wp_id, 'custom_fields_high_moodle', $custom_fields_moodle_high);
        update_post_meta($post_wp_id, 'custom_fields_date_moodle', $custom_fields_moodle_date);
        return $post_wp_id;
    }
    public static function updateCourse($data, $course_id_mdl, $is_trash = false)
    {
        $course_moodle = (array)MoodleController::get_courses_moojla((int)$data['course_id']);
        $custom_fields = @$course_moodle['customfields'];

        $opt = get_option("moopress_api_info", '');
        $force_content_api = 0;
        $force_title_api = 0;
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $force_content_api_default = (int)@$settings['force_content_api'] ? 1 : 0;
            $force_title_api_default = (int)@$settings['force_title_api'] ? 1 : 0;
        }
        $imgurl  = @$data['imgurl']; //Must save separately !
        if ($is_trash) {
            $last_course = self::getCourseByMdlId($data['course_id'], true);
        } else {
            $last_course = self::getCourseByMdlId($data['course_id']);
        }
        $post_wp_id = $last_course->ID;

        $force_content_course_post = (int)get_post_meta($post_wp_id, 'force_content_course', true);
        $force_title_course_post = (int)get_post_meta($post_wp_id, 'force_title_course', true);

        $force_content_api = $force_content_course_post == 2 ? $force_content_api_default : $force_content_course_post;
        $force_title_api = $force_title_course_post == 2 ? $force_title_api_default : $force_title_course_post;


        $slug = urldecode($last_course->post_name);
        $title = $last_course->post_title;
        $content = $last_course->post_content;
        $post_status = $last_course->post_status;
        $post_status = ($post_status == 'trash') ? "draft" : $post_status;
        $imgurl_moodle = get_post_meta($post_wp_id, 'real_url_img_moodle_path', true);
        if ($imgurl_moodle && !BaseHelper::url_exists($imgurl_moodle)) {
            $imgurl_moodle = '';
        }
        if ($force_title_api) {
            $title = $data['course_name'];
        }
        if ($force_content_api) {
            $content = $data['summary'];
        }
        $course_post = array(
            'ID'           => $post_wp_id,
            'post_title' => $title,
            'post_type' => 'product',
            'post_status' => $post_status,
            'post_content' => $content,
        );

        $cate_prod_id = self::createCourseCategoty($data['category_name'], $data['category_desc'], $data['category']);
        $enrol_method = @$data['enrol_method'];
        $price_product = 0;
        $price_currency = '';
        $rial_price_product = 0;

        if ($enrol_method) {
            $price_product = (int)$enrol_method['cost'];
            $price_currency = $enrol_method['currency'];
        }
        // Update the post into the database
        wp_update_post($course_post);
        $product = wc_get_product($post_wp_id);
        $product->set_category_ids(array($cate_prod_id));
        $product->set_name($title);
        $product->set_regular_price($price_product);
        $product->set_description($content);

        if ($imgurl) {
            if ($imgurl_moodle) {
                if ($imgurl != $imgurl_moodle) {
                    $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                    $product->set_image_id($attachment_id);
                }
            } else {
                $attachment_id = BaseHelper::upload_file_by_url($imgurl);
                $product->set_image_id($attachment_id);
            }
        }
        $product->set_slug($slug);
        $product->set_status($post_status);
        $post_wp_id = $product->save();

        $customs_low_txt = @(array)$data['custom_inputs']['txt_low'];
        $customs_high_txt = @(array)$data['custom_inputs']['txt_high'];
        $customs_date_txt = @(array)$data['custom_inputs']['txt_date'];

        $custom_fields_moodle_low = [];
        $custom_fields_moodle_high = [];
        $custom_fields_moodle_date = [];
        if ($custom_fields) {
            foreach ($custom_fields as $csf_item) {
                $item_custom = [];
                $csf_item = (array)$csf_item;
                $csf_type = $csf_item['type'];
                $csf_key = $csf_item['shortname'];
                $csf_title = $csf_item['name'];
                $csf_value = $csf_item['value'];
                $csf_valueraw = $csf_item['valueraw'];
                $item_custom['key_custom_fld'] = $csf_key;
                $item_custom['title_custom_fld'] = $csf_title;
                $item_custom['value_mdl_custom_fld'] = $csf_value;
                if ($csf_type == "date") {
                    $item_custom['value_custom_fld'] =  BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$csf_valueraw));
                    $custom_fields_moodle_date[] = $item_custom;
                } elseif ($csf_type == "textarea") {
                    $item_custom['value_custom_fld'] = $csf_valueraw;
                    $custom_fields_moodle_high[] = $item_custom;
                } else {

                    $_v = $csf_valueraw;
                    if ($csf_type == "select") {
                        $_v = $csf_value;
                    }
                    $item_custom['value_custom_fld'] = $_v;
                    $custom_fields_moodle_low[] = $item_custom;
                }
            }
        }



        $opt = get_option("moopress_api_info", '');
        $moodle_url = '';
        if ($opt) {
            $settings = unserialize(base64_decode($opt));
            $moodle_url = @$settings['moodle_url'];
        }
        $course_moodle_url = $moodle_url . "course/view.php?id=" . $data['course_id'];

        $start_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['startdate']));
        $end_date_jalali = BaseHelper::make_en_str(moopress_jdate('Y/n/j', (int)$data['enddate']));
        
        update_post_meta($post_wp_id, 'course_id_mdl', $data['course_id']);
        update_post_meta($post_wp_id, 'category_name', $data['category_name']);
        update_post_meta($post_wp_id, 'category_desc', $data['category_desc']);
        update_post_meta($post_wp_id, 'course_moodle_url', $course_moodle_url);

        update_post_meta($post_wp_id, 'real_url_img_moodle_path', $imgurl);
        update_post_meta($post_wp_id, 'short_name_course_mdl', $data['course_shortname']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_timestamp', $data['startdate']);
        update_post_meta($post_wp_id, 'begin_date_course_mdl_jalali', $start_date_jalali);
        update_post_meta($post_wp_id, 'end_date_course_mdl_timestamp', $data['enddate']);
        update_post_meta($post_wp_id, 'end_date_course_mdl_jalali', $end_date_jalali);
        update_post_meta($post_wp_id, 'category_course_mdl', $data['category']);
        update_post_meta($post_wp_id, 'custom_fields_low_moodle', $custom_fields_moodle_low);
        update_post_meta($post_wp_id, 'custom_fields_high_moodle', $custom_fields_moodle_high);
        update_post_meta($post_wp_id, 'custom_fields_date_moodle', $custom_fields_moodle_date);
        return $post_wp_id;
    }
    public static function updateCourseCost($cost, $product_id)
    {
        $product = wc_get_product($product_id);
        $product->set_regular_price($cost);
        $post_wp_id = $product->save();
        return  $post_wp_id;
    }
    public static function createCourseCategoty($title_cate, $desc_cate, $cate_mdl_id = 0)
    {
        if ($cate_mdl_id) {
            $cate_obj = self::getCategoryByMdlId($cate_mdl_id);
            if ($cate_obj) {
                // BaseHelper::dd($cate_obj);
                // die;
                $cate_name = $cate_obj['name'];
                $cate_wp_id = (int)$cate_obj['term_id'];
                $slug = str_replace(" ", "-", $cate_name);
                $slug = str_replace("‌", "-", $slug);
                wp_update_term($cate_wp_id, 'product_cat', array(
                    'name' => $title_cate,
                    'slug' =>  $slug
                ));
                return $cate_wp_id;
            }
        }


        // $data = term_exists($title_cate, 'product_cat');
        // if ($data) {
        //     update_term_meta((int)$data['term_id'], 'category_mdl_id', $cate_mdl_id);
        //     return (int)$data['term_id'];
        // }
        $slug = str_replace(" ", "-", $title_cate);
        $slug = str_replace("‌", "-", $slug);

        $term_data = (array)wp_insert_term(
            $title_cate,
            'product_cat',
            array(
                'description' => $desc_cate,
                'slug' => $slug,
            )
        );
        if (@$term_data['term_id']) {
            update_term_meta($term_data['term_id'], 'category_mdl_id', $cate_mdl_id);

            return (int)$term_data['term_id'];
        } else {
            return 0;
        }
    }
    public static function getCategoryByMdlId($cate_mdl_id)
    {
        $term_args = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );
        $terms = get_terms($term_args);
        $term_obj = array();
        foreach ($terms as $term) {
            $key = (int)get_term_meta($term->term_id, 'category_mdl_id', true);
            if ($key == (int)$cate_mdl_id) {
                $term_obj = $term;
            }
        }
        return (array)$term_obj;
    }
}
