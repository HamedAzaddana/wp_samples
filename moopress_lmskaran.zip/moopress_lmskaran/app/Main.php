<?php

namespace LmskaranMoopress;

use WPMVC\Bridge;

/**
 * Main class.
 * Bridge between WordPress and App.
 * Class contains declaration of hooks and filters.
 *
 * @author lmskaran <https://lmskaran.com/>
 * @package lmskaran-moopress
 * @version 1.0.0
 */
class Main extends Bridge
{
    public function init()
    {
        $this->on_front_ajax();
        $this->add_action('rest_api_init', 'Api/ApiController@register_routes');
        $this->add_action('wp_login', 'AuthController@sso_auth_after_login', 10, 2);
        $this->add_action('woocommerce_register_form', 'AuthController@add_reg_wooc_fields');
        $this->add_action(
            'woocommerce_register_post',
            'AuthController@validate_register',
            10,
            3
        );
        $this->add_action('woocommerce_created_customer', 'AuthController@register_user_info');
        $this->add_filter(
            'woocommerce_min_password_strength',
            'AuthController@change_wooc_password_policy',
            10
        );
        $this->add_action('wp_print_scripts', 'AuthController@remove_password_policy', 10);
        $this->add_action('wp_footer', 'AuthController@alert_reg_moodle', 100);
        $this->add_action(
            'woocommerce_save_account_details_errors',
            'AuthController@validate_update_account',
            10,
            2
        );
        $this->add_action('woocommerce_save_account_details', 'AuthController@update_account_info');
        $this->add_action('password_reset', 'AuthController@after_password_reset', 10, 2);
        $this->add_filter(
            'woocommerce_add_to_cart_validation',
            'AuthController@add_to_cart_validation',
            10,
            3
        );
        $this->add_action(
            'user_profile_update_errors',
            'AuthController@validate_user_reg_admin',
            10,
            3
        );
        $this->add_action('user_register', 'AuthController@user_register_admin');
        $this->add_action('personal_options_update', 'AuthController@update_register_admin');
        $this->add_action('edit_user_profile_update', 'AuthController@update_register_admin');
        $this->add_action(
            'profile_update',
            'AuthController@after_update_register_admin',
            10,
            2
        );
        $this->add_filter('manage_users_columns', 'AuthController@add_edit_moodle_link_column');
        $this->add_filter(
            'manage_users_custom_column',
            'AuthController@add_edit_moodle_link_column_row',
            10,
            3
        );
        $this->add_filter( 'the_content', 'ProductController@add_course_elementor_templates' );
        $this->add_action('wp_footer', 'AdminMenuController@load_csrf_token');
        //        $this->add_action( 'wp_footer', 'AuthController@redirect_2dir_login_mdl' );
        //        $this->add_action( 'admin_footer', 'AuthController@redirect_2dir_login_mdl' );
        $this->add_action('shutdown', 'AuthController@redirect_2dir_login_mdl');
        $this->add_action('wp_footer', 'AdminMenuController@swal_show_messages');
        $this->add_action('delete_user', 'AuthController@delete_user_wp');
        // $this->add_action(
        //     'woocommerce_order_status_completed',
        //     'OrderController@enrol_user_after_order',
        //     10,
        //     1
        // );
        $this->add_action(
            'woocommerce_new_order',
            'OrderController@enrol_user_after_any_order',
            10,
            2
        );
        $this->add_action(
            'woocommerce_order_status_changed',
            'OrderController@enrol_user_after_change_order',
            10,
            3
        );
        $this->add_action('add_meta_boxes', 'ProductController@show_participants_course');
        $this->add_shortcode('moopress_my_courses_enrolled', 'ProductController@load_my_courses_enrolled');
        $this->add_shortcode('moopress_participants_role_id', 'ProductController@load_course_participants_role_id');
        $this->add_shortcode('moopress_course_modules_sections', 'ProductController@load_course_modules_sections');
        $this->add_shortcode('moopress_moodle_quiz_hold', 'ProductController@load_moodle_quiz');
    }
    public function on_admin()
    {
        $this->on_admin_ajax();
        $this->add_action('admin_footer', 'AdminMenuController@load_csrf_token');
        $this->add_action('plugins_loaded', 'AdminMenuController@check_woocommerce');
        $this->add_action('admin_menu', 'AdminMenuController@show_menu');
        $this->add_action('cmb2_admin_init', 'ProductController@moodle_fields');
        $this->add_action('save_post', 'ProductController@save_product_handle', 10, 2);
        $this->add_action('post_submitbox_misc_actions', 'ProductController@add_sync_btn_moodle');
        $this->add_filter('bulk_actions-edit-product', 'ProductController@add_bulk_action_sync');
        $this->add_action(
            'handle_bulk_actions-edit-product',
            'ProductController@handle_product_bulk_actions',
            10,
            3
        );
        $this->add_filter('manage_product_posts_columns', 'ProductController@register_columns');
        $this->add_action(
            'manage_product_posts_custom_column',
            'ProductController@handle_new_columns',
            10,
            2
        );
    }
    private function on_admin_ajax()
    {
        $moodle_ajax_methods = [
            'test_moodle_connection',
            'sync_product_from_moodle',
            'get_course_participants_moodle',
            'unenroll_participants_moodle',
            'add_manual_participant_course',
            'sync_product_to_moodle_force',
        ];
        if ($moodle_ajax_methods) {
            foreach ($moodle_ajax_methods as $moodle_ajax_method) {
                $this->add_action('wp_ajax_' . $moodle_ajax_method, 'Ajax/AjaxController@' . $moodle_ajax_method);
                $this->add_action('wp_ajax_nopriv_' . $moodle_ajax_method, 'Ajax/AjaxController@' . $moodle_ajax_method);
            }
        }
    }
    private function on_front_ajax()
    {
        $moodle_ajax_methods = ['get_course_modules_front'];
        if ($moodle_ajax_methods) {
            foreach ($moodle_ajax_methods as $moodle_ajax_method) {
                $this->add_action('wp_ajax_' . $moodle_ajax_method, 'Ajax/AjaxController@' . $moodle_ajax_method);
                $this->add_action('wp_ajax_nopriv_' . $moodle_ajax_method, 'Ajax/AjaxController@' . $moodle_ajax_method);
            }
        }
    }
}
