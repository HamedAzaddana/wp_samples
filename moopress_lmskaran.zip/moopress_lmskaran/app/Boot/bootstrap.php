<?php

use WPMVC\Config;

/**
 * This file will load configuration file and init Main class.
 *
 * @author WordPress MVC <https://www.wordpress-mvc.com/>
 * @license MIT
 * @package wpmvc
 * @version 1.0.4
 */

require_once( __DIR__ . '/../../vendor/autoload.php' );

define('MOOPRSSS_APP_URL', home_url() . "/wp-content/plugins/moopress_lmskaran/");
define('MOOPRSSS_APP_PATH', WP_CONTENT_DIR. '/plugins/moopress_lmskaran/');


require_once(MOOPRSSS_APP_PATH . "addons/libs/jdf.php");
require_once(MOOPRSSS_APP_PATH . "addons/cmb2/init.php");


$config = include( plugin_dir_path( __FILE__ ) . '../Config/app.php' );

$plugin_namespace = $config['namespace'];

$plugin_name = strtolower( explode( '\\' , $plugin_namespace )[0] );

$plugin_class = $plugin_namespace . '\Main';

$plugin_reflection = new ReflectionClass( get_parent_class( $plugin_class ) );

// Global class init
$$plugin_name = new $plugin_class( new Config( $config ) );

//Activate Plugin functions
(new LmskaranMoopress\Controllers\ActivateController())->init();


// Unset
unset($plugin_reflection);
unset($plugin_namespace);
unset($plugin_name);
unset($plugin_class);
unset($config);