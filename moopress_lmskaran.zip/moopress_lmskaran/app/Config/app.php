<?php

/**
 * App configuration file.
 */
return [

    'namespace' => 'LmskaranMoopress',

    'type' => 'plugin',

    'version' => '1.0.0',

    'author' => 'lmskaran <https://lmskaran.com/>',

    'license' => 'MIT',

    'autoenqueue' => [

        // Enables or disables auto-enqueue of assets
        'enabled'       => true,
        // Enqueue priority
        'priority'      => 10,
        // Assets to auto-enqueue or auto-register
        'assets'        => [
            //css
            [
                'asset'     => 'css/admin.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/font-awesome.min.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/jalalidatepicker.min.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/select2.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/sweetalert2.min.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/sweetalert2.min.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => false,
            ],
            [
                'asset'     => 'css/vanillatoasts.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'css/front.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => false,
            ],
            [
                'asset'     => 'css/font-awesome.min.css',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => false,
            ],
            //js
            [
                'asset'     => 'js/admin.js',
                'dep'       => [],
                'footer'    => true,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/jalalidatepicker.min.js',
                'dep'       => [],
                'footer'    => true,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/select2.js',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/sweetalert2.min.js',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/jquery-ui.js',
                'dep'       => [],
                'footer'    => true,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/sweetalert2.min.js',
                'dep'       => [],
                'footer'    => false,
                'is_admin'  => false,
            ],
            [
                'asset'     => 'js/vanillatoasts.js',
                'dep'       => [],
                'footer'    => true,
                'is_admin'  => true,
            ],
            [
                'asset'     => 'js/front.js',
                'dep'       => [],
                'footer'    => true,
                'is_admin'  => false,
            ],

        ],

    ],

    'localize' => [

        // Enables or disables localization
        'enabled'       => true,
        // Default path for language files
        'path'          => __DIR__ . '/../../assets/lang/',
        // Text domain
        'textdomain' => 'lmskaran-moopress',
        // Unload loaded locale files before localization
        'unload'        => false,
        // Flag that indicates if this is a WordPress.org plugin/theme
        'is_public'     => false,

    ],

    'paths' => [
        'base'          => __DIR__ . '/../',
        'controllers'   => __DIR__ . '/../Controllers/',
        'views'         => __DIR__ . '/../../assets/views/',
        'lang'          => __DIR__ . '/../../assets/lang/',
        'log'           => WP_CONTENT_DIR . '/wpmvc/log',
    ],


    'cache' => [

        // Enables or disables cache
        'enabled'       => true,
        // files, auto (files), apc, wincache, xcache, memcache, memcached
        'storage'       => 'auto',
        // Default path for files
        'path'          => WP_CONTENT_DIR . '/wpmvc/cache',
        // It will create a path by PATH/securityKey
        'securityKey'   => '',
        // FallBack Driver
        'fallback'      => [
            'memcache'  =>  'files',
            'apc'       =>  'sqlite',
        ],
        // .htaccess protect
        'htaccess'      => true,
        // Default Memcache Server
        'server'        => [
            ['127.0.0.1', 11211, 1],
        ],

    ],

    'addons' => [],

];
