jQuery(document).ready(function ($) {



    
    
    var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
    function moopress_fa2en(txt) {
        txt = txt.replaceAll("۱", "1");
        txt = txt.replaceAll("۲", "2");
        txt = txt.replaceAll("۳", "3");
        txt = txt.replaceAll("۴", "4");
        txt = txt.replaceAll("۵", "5");
        txt = txt.replaceAll("۶", "6");
        txt = txt.replaceAll("۷", "7");
        txt = txt.replaceAll("۸", "8");
        txt = txt.replaceAll("۹", "9");
        txt = txt.replaceAll("۰", "0");
        return txt;
    }
    function get_course_modules(cid, wp_ajax_url) {

        $.ajax({
            url: wp_ajax_url,
            type: "POST",
            data: {
                action: "get_course_modules_front",
                moopress_csrf_token,
                cid
            },
            beforeSend: function () {

            },
            complete: function (res) {
                console.log(res)
                var status_code = res.status;
                if (status_code != 200) {
                    // Swal.fire({
                    //     title: 'توجه !',
                    //     text: 'مشکلی در لود ماژول های درس رخ داده است !',
                    //     icon: 'error',
                    //     confirmButtonText: 'بستن'
                    // });
                    $('#moopress-course-modules').hide();
                } else {
                    $('#moopress-course-modules').html(res.responseText);
                }

            },

        });
    }
    function MoopressLoadElementsEvent() {
        if ($('#moopress-course-modules').length) {
            var wp_ajax_url = $('#moopress-course-modules .loading-state input[name="wp-ajax-url"]').val();
            var cid = $('#moopress-course-modules .loading-state input[name="cid"]').val();
            get_course_modules(cid, wp_ajax_url);
            
        }
    }
    if (document.readyState === 'ready' || document.readyState === 'complete') {
        MoopressLoadElementsEvent()
    } else {
        document.onreadystatechange = function () {
            if (document.readyState == "complete") {
                MoopressLoadElementsEvent()
            }
        }
    }
    $('input[type=password]').on('input', function () {
        var enval = moopress_fa2en($(this).val());
        $(this).val(enval);
    });
    


})