jQuery(document).ready(function ($) {
    $("#moopress_settings *").tooltip({
        tooltipClass: "moopress_tootip_jui",
    });
    function moopress_make_wordpress_token(length) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789*&^%$#@<>-_';
        const charactersLength = characters.length;
        let counter = 0;
        while (counter < length) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
            counter += 1;
        }
        return result;
    }

  
    var ajax_moopress_url = cmb2_l10.ajaxurl;
    var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
    //set nav clicks
    // $('.nav-tab-moopress').click(function (e) {
    //     e.preventDefault();
    //     var data_refrence_id = $(this).attr('data-refrence');
    //     $('.nav-tab-moopress').removeClass('nav-tab-active');
    //     $(this).addClass('nav-tab-active');
    //     $('#moopress-content-admin-tab > div').hide();
    //     $(`#moopress-content-admin-tab > #${data_refrence_id}`).show();
    // });
    //generate token wordpress
    $('#auto_generato_wordpress_token_btn').click(function (e) {
        var token_wordpress = moopress_make_wordpress_token(40);
        // var last_token_wordpress = $(`input[name="wordpress_token"]`).val();

        $('#auto_generato_wordpress_token').text(token_wordpress);
        $(`input[name="wordpress_token"]`).val(token_wordpress);
    });
    //test moodle connection
    $('#moopress_test_moodle_connection').click(function (e) {
        e.preventDefault();
        var _btn = $(this);
        var _btn_html = _btn.html();
        var _loading_content = `لطفا منتظر بمانید ... <i class='fa fa-spin fa-spinner'></i>`;
        $.ajax({
            url: ajax_moopress_url,
            type: "POST",
            data: {
                action: "test_moodle_connection",
                moopress_csrf_token
            },
            beforeSend: function () {
                _btn.html(_loading_content)
            },
            complete: function (res) {
                var status_code = res.status;
                var msg = res.responseJSON.data;
                if (status_code != 200) {
                    Swal.fire({
                        title: 'توجه !',
                        text: msg,
                        icon: 'error',
                        confirmButtonText: 'بستن'
                    })
                } else {
                    Swal.fire({
                        title: 'عالیه !',
                        text: msg,
                        icon: 'success',
                        confirmButtonText: 'بستن'
                    })
                }

                _btn.html(_btn_html)
            },

        });

    });
    //sync btns submit forms
    $('#btn_form_moopress_sync_categories').click(function (e) {
        $('#form_moopress_sync_categories').submit();
    });
    $('#btn_form_moopress_sync_courses').click(function (e) {
        $('#form_moopress_sync_courses').submit();
    });
    $('#btn_form_moopress_sync_users').click(function (e) {
        $('#form_moopress_sync_users').submit();
    });
    $(`.input_sync_settings`).on('input', function (e) {
        var _val = parseInt($(this).val());
        var _class = "." + $(this).attr('data-class');
        $(_class).val(_val)
    });

   

    

    //sync button for table product
    $('.moopress_sync_table_product').click(function (e) {
        e.preventDefault();
        var _btn = $(this);
        _btn.attr('disabled', 'disabled');
        var _btn_html = _btn.html();
        var _loading_content = ` <i class="fa fa-refresh fa-spin"></i> همگام سازی از مودل `;
        var product_id = parseInt(_btn.attr('data-pid'));
        var product_title = parseInt(_btn.attr('data-title'));

        $.ajax({
            url: ajax_moopress_url,
            type: "POST",
            data: {
                action: "sync_product_from_moodle",
                moopress_csrf_token,
                product_id
            },
            beforeSend: function () {
                _btn.html(_loading_content)
            },
            complete: function (res) {
                var status_code = res.status;
                var msg = res.responseJSON.data;
                if (status_code != 200) {
                    Swal.fire({
                        title: 'توجه !',
                        text: msg,
                        icon: 'error',
                        confirmButtonText: 'بستن'
                    })
                } else {
                    Swal.fire({
                        title: 'عالیه !',
                        text: msg,
                        icon: 'success',
                        confirmButtonText: 'بستن'
                    })
                    location.reload();
                }
                _btn.removeAttr('disabled');
                _btn.html(_btn_html)
            },

        });

    });
    //cancel sync operation !
    $('#moopress_cancel_sync_btn').click(function (e) {
        $(this).attr('disabled', 'disabled');
        $(this).html(`<i class='fa fa-stop-circle'></i> در حال خروج ...`);

        var bc_url = $(this).attr('bc-url');
        window.location.replace(bc_url);
    });
    //pause sync operation !
    $('#moopress_pause_sync_btn').click(function (e) {
        $(this).attr('disabled', 'disabled');
        $(this).html(`<i class='fa fa-pause-circle-o'></i> در حال توقف ...`);
        var bc_url = $(this).attr('bc-url');
        var nc_url = $(this).attr('nc-url');
        localStorage.setItem('mprs_sync_continue_url', nc_url);
        window.location.replace(bc_url);

    });
    //continue sync operation !
    $('#moopress_continue_sync_btn').click(function (e) {
        $(this).attr('disabled', 'disabled');
        $(this).html(`<i class='fa fa-play-circle'></i> در حال از سرگیری ...`);
        var mprs_sync_continue_url = localStorage.getItem('mprs_sync_continue_url');
        if (mprs_sync_continue_url) {
            window.location.replace(mprs_sync_continue_url);
            localStorage.setItem('mprs_sync_continue_url', '');
        }
    });

    //load select 2 and jalali date picker for cmb2 fields
    $('#moodle_cmb2_metabox #category_course_mdl,#moodle_cmb2_metabox #force_delete_course,#moodle_cmb2_metabox #force_content_course,#moodle_cmb2_metabox #force_title_course').select2({
        placeholder: "",
        dir: "rtl",
    });
    jalaliDatepicker.startWatch({
        minDate: "attr",
        maxDate: "attr",
        selector: `[jdp="jdp"]`
    });
});