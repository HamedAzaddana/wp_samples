<?php
if ($categories) {
    foreach ($categories as $k_cate => $cate_item) {
        $data_array = [
            'k' => $k_cate,
            'v' => $cate_item,
        ];
        $data_stringify = base64_encode(serialize($data_array));
        $url = get_site_url() . "/wp-json/moopress/v1/sync/category";
        echo '
           <script>
                    var req = new XMLHttpRequest();
                    req.open(\'post\', "' . $url . '");
                    req.setRequestHeader("Wp-Auth-Token", "' . $token . '");
                    req.setRequestHeader("Wp-local-data", "' . $data_stringify . '");
                    req.send();
                    req.onload = function() {
                        var j_response = JSON.parse(this.responseText);
                        if (j_response.success) {
                            var success_box = "<div class=\'notice notice-success is-dismissible\' style=\'padding:10px ;\'>" + j_response.data.message + "</div><br>";
                            document.getElementById(\'moopress_msg_box_send_sms\').innerHTML = document.getElementById(\'moopress_msg_box_send_sms\').innerHTML + success_box;
                        } else {
                            var error_msg = \'\';
                            if (j_response.message) {
                                error_msg = j_response.message;
                            } else {
                                error_msg = j_response.data.message
                            }
                            var error_box = "<div class=\'notice notice-error is-dismissible\' style=\'padding:10px ;\'>" + error_msg + "</div><br>";
                            document.getElementById(\'moopress_msg_box_send_sms\').innerHTML = document.getElementById(\'moopress_msg_box_send_sms\').innerHTML + error_box;
                        }
                    }
                </script>
        ';
    }
}

if ($courses) {
    foreach ($courses as $course_item) {
        $data_stringify = base64_encode(serialize($course_item));
        $url = get_site_url() . "/wp-json/moopress/v1/sync/course";
        echo '
        <script>
                 var req = new XMLHttpRequest();
                 req.open(\'post\', "' . $url . '");
                 req.setRequestHeader("Wp-Auth-Token", "' . $token . '");
                 req.setRequestHeader("Wp-local-data", "' . $data_stringify . '");
                 req.send();
                 req.onload = function() {
                     var j_response = JSON.parse(this.responseText);
                     if (j_response.success) {
                         var success_box = "<div class=\'notice notice-success is-dismissible\' style=\'padding:10px ;\'>" + j_response.data.message + "</div><br>";
                         document.getElementById(\'moopress_msg_box_send_sms\').innerHTML = document.getElementById(\'moopress_msg_box_send_sms\').innerHTML + success_box;
                     } else {
                         var error_msg = \'\';
                         if (j_response.message) {
                             error_msg = j_response.message;
                         } else {
                             error_msg = j_response.data.message
                         }
                         var error_box = "<div class=\'notice notice-error is-dismissible\' style=\'padding:10px ;\'>" + error_msg + "</div><br>";
                         document.getElementById(\'moopress_msg_box_send_sms\').innerHTML = document.getElementById(\'moopress_msg_box_send_sms\').innerHTML + error_box;
                     }
                 }
             </script>
     ';
    }
}
?>

<div id="moopress_msg_box_send_sms"></div>