<?php

$error_occurred = @$params['error_occurred'];
$errors = @$params['errors'];
$errors = $errors ? unserialize(base64_decode($errors)) : ["خطایی رخ داد !"];
if ($error_occurred) {
?>
    <script>
        Swal.fire({
            title: '<strong>توجه !<strong>',
            icon: 'error',
            html: "<?php
                    foreach ($errors as $error) {
                        echo "<span style='color:red;'>*</span>".$error."";
                    }
                    ?>",
            confirmButtonText: 'بستن',
        })
    </script>
<?php
}
