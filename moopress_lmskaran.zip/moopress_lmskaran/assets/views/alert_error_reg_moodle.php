<script>
    Swal.fire({
        title: 'توجه !',
        text: 'ثبت نام شما در سامانه مودل با خطا مواجه شد !',
        icon: 'error',
        confirmButtonText: 'بستن'
    });
</script>
