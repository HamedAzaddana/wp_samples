<div class="moopress_card" id="moopress_settings">

    <h1> <i class="fa fa-bolt"></i> تنظیمات موپرس</h1>
    <hr>
    <div>
        <?php
        $base_setting_url =  $next_url = get_site_url() . "/wp-admin/admin.php?page=lmskaran_moopress_settings";
        $url_view_a = $base_setting_url . "&view=auth_webservice";
        $url_view_b = $base_setting_url . "&view=other_settings";
        $url_view_c = $base_setting_url . "&view=sync_tables";
        $url_view_d = $base_setting_url . "&view=hints_shortcode";
        $active_class_a = $view_type == "auth_webservice" ? "nav-tab-active" : "";
        $active_class_b = $view_type == "other_settings" ? "nav-tab-active" : "";
        $active_class_c = $view_type == "sync_tables" ? "nav-tab-active" : "";
        $active_class_d = $view_type == "hints_shortcode" ? "nav-tab-active" : "";
        ?>
        <form method="POST">
            <nav id="alocom-tabs" class="nav-tab-wrapper woo-nav-tab-wrapper">
                <a href="<?php echo $url_view_a; ?>" data-refrence="auth-to-moopress" class="nav-tab-moopress nav-tab <?php echo $active_class_a; ?>"><i class="fa fa-sign-in"></i> احراز هویت</a>
                <a href="<?php echo $url_view_b; ?>" data-refrence="others-moopress" class="nav-tab-moopress nav-tab <?php echo $active_class_b; ?>"><i class="fa fa-file-code-o"></i> تنظیمات دیگر</a>
                <a href="<?php echo $url_view_c; ?>" data-refrence="sync-moopress" class="nav-tab-moopress nav-tab <?php echo $active_class_c; ?>"><i class="fa fa-refresh"></i> همگام سازی اطلاعات</a>
                <a href="<?php echo $url_view_d; ?>" data-refrence="hints-shortcode" class="nav-tab-moopress nav-tab <?php echo $active_class_d; ?>"><i class="fa fa-exclamation-circle"></i> راهنما</a>
            </nav>
            <div id="moopress-content-admin-tab" style="height:fit-content;">
                <?php
                if ($view_type == "auth_webservice") {
                ?>
                    <div id="auth-to-moopress" style="display: block;">
                        <h2>
                            احراز هویت وب سرویس
                        </h2>
                        <div>
                            <div class="form" title="آدرس دامنه اصلی سایت مودلی خود را اینجا همراه با اسلش وارد کنید.">
                                <input placeholder="http://your_moodle/" value="<?php echo $moodle_url; ?>" style="direction: ltr;" type="text" name="moodle_url" autocomplete="new-password" />
                                <label for="text" class="label-name">
                                    <span class="content-name">
                                        آدرس مودل
                                    </span>
                                </label>
                            </div>
                            <?php
                            $tooltip_token_moodle = "";
                            if ($moodle_url) {

                                $tooltip_token_moodle .= "ابتدا به آدرس زیر بروید و مقدار توکن کاربر Moopress را کپی کنید : ";
                                $tooltip_token_moodle .= $moodle_url . "admin/webservice/tokens.php";
                                $tooltip_token_moodle .= "\n";
                                $tooltip_token_moodle .= "حال آن را به عنوان توکن مودل ثبت کنید !";
                                $tooltip_token_moodle .= " حتما دکمه ذخیره بزنید و سپس اتصال را تست کنید. ";
                            }
                            ?>
                            <div class="form" title="<?php echo $tooltip_token_moodle; ?>">
                                <input value="<?php echo $moodle_token; ?>" style="direction: ltr;" type="password" name="moodle_token" autocomplete="new-password" />
                                <label for="text" class="label-name">
                                    <span class="content-name">
                                        توکن مودل
                                    </span>
                                </label>
                            </div>
                            <br>
                            <div>
                                <a target="_blank" href="<?php echo $moodle_url . "admin/webservice/tokens.php" ?>">مشاهده لینک ذکر شده</a> <br>
                            </div>
                            <?php
                            if ($moodle_url && $moodle_token) {
                            ?>
                                <button id="moopress_test_moodle_connection" type="button" class="btn-moopress-success"> <i class="fa fa-exchange"></i> تست اتصال با مودل </button>
                                <!-- <button id="moopress_test_moodle_connection" type="button" class="btn-moopress-success"> <i class="fa fa-exchange"></i> تست اتصال با مودل </button>
                                <br>
                                <span class="moopress-hint-input"> *ابتدا حتما دکمه ذخیره بزنید و سپس اتصال را تست کنید. </span>
                                <br> -->
                            <?php
                            }
                            ?>
                            <br> <br>
                            <?php
                            $tooltip_token_wordpress = "برای ایجاد توکن وردپرس روی دکمه زیر کلیک کرده و متن ایجاد شده را کپی کنید.";
                            $tooltip_token_wordpress .= "حال توکن کپی شده به عنوان توکن وردپرس در اینجا ذخیره کنید و سپس به آدرس زیر رفته و بعنوان مقدار توکن در مودل خود ذخیره کنید. حتما آدرس صحیح وردپرس خود را هم در صفحه زیر ثبت کنید.";
                            $tooltip_token_wordpress .= $moodle_url . "admin/settings.php?section=authsettingmoojla";
                            ?>
                            <div class="form" title="<?php echo $tooltip_token_wordpress; ?>">
                                <input value="<?php echo $wordpress_token; ?>" style="direction: ltr;" type="password" name="wordpress_token" autocomplete="new-password" />
                                <label for="text" class="label-name">
                                    <span class="content-name">
                                        توکن وردپرس
                                    </span>
                                </label>
                            </div>
                            <br>
                            <div>
                                <a target="_blank" href="<?php echo $moodle_url . "admin/settings.php?section=authsettingmoojla" ?>">مشاهده لینک ذکر شده</a> <br>
                            </div>
                            <!-- <p style="font-weight:bold;">
                                برای ایجاد <span style="color: blue;">توکن وردپرس</span> روی دکمه زیر کلیک کرده و متن ایجاد شده را کپی کنید :
                            </p> -->
                            <button id="auto_generato_wordpress_token_btn" type="button" class="btn-moopress-info"> <i class="fa fa-key"></i> ایجاد توکن وردپرس </button>
                            <br><br>
                            <span id="auto_generato_wordpress_token" style="color: #3f51b5;font-weight:bold;font-size: 15px;">*</span>
                            <br> <br>
                            <?php
                            if ($moodle_url) {
                            ?>
                                <!-- <br> <br>
                                <p style="font-weight:bold;">
                                    ابتدا به آدرس زیر بروید و مقدار توکن کاربر Moopress را کپی کنید :
                                </p>
                                <div class="moopress-html-ltr">
                                    <a target="_blank" href="<?php echo $moodle_url . "admin/webservice/tokens.php" ?>"> <?php echo $moodle_url . "admin/settings.php?section=externalservices" ?></a> <br>
                                </div>
                                <p style="font-weight:bold;">
                                    حال آن را به عنوان <span style="color: blue;">توکن مودل</span> در بالا ثبت کنید !
                                </p>
                                <br> <br> -->
                            <?php
                            }
                            ?>
                            <br>
                            <!-- <p style="font-weight:bold;">
                                حال توکن کپی شده به عنوان <span style="color: blue;"> توکن وردپرس </span>در بالا ذخیره کنید و سپس به آدرس زیر رفته و بعنوان مقدار توکن در مودل خود ذخیره کنید.
                                حتما آدرس صحیح وردپرس خود را هم در صفحه زیر ثبت کنید.
                            </p> -->
                            <!-- <br>
                            <div class="moopress-html-ltr">
                                <a target="_blank" href="<?php echo $moodle_url . "admin/settings.php?section=authsettingmoojla" ?>"> <?php echo $moodle_url . "admin/settings.php?section=authsettingmoojla" ?></a> <br>
                            </div> -->

                            <p style="font-weight:bold;line-height: 1.8;">
                                توجه کنید که حتما سیاست پسورد کاربران در مودل به این صورت باشد که حداقل تعداد کاراکتر های آن 5 و حداقل دارای یک کاراکتر با حروف کوچک انگلیسی،حداقل دارای یک کاراکتر با حروف بزرگ انگلیسی و حداقل یک کاراکتر از اعداد را شامل شود.
                                در غیر این صورت کاربر در مودل ثبت نام نمی شود.
                                توجه کنید که کاربران برای ثبت سفارش باید حتما در ابتدا در سایت ثبت نام شوند.
                                لینک زیر را مشاهده کنید. ( پارامتر های Password length و ... )
                            </p>
                            <br>
                            <div class="moopress-html-ltr">
                                <a target="_blank" href="<?php echo $moodle_url . "admin/search.php?query=password" ?>"> <?php echo $moodle_url . "admin/search.php?query=password" ?></a> <br>
                            </div>
                            <br>

                            <hr>
                        </div>
                    </div>
                <?php
                } elseif ($view_type == "other_settings") {
                ?>
                    <div id="others-moopress" style="display: block;">
                        <h2>
                            تنظیمات دیگر
                        </h2>
                        <hr>
                        <div>
                            <div style="display: none;" class="form" title="آیدی نقش student در سایت مودلی شما که معمولا برابر 5 است. ">
                                <input value="<?php echo $role_id_student; ?>" style="direction: ltr;" type="number" name="role_id_student" autocomplete="new-password" />
                                <label for="text" class="label-name">
                                    <span class="content-name">
                                        آیدی نقش دانش آموز در مودل
                                    </span>
                                </label>
                            </div>
                            <br>
                            <?php
                            $force_delete_api_chk = $force_delete_api ? "checked" : "";
                            $force_content_api_chk = $force_content_api ? "checked" : "";
                            $force_title_api_chk = $force_title_api ? "checked" : "";
                            $force_course_published_chk = $force_course_published ? "checked" : "";
                            $order_enrol_status = $order_enrol_status ? $order_enrol_status : "wc-completed";
                            ?>
                            <div>
                                <input <?php echo $force_course_published_chk; ?> type="checkbox" name="force_course_published" value="1"> دوره بعد از ایجاد از طرف مودل، در وردپرس به وضعیت انتشار در بیاید ؟
                            </div>
                            <br>
                            <div>
                                <input <?php echo $force_delete_api_chk; ?> type="checkbox" name="force_delete_api" value="1"> دوره بعد حذف از طرف مودل، در وردپرس هم حذف شود ؟
                            </div>
                            <br>
                            <div>
                                <input <?php echo $force_content_api_chk; ?> type="checkbox" name="force_content_api" value="1"> محتوای دوره در وردپرس، بعد از تغییر مقدار آن در مودل و یا در همگام سازی از مودل به وردپرس، در وردپرس هم تغییر کند ؟
                            </div>
                            <br>
                            <div>
                                <input <?php echo $force_title_api_chk; ?> type="checkbox" name="force_title_api" value="1"> عنوان دوره در وردپرس، بعد از تغییر مقدار آن در مودل و یا در همگام سازی از مودل به وردپرس، در وردپرس هم تغییر کند ؟
                            </div>
                            <br>
                            <?php
                            $order_statuses = wc_get_order_statuses();

                            ?>
                            <div>
                                <label for="">وضعیت سفارش مشتریان برای اینکه در درس های آن سفارش انرول شوند ؟</label>
                                <select name="order_enrol_status" id="order_enrol_status">
                                    <?php
                                    foreach ($order_statuses as $k_order_status => $v_order_status) {
                                        $_selected = ($k_order_status == $order_enrol_status) ? "selected" : "";
                                    ?>
                                        <option <?php echo $_selected;  ?> value="<?php echo $k_order_status; ?>"><?php echo $v_order_status; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>

                            <br><br>
                            <?php
                            if ($elementor_library_templates) {
                            ?>
                                <div>
                                    <label for="">قالب المنتور مدنظر برای هدر در محتوای نمایشی وردپرس محصولات ؟</label>
                                    <select name="elementor_library_header_id" id="elementor_library_header_id">
                                        <?php
                                        $_selected_none = ((int)$elementor_library_header_id == 0) ? "selected" : "";
                                        ?>
                                        <option <?php echo $_selected_none;  ?> value="0">- بدون قالب -</option>
                                        <?php
                                        foreach ($elementor_library_templates as  $elementor_library_template) {

                                            $_selected = ((int)$elementor_library_header_id == (int)$elementor_library_template->ID) ? "selected" : "";
                                        ?>
                                            <option <?php echo $_selected;  ?> value="<?php echo $elementor_library_template->ID; ?>"><?php echo $elementor_library_template->post_title; ?></option>
                                        <?php
                                        }
                                        ?>

                                    </select>
                                </div>
                                <br><br>
                                <div>
                                    <label for="">قالب المنتور مدنظر برای فوتر در محتوای نمایشی وردپرس محصولات ؟</label>
                                    <select name="elementor_library_footer_id" id="elementor_library_footer_id">
                                        <?php
                                        $_selected_none = ((int)$elementor_library_header_id == 0) ? "selected" : "";
                                        ?>
                                        <option <?php echo $_selected_none;  ?> value="0">- بدون قالب -</option>
                                        <?php
                                        foreach ($elementor_library_templates as  $elementor_library_template) {

                                            $_selected = ((int)$elementor_library_footer_id == (int)$elementor_library_template->ID) ? "selected" : "";
                                        ?>
                                            <option <?php echo $_selected;  ?> value="<?php echo $elementor_library_template->ID; ?>"><?php echo $elementor_library_template->post_title; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <br><br>
                            <?php
                            }
                            ?>

                            <br><br>
                        </div>
                    </div>
                <?php
                } elseif ($view_type == "sync_tables") {
                ?>
                    <div id="sync-moopress" style="display: block;">
                        <h2>
                            همگام سازی اطلاعات از مودل به وردپرس
                        </h2>
                        <hr>
                        <div style="height: 50px;">
                            <button id="btn_form_moopress_sync_categories" style="margin-bottom: 30px;" type="button" class="btn-moopress-primary"> <i class="fa fa-refresh"></i> همگام سازی دسته بندی ها </button>
                            <button id="btn_form_moopress_sync_courses" style="margin-bottom: 30px;" type="button" class="btn-moopress-primary"> <i class="fa fa-refresh"></i> همگام سازی دوره ها </button>
                            <br>
                        </div>
                        <h2>
                            همگام سازی اطلاعات از وردپرس به مودل
                        </h2>
                        <hr>
                        <div style="height: 50px;">
                            <button id="btn_form_moopress_sync_users" style="margin-bottom: 30px;" type="button" class="btn-moopress-primary"> <i class="fa fa-refresh"></i> همگام سازی کاربران ها </button>
                            <br>
                        </div>
                        <div style="height: 500px;">
                            <div title="ایندکس شروع همگام سازی در آرایه گرفته شده از مودل">
                                <label for="">آفست : </label>
                                <input type="number" class="input_sync_settings" name="offset_process_sync" data-class="offset_process_input" id="offset_process_sync" value="0" min="0">
                            </div>
                            <br>
                            <div title="تعداد اعمال همگام سازی در آرایه گرفته شده از مودل">
                                <label for="">تعداد : </label>
                                <input type="number" class="input_sync_settings" name="count_process_sync" data-class="count_process_input" id="offset_process_sync" value="200" min="0">
                            </div>
                            <br>
                            <div title="تعداد انجام عملیات همگام سازی  در هر بار ریکوئست ارسالی به سرور">
                                <label for="">نرخ تازه سازی صفحه : </label>
                                <input type="number" class="input_sync_settings" name="refresh_rate_process_sync" data-class="refresh_rate_process_input" id="offset_process_sync" value="5" min="0">
                            </div>
                        </div>
                    </div>
                    <script>
                        jQuery(document).ready(function($) {
                            $('#save-moopress-settings-db').remove();
                        })
                    </script>
                <?php
                } elseif ($view_type == "hints_shortcode") {
                ?>
                    <div id="hints-shortcode" style="display: block;">
                        <h2>
                            شورتکد های مورد استفاده
                        </h2>
                        <hr>
                        <div>
                            <b>شورت کد دوره های من : (دوره های خریداری شده توسط کاربر لاگین شده فعلی)</b>
                            <p>[moopress_my_courses_enrolled]</p>
                            <br>
                            <b>شورت کد نمایش اعضای یک درس با رول آیدی مشخص مودلی:</b>
                            <p>[moopress_participants_role_id role_id='SOME_INTEGER_NUMBER']</p>
                            <a target="_blank" href="<?php echo $moodle_url . "admin/roles/manage.php" ?>">مشاهده رول های تعریف شده مودل</a> <br>
                            <b>شورت نمایش کورس ماژول های مودلی: </b>
                            <p>[moopress_course_modules_sections]</p>
                            <br>
                        </div>
                    </div>
                    <script>
                        jQuery(document).ready(function($) {
                            $('#save-moopress-settings-db').remove();
                        })
                    </script>
                <?php
                } else {
                }
                ?>
            </div>
            <button id="save-moopress-settings-db" type="submit" class="button-primary woocommerce-save-button"> <i class="fa fa-floppy-o"></i> ذخیره </button>
        </form>
        <?php
        $action_sync = get_admin_url() . "admin.php?page=lmskaran_moopress_settings&view=sync_tables&begin_sync=1";
        ?>
        <form method="POST" action="<?php echo $action_sync; ?>" id="form_moopress_sync_categories">
            <input type="hidden" name="type_sync_param" value="categories">
            <input type="hidden" name="wordpress_token_local" value="<?php echo $wordpress_token; ?>">

            <input type="hidden" class="offset_process_input" name="offset_process" value="0">
            <input type="hidden" class="count_process_input" name="count_process" value="20">
            <input type="hidden" class="refresh_rate_process_input" name="refresh_rate_process" value="10">
        </form>
        <form method="POST" action="<?php echo $action_sync; ?>" id="form_moopress_sync_courses">
            <input type="hidden" name="type_sync_param" value="courses">
            <input type="hidden" name="wordpress_token_local" value="<?php echo $wordpress_token; ?>">

            <input type="hidden" class="offset_process_input" name="offset_process" value="0">
            <input type="hidden" class="count_process_input" name="count_process" value="20">
            <input type="hidden" class="refresh_rate_process_input" name="refresh_rate_process" value="10">
        </form>
        <form method="POST" action="<?php echo $action_sync; ?>" id="form_moopress_sync_users">
            <input type="hidden" name="type_sync_param" value="users">
            <input type="hidden" name="wordpress_token_local" value="<?php echo $wordpress_token; ?>">

            <input type="hidden" class="offset_process_input" name="offset_process" value="0">
            <input type="hidden" class="count_process_input" name="count_process" value="20">
            <input type="hidden" class="refresh_rate_process_input" name="refresh_rate_process" value="10">
        </form>
    </div>
</div>
<?php
if ($view_type == "sync_tables" && ($nextStartCountRate || $begin_sync)) {
?>
    <script>
        jQuery(document).ready(function($) {
            $('#adminmenuback').hide();
            $('#adminmenuwrap').hide();
            $('#wpadminbar').hide();

        });
    </script>
<?php
}
?>