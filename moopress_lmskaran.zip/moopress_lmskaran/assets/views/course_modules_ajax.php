<div class="container">
    <?php
    $is_user_logged_in = get_current_user_id();
    if ($is_enrolled_course) {

    ?>
        <div class="moopress_course_progress_complete">
            <h2>میزان پیشروی شما در این درس:</h2><br>
            <?php if ($percentage_complete > 0) {
            ?>
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $percentage_complete; ?>%;"><?php echo $percentage_complete . "%"; ?></div>
                </div>
            <?php
            } else {
            ?>
                <h3 style="color: black;">0%</h3>
            <?php
            } ?>

        </div>

        <?php
    }
    if ($course_modules) {
        foreach ($course_modules as $cm) {
            $_invisivble_cm_class = "";
            if ((!$cm->visible || !$cm->uservisible)) {
                $_invisivble_cm_p = "moopress_invisivble_cm_class";
            }
            $modules_items = $cm->modules;
        ?>
            <div class="accordian-box-item <?php echo $_invisivble_cm_p; ?>">
                <div class="head">
                    <h2><?php echo $cm->name; ?></h2>
                    <i class="fa fa-arrow-left"></i>
                </div>
                <div class="content">
                    <div>
                        <p>
                            <?php echo $cm->summary; ?>
                        </p>
                        <hr>
                        <div class="modules">
                            <?php
                            if ($modules_items) {
                                foreach ($modules_items as $mdl_item) {
                                    $_invisivble_mdl_item_class = "";
                                    $_invisivble_mdl_item_p = "";
                                    if ((!$mdl_item->visible || !$mdl_item->uservisible)) {
                                        $_invisivble_mdl_item_class = "moopress_invisivble_mdl_item_class";
                                        $_invisivble_mdl_item_p = "<p style='color: #bc2626;font-size: 18px;font-weight: bold;'>(به این بخش دسترسی ندارید !)</p>";
                                    }
                            ?>
                                    <div class="<?php echo $_invisivble_mdl_item_class; ?>">
                                        <?php
                                        if (@$mdl_item->url) {
                                            if ($_invisivble_mdl_item_class) {
                                                $mdl_item->url = "javascript:void(0);";
                                            }
                                            $extra_quiz_link = "";
                                            if (@$mdl_item->modname == "quiz") {
                                                $extra_quiz_link = get_site_url() . "/moopress_moodle_quiz_hold/?frame_url=" . base64_encode($mdl_item->url);
                                                $mdl_item->url = $extra_quiz_link;
                                            }
                                        ?>
                                            <div class="moopress-module-container">
                                                <div class="moopress-module-half-1"> <a target="_blank" href="<?php echo @$mdl_item->url; ?>"><img style="width: 20px;height:20px;" src="<?php echo $mdl_item->modicon; ?>" alt=""></a></div>
                                                <div class="moopress-module-half-2">
                                                    <a target="_blank" href="<?php echo @$mdl_item->url; ?>">
                                                        <h3 style="color:#673ab7;"><?php echo $mdl_item->name; ?></h3>
                                                        <?php
                                                        echo  $_invisivble_mdl_item_p;
                                                        ?>
                                                    </a>

                                                </div>
                                            </div>
                                        <?php
                                        } else {
                                        ?>
                                            <div class="moopress-module-container-content">
                                                <?php echo $mdl_item->description; ?>
                                            </div>
                                        <?php
                                        }
                                        ?>

                                    </div>
                                    <hr>
                            <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <br>
    <?php
        }
    }
    ?>
</div>
<script>
    jQuery(document).ready(function($) {
        $('#moopress-course-modules .head').click(function() {
            $(this).toggleClass('active');
            $(this).parent().find('.fa-arrow-left').toggleClass('fa-arrow-down');
            $(this).parent().find('.content').slideToggle(280);
        });
    });
</script>