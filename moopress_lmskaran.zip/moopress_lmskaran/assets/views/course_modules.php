
<div id="moopress-course-modules">
    <div class="loading-state">
        <img src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-1.gif"; ?>" alt="">
        <input type="hidden" name="wp-ajax-url" value="<?php echo get_site_url() . "/wp-admin/admin-ajax.php"; ?>">
        <input type="hidden" name="cid" value="<?php echo $course_id_mdl; ?>">
    </div>
</div>
<?php
$moopress_error_cart = @$_GET['moopress_error_cart'] ? base64_decode($_GET['moopress_error_cart']) : "";

if($moopress_error_cart){
    ?>
    <script>
    jQuery(document).ready(function($) {
        var _moopress_error_cart = "<?php echo $moopress_error_cart; ?>";
        Swal.fire({
            title: 'توجه !',
            html: _moopress_error_cart,
            icon: 'error',
            confirmButtonText: 'بستن'
        });
    });
</script>
    <?php
}

