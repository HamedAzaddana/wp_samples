<?php
if ($course_id_mdl) {
    $gif_error_ajax_src =  get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/error-icon-1.gif";
?>

    <div id="moopress_subMetaBox_add_participant" style="display: flex;">
        <div>
            <label for="">کاربر :</label>
            <select name="mprs_ajax_user_id" id="mprs_ajax_user_id" class="moopress-select2">
                <option value="0" selected>- انتخاب کنید -</option>
                <?php
                foreach ($users_moodle as $user_moodle) {
                    $user_id = $user_moodle->ID;
                    $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));
                    $user_login = $user_moodle->data->user_login;
                    $m_lastname = get_user_meta($user_id, 'last_name', true);
                    $m_firstname = get_user_meta($user_id, 'first_name', true);
                    $m_fullname = $m_firstname . " " . $m_lastname;
                ?>
                    <option value="<?php echo $user_id ?>"><?php echo $m_fullname . "($user_login)"; ?></option>
                <?php
                }
                ?>
            </select>
            &nbsp;&nbsp;&nbsp;
        </div>
        <div>
            <label for="">نقش کاربری :</label>
            <select name="mprs_ajax_moodle_role" id="mprs_ajax_moodle_role" class="moopress-select2">
                <option value="0___null" selected>- انتخاب کنید -</option>
                <?php
                foreach ($roles as $role) {
                    $role_id = $role->id;
                    $role_title = $role->shortname;
                ?>
                    <option value="<?php echo $role_id . "___" . $role_title ?>"><?php echo $role_title; ?></option>
                <?php
                }
                ?>
            </select>
            &nbsp;&nbsp;&nbsp;
        </div>
        <div>
            &nbsp;&nbsp;&nbsp;
            <button id="moopress-action-add-participants" style="background: #6772a8;border-color: #6772a8;" type="button" class="button button-primary button-large">
                افزودن <i class="fa fa-plus-square-o"></i>
            </button>
        </div>
    </div>
    <br><br>
    <hr>
    <input type="text" name="search_keyWord_customer" id="search_keyWord_customer" placeholder="کلمه کلیدی جستجو ..." id="">
    <button id="search_keyWord_customer_action" style="background: #22b14a;border-color: #22b14a;" type="button" class="button button-primary button-large">
        <i class="fa fa-search"></i>
    </button>
    <br><br>
    <div id="moopress_subMetaBox_participants">
        <div style="justify-content: center;display: flex;">
            <img id="moopress_image_participants_ajax_status" style="width: 50%;height: 300px;" src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-3.gif"; ?>" alt="">
        </div>
    </div>
    <script>
        jQuery(document).ready(function($) {
            $('.moopress-select2').select2({
                placeholder: "",
                dir: "rtl",
            });
            var course_moodle_id = parseInt("<?php echo $course_id_mdl; ?>");
            var course_wp_id = parseInt("<?php echo $course_id_wp; ?>");

            $('#moopress-action-add-participants').on('click', function() {
                var _btn = $(this);
                var _btn_html = _btn.html();
                var _loading_html = ` <i class="fa fa-spin fa-spinner"></i>`;
                var ajax_moopress_url = cmb2_l10.ajaxurl;
                var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
                var user_id = $('#mprs_ajax_user_id').select2("val");
                var role = $('#mprs_ajax_moodle_role').select2("val");

                $.ajax({
                    url: ajax_moopress_url,
                    type: "POST",
                    data: {
                        action: "add_manual_participant_course",
                        course_moodle_id,
                        moopress_csrf_token,
                        course_wp_id,
                        role,
                        user_id,
                    },
                    beforeSend: function() {
                        _btn.html(_loading_html);
                    },
                    complete: function(res) {
                        _btn.html(_btn_html);
                        var status_code = res.status;
                        if (status_code == 200) {
                            GetParticipantsCourse('', 1, course_moodle_id);
                        }
                    },
                    error: function(res) {
                        var status_code = res.status;
                        if (status_code != 200) {
                            var msg = res.responseJSON.data;
                            Swal.fire({
                                title: 'توجه !',
                                text: msg,
                                icon: 'error',
                                confirmButtonText: 'بستن'
                            })
                        }
                    }
                });
            });

            function GetParticipantsCourse(KeyWord = '', paged_num = 1, course_moodle_id = 0) {
                var _participants_div = $('#moopress_subMetaBox_participants');
                var ajax_moopress_url = cmb2_l10.ajaxurl;
                var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
                var loading_gif = `
                <div style="justify-content: center;display: flex;">
                  <img id="moopress_image_participants_ajax_status" style="width: 50%;height: 300px;" src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-3.gif"; ?>" alt="">
                </div>
            `;
                $.ajax({
                    url: ajax_moopress_url,
                    type: "POST",
                    data: {
                        action: "get_course_participants_moodle",
                        KeyWord: KeyWord,
                        paged_num: paged_num,
                        course_moodle_id: course_moodle_id,
                        moopress_csrf_token: moopress_csrf_token,
                    },
                    beforeSend: function() {
                        _participants_div.html(loading_gif);
                    },
                    complete: function(res) {
                        _participants_div.html(res.responseText);
                    },
                    error: function(res) {
                        console.log(res)
                        $('#moopress_image_participants_ajax_status').attr("src", "<?php echo $gif_error_ajax_src ?>");
                        var status_code = res.status;

                        if (status_code != 200) {
                            var msg = res.responseJSON.data;
                            Swal.fire({
                                title: 'توجه !',
                                text: msg,
                                icon: 'error',
                                confirmButtonText: 'بستن'
                            })
                        }
                    }
                });
            }
            if (document.readyState === 'ready' || document.readyState === 'complete') {
                GetParticipantsCourse('', 1, course_moodle_id);
            } else {
                document.onreadystatechange = function() {
                    if (document.readyState == "complete") {
                        GetParticipantsCourse('', 1, course_moodle_id);
                    }
                }
            }

            $('#search_keyWord_customer_action').on('click', function() {
                var kword = $('#search_keyWord_customer').val();
                GetParticipantsCourse(kword, 1, course_moodle_id);
            });
            $('#search_keyWord_customer').keypress(function(e) {
                var key = e.which;
                if (key == 13) // the enter key code
                {
                    $('#search_keyWord_customer_action').click();
                    return false;
                }
            });
        });
    </script>
<?php
} else {
?>
    <div>
        <h3 style="color: red;">* این محصول به صورت دوره در مودل ثبت نشده است.</h3>
    </div>
<?php
}
