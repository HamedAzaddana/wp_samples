<?php

?>
<div class="moopress_card" id="moopress_settings">
    <h1> <i class="fa fa-users"></i> کاربران ثبت نام شده در مودل</h1>
    <hr>
    <div style="display: flex;">
        <div>
            <label>کاربر :</label>
            <select name="mprs_ajax_user_id" id="mprs_ajax_user_id" class="moopress-select2">
                <option value="0" selected>- انتخاب کنید -</option>
                <?php
                foreach ($users_moodle as $user_moodle) {
                    $user_id = $user_moodle->ID;
                    $user_id_mdl = intval(get_user_meta($user_id, "user_id_mdl", true));
                    $user_login = $user_moodle->data->user_login;
                    $m_lastname = get_user_meta($user_id, 'last_name', true);
                    $m_firstname = get_user_meta($user_id, 'first_name', true);
                    $m_fullname = $m_firstname . " " . $m_lastname;
                ?>
                    <option value="<?php echo $user_id ?>"><?php echo $m_fullname . "($user_login)"; ?></option>
                <?php
                }
                ?>
            </select>
            &nbsp;&nbsp;&nbsp;
        </div>
        <div >
            <input style="display: none;" type="text" name="search_keyWord_customer" id="search_keyWord_customer" placeholder="کلمه کلیدی جستجو ...">
            <button id="search_keyWord_customer_action" style="background: #22b14a;border-color: #22b14a;" type="button" class="button button-primary button-large">
                <i class="fa fa-search"></i>
            </button>
        </div>
    </div>
    <br><br>
    <div id="moopress_subMetaBox_participants">
        <div style="justify-content: center;display: flex;">
            <img id="moopress_image_participants_ajax_status" style="width: 50%;height: 300px;" src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-3.gif"; ?>" alt="">
        </div>
    </div>
</div>
<script>
    jQuery(document).ready(function($) {
        $('.moopress-select2').select2({
            placeholder: "",
            dir: "rtl",
        });
        var course_moodle_id = 0

        function GetParticipantsCourse(KeyWord = '', paged_num = 1, course_moodle_id = 0) {
            var _participants_div = $('#moopress_subMetaBox_participants');
            var ajax_moopress_url = cmb2_l10.ajaxurl;
            var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
            var loading_gif = `
            <div style="justify-content: center;display: flex;">
               <img id="moopress_image_participants_ajax_status" style="width: 50%;height: 300px;" src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-3.gif"; ?>" alt="">
            </div>
            `;
            var user_id_selected = $('#mprs_ajax_user_id').select2("val");

            $.ajax({
                url: ajax_moopress_url,
                type: "POST",
                data: {
                    action: "get_course_participants_moodle",
                    KeyWord: KeyWord,
                    paged_num: paged_num,
                    course_moodle_id: course_moodle_id,
                    moopress_csrf_token: moopress_csrf_token,
                    user_id_selected:user_id_selected
                },
                beforeSend: function() {
                    _participants_div.html(loading_gif);
                },
                complete: function(res) {
                    _participants_div.html(res.responseText);
                },
                error: function(res) {
                    console.log(res)
                    $('#moopress_image_participants_ajax_status').attr("src", "<?php echo $gif_error_ajax_src ?>");
                    var status_code = res.status;

                    if (status_code != 200) {
                        var msg = res.responseJSON.data;
                        Swal.fire({
                            title: 'توجه !',
                            text: msg,
                            icon: 'error',
                            confirmButtonText: 'بستن'
                        })
                    }
                }
            });
        }
        if (document.readyState === 'ready' || document.readyState === 'complete') {
            GetParticipantsCourse('', 1, course_moodle_id);
        } else {
            document.onreadystatechange = function() {
                if (document.readyState == "complete") {
                    GetParticipantsCourse('', 1, course_moodle_id);
                }
            }
        }

        $('#search_keyWord_customer_action').on('click', function() {
            var kword = $('#search_keyWord_customer').val();
            GetParticipantsCourse(kword, 1, course_moodle_id);
        });
        $('#search_keyWord_customer').keypress(function(e) {
            var key = e.which;
            if (key == 13) // the enter key code
            {
                $('#search_keyWord_customer_action').click();
                return false;
            }
        });
    });
</script>