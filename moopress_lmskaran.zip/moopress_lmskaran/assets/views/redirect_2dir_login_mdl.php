<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->
<script>
    jQuery(document).ready(function($) {
        let main_url= window.location.href.replace(/\?moopress_wp2m_login=.*/, "");
        window.history.replaceState('', '', main_url);
        // let return_to_dec = new URL("php echo $return_to_dec; ");
        // return_to_dec.searchParams.delete('moopress_wp2m_login');
        // return_to_dec.searchParams.delete('return_to');

        // $('a').attr('href', 'javascript: void(0)');
        $('button,input[type=submit]').attr('disabled', 'disabled');
        $.ajax({
            type: "GET",
            url: "<?php echo $moopress_wp2m_login_dec; ?>",
            data: {},
            success: function(result) {
                // console.log(result);
                // console.log(return_to_dec);
                // document.write = result;
                // window.location.replace(return_to_dec);
            }
        });
    });
</script>