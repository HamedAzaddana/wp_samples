<script>
    //sync button for single product
    jQuery(document).ready(function($) {
        var ajax_moopress_url = "<?php echo $ajax_url_wp; ?>";
        var moopress_csrf_token = $('#Moopress_Csrf_Token').val();

        function moopress_sync_course_to_moodle(ajax_url, moopress_csrf_token, product_id,BtnPushed) {
            var _btn = BtnPushed;
            _btn.attr('disabled', 'disabled');
            var _btn_html = _btn.html();
            var _loading_content = ` <i class="fa fa-refresh fa-spin"></i> همگام سازی به مودل `;
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: {
                    action: "sync_product_to_moodle_force",
                    moopress_csrf_token,
                    product_id
                },
                beforeSend: function() {
                    _btn.html(_loading_content)
                },
                complete: function(res) {
                    var status_code = res.status;
                    var msg = res.responseJSON.data;
                    if (status_code != 200) {
                        Swal.fire({
                            title: 'توجه !',
                            html: msg,
                            icon: 'error',
                            confirmButtonText: 'بستن'
                        })
                    } else {
                        Swal.fire({
                            title: 'عالیه !',
                            html: msg,
                            icon: 'success',
                            confirmButtonText: 'بستن'
                        })
                        location.reload();
                    }
                    _btn.removeAttr('disabled');
                    _btn.html(_btn_html)
                },

            });
        }
        //sync button for single product from moodle
        $('#moopress_sync_single_product').click(function(e) {
            e.preventDefault();
            var _btn = $(this);
            _btn.attr('disabled', 'disabled');
            var _btn_html = _btn.html();
            var _loading_content = ` <i class="fa fa-refresh fa-spin"></i> همگام سازی از مودل `;
            var product_id = parseInt(_btn.attr('data-pid'));

            $.ajax({
                url: ajax_moopress_url,
                type: "POST",
                data: {
                    action: "sync_product_from_moodle",
                    moopress_csrf_token,
                    product_id
                },
                beforeSend: function() {
                    _btn.html(_loading_content)
                },
                complete: function(res) {
                    var status_code = res.status;
                    var msg = res.responseJSON.data;
                    if (status_code != 200) {
                        Swal.fire({
                            title: 'توجه !',
                            html: msg,
                            icon: 'error',
                            confirmButtonText: 'بستن'
                        })
                    } else {
                        Swal.fire({
                            title: 'عالیه !',
                            html: msg,
                            icon: 'success',
                            confirmButtonText: 'بستن'
                        })
                        location.reload();
                    }
                    _btn.removeAttr('disabled');
                    _btn.html(_btn_html)
                },

            });

        });
        //sync button for single product to moodle
        $('#moopress_sync_single_product_to_moodle').click(function(e) {
            var _btn = $(this);
            var product_id = parseInt(_btn.attr('data-pid'));
            Swal.fire({
                title: `اخطار`,
                text: `آیا برای همگام سازی این محصول در مودل مطمئن هستید ؟`,
                allowOutsideClick: true,
                showCancelButton: true,
                showConfirmButton: true,
                showDenyButton: false,
                confirmButtonText: 'تایید',
                cancelButtonText: 'انصراف',
            }).then((result) => {
                if (result.isConfirmed) {
                    moopress_sync_course_to_moodle(ajax_moopress_url, moopress_csrf_token, product_id,_btn)
                }
            });

        });
    })
</script>