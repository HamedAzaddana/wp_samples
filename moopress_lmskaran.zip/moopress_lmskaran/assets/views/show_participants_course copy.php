<?php
if ($course_id_mdl) {
?>
    <div id="moopress_subMetaBox_participants">

    </div>
    <script>
        jQuery(document).ready(function($) {
            var _participants_div = $('#moopress_subMetaBox_participants');
            


        });
    </script>
<?php
} else {
?>
    <div>
        <h3 style="color: red;">* این محصول به صورت دوره در مودل ثبت نشده است.</h3>
    </div>
<?php
}
