<div class="moopress_shortcode_participants_role">
    <?php
    if ($participants) {
        foreach ($participants as $key_prt => $participant) {
            $user_info = $participant['user_info'];
            $order_info = $participant['order_info'];
            $user_id = intval($user_info->data->ID);
            $username = $user_info->data->user_login;
            $first_name = get_user_meta($user_info->ID, 'first_name', true);
            $last_name = get_user_meta($user_info->ID, 'last_name', true);
            $user_id_mdl = (int)get_user_meta($user_info->ID, 'user_id_mdl', true);
            $full_name = $first_name . " " . $last_name;
            $order_id = (int)@$order_info->ID;
            $order_status = $order_info->post_status;
    ?>
            <p> * <?php echo $full_name ?></p> <br>
    <?php
        }
    }

    ?>
</div>