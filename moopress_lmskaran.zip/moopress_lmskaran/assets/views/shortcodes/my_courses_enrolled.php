<?php
if (get_current_user_id()) {
    if ($courses_user) {
?>
        <div class="moopress_my_courses_container">
            <?php
            foreach ($courses_user as $course) {
                $course_post = $course['course_post'];
                $course_id = $course_post->ID;
                $course_title = $course_post->post_title;
                $course_status = $course_post->post_status;
                $role_title = $course['role_title'];
                $created_at_jalali = $course['created_at_jalali'];
                $course_image = @wp_get_attachment_image_src(get_post_thumbnail_id($course_id), 'single-post-thumbnail')[0];
                if (!$course_image) {
                    $course_image = site_url("/wp-content/plugins/moopress_lmskaran/assets/img/my_course_default.png");
                }
                $course_wp_link  = get_permalink($course_id);
                $course_moodle_link  = get_post_meta($course_id, 'course_moodle_url', true);
                if ($course_status != 'publish') {
                    continue;
                }
            ?>
                <div class="moopress_my_courses_item">
                    <div class="moopress_my_courses_item_img">
                        <img src="<?php echo $course_image; ?>" alt="<?php echo $course_title; ?>">
                    </div>
                    <div class="moopress_my_courses_item_body">
                        <h3><?php echo $course_title; ?></h3>
                    </div>
                    <hr>
                    <div class="moopress_my_courses_item_footer">
                        <a href="<?php echo $course_wp_link; ?>" type="button" class="btnm-info">مشاهده درس</a>
                        <br><br><br>
                        <a href="<?php echo $course_moodle_link; ?>" target="_blank" type="button" class="btnm-success">مشاهده درس در سامانه مدیریت یادگیری</a>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    <?php
    } else {
    ?>
        <div class="woocommerce-info">
            تاکنون در هیچ درسی ثبت نام نکرده اید !
        </div>
    <?php
    }
} else {
    ?>
    <div class="woocommerce-error">
        باید ابتدا وارد سایت شوید.
    </div>
<?php
}
?>