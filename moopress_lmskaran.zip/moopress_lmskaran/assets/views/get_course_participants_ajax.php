<?php

if ($participants) {
?>
    <table class="wp-list-table widefat fixed striped" id="tbl_moodle_participants">
        <thead style="position:sticky;top:30px;background-color:#B8B3B3;font-weight:bolder;text-align: center;">
            <tr style="text-align: center;">
                <th style="text-align: center;">نام و نام خانوادگی</th>
                <th style="text-align: center;">نام کاربری وردپرس</th>
                <?php
                if (!$course_moodle_id) {
                ?>
                    <th style="text-align: center;"> دوره</th>
                <?php
                }
                ?>
                <th style="text-align: center;"> سفارش</th>
                <th style="text-align: center;">نقش کاربر</th>
                <th style="text-align: center;">درصد پیشروی</th>
                <th style="text-align: center;">تاریخ عضویت</th>
                <th style="text-align: center;">حذف</th>

            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($participants as $key_prt => $participant) {
                $user_info = $participant['user_info'];
                $order_info = $participant['order_info'];
                $user_id = intval($user_info->data->ID);
                $username = $user_info->data->user_login;
                $first_name = get_user_meta($user_info->ID, 'first_name', true);
                $last_name = get_user_meta($user_info->ID, 'last_name', true);
                $user_id_mdl = (int)get_user_meta($user_info->ID, 'user_id_mdl', true);
                $full_name = $first_name . " " . $last_name;
                $order_id = (int)@$order_info->ID;
                $order_status = $order_info->post_status;
            ?>
                <tr style="text-align: center;vertical-align:middle;" data-row="<?php echo $key_prt; ?>">
                    <td style="text-align: center;vertical-align:middle;">
                        <?php echo $full_name; ?>
                    </td>
                    <td style="text-align: center;vertical-align:middle;">
                        <a href="<?php echo admin_url() . "user-edit.php?user_id=" . $user_id; ?>" target="_blank">
                            <?php
                            echo $username;
                            ?>
                        </a>
                    </td>
                    <?php
                    $course_moodle_id_delete = 0;
                    if (!$course_moodle_id) {
                        $course_info = $participant['course_info'];
                        $course_id = (int)@$course_info->ID;
                        $course_moodle_meta_id = (int)get_post_meta($course_id, 'course_id_mdl', true);
                        $course_moodle_id_delete = $course_moodle_meta_id;
                    ?>
                        <td>
                            <?php
                            if ($course_id) {
                            ?>
                                <a href="<?php echo admin_url() . "post.php?post=$course_id&action=edit"; ?>" target="_blank">
                                    <?php echo $course_info->post_title; ?>
                                </a>
                            <?php
                            } else {
                            ?>
                                --
                            <?php
                            }
                            ?>
                        </td>
                    <?php
                    } else {
                        $course_moodle_id_delete = $course_moodle_id;
                    }
                    ?>
                    <td>
                        <?php
                        if ($order_id) {
                        ?>
                            <a href="<?php echo admin_url() . "post.php?post=$order_id&action=edit"; ?>" target="_blank">
                                مشاهده سفارش (<?php echo $order_status; ?>)
                            </a>
                        <?php
                        } else {
                        ?>
                            --
                        <?php
                        }
                        ?>

                    </td>
                    <td>
                        <?php
                        echo $participant['role_title'];
                        ?>
                    </td>
                    <td>
                        <?php
                        $percentage_complete = \LmskaranMoopress\Controllers\Webservice\MoodleController::get_course_complete_percentages($course_moodle_id_delete, $user_id_mdl);
                        echo "$percentage_complete%";
                        ?>
                    </td>
                    <td>
                        <?php
                        echo $participant['created_at_jalali'];
                        ?>
                    </td>
                    <td>
                        <button fullname="<?php echo $full_name; ?>" role-id="<?php echo $participant['role_id']; ?>" course-id="<?php echo $course_moodle_id_delete; ?>" user-id="<?php echo $user_id_mdl; ?>" style="" type="button" class="btn-go-delete-ajax unenroll_participant"> <i class="fa fa-trash"></i> </button>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
    <center style="margin:10px ;">
        تعداد نتایج : <?php echo $cnt_results; ?>
        <br>
        <div class="pagination_moopress_participants pagination_moopress_elements" style="padding:10px;">

            <a class="pagins go_prev_page" go-number-page="<?php echo $paged_num - 1; ?>" href="#page-prev-<?php echo $paged_num - 1; ?>" <?php if ($paged_num == 1) {
                                                                                                                                                echo " style='display:none;' ";
                                                                                                                                            } ?>>&raquo;</a>
            <?php

            for ($i = 1; $i <= $links_num; $i++) :
            ?>
                <a href="#page-<?php echo $i; ?>" class="pagins go_this_page  <?php if ($paged_num == $i) {
                                                                                    echo "active";
                                                                                } ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor;  ?>
            <a class="pagins go_next_page" go-number-page="<?php echo $paged_num + 1; ?>" href="#page-next-<?php echo $paged_num + 1; ?>" <?php if ($paged_num == $last_num_paged) {
                                                                                                                                                echo " style='display:none;' ";
                                                                                                                                            } ?>>&laquo;</a>
        </div>
    </center>
<?php
} else {
?>
    <center>
        <h3 style="color:red;">نتیجه ای یافت نشد !</h3>
    </center>
<?php
}
?>
<script>
    jQuery(document).ready(function($) {

        //Fuctions 
        function conv_num_to_en(txt) {
            txt = txt.replaceAll("۱", "1");
            txt = txt.replaceAll("۲", "2");
            txt = txt.replaceAll("۳", "3");
            txt = txt.replaceAll("۴", "4");
            txt = txt.replaceAll("۵", "5");
            txt = txt.replaceAll("۶", "6");
            txt = txt.replaceAll("۷", "7");
            txt = txt.replaceAll("۸", "8");
            txt = txt.replaceAll("۹", "9");
            txt = txt.replaceAll("۰", "0");
            return txt;
        }
        var course_moodle_id = parseInt("<?php echo $course_moodle_id; ?>");

        function GetParticipantsCourse(KeyWord = '', paged_num = 1, course_moodle_id = 0) {
            var _participants_div = $('#moopress_subMetaBox_participants');
            var ajax_moopress_url = cmb2_l10.ajaxurl;
            var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
            var loading_gif = `
            <div style="justify-content: center;display: flex;">
               <img id="moopress_image_participants_ajax_status" style="width: 50%;height: 300px;" src="<?php echo get_site_url() . "/wp-content/plugins/moopress_lmskaran/assets/img/loading-icon-3.gif"; ?>" alt="">
            </div>
            `;
            $.ajax({
                url: ajax_moopress_url,
                type: "POST",
                data: {
                    action: "get_course_participants_moodle",
                    KeyWord: KeyWord,
                    paged_num: paged_num,
                    course_moodle_id: course_moodle_id,
                    moopress_csrf_token: moopress_csrf_token,
                },
                beforeSend: function() {
                    _participants_div.html(loading_gif);
                },
                complete: function(res) {
                    _participants_div.html(res.responseText);
                },
                error: function(res) {
                    console.log(res)
                    $('#moopress_image_participants_ajax_status').attr("src", "<?php echo $gif_error_ajax_src ?>");
                    var status_code = res.status;

                    if (status_code != 200) {
                        var msg = res.responseJSON.data;
                        Swal.fire({
                            title: 'توجه !',
                            text: msg,
                            icon: 'error',
                            confirmButtonText: 'بستن'
                        })
                    }
                }
            });
        }

        //Pagination Hide Links

        var links_pagination = $(".pagination_moopress_participants a");

        var number_pages = links_pagination.length;
        var last_page_num = links_pagination.length - 2;
        var active_link = $(".pagination_moopress_participants a.active");
        var active_page_number = parseInt(conv_num_to_en(active_link.text()));
        var showed_just_nums = [1, 2, 3, last_page_num, last_page_num - 1, last_page_num - 2, last_page_num - 3, active_page_number, active_page_number + 1, active_page_number + 2, active_page_number + 3,
            active_page_number - 1, active_page_number - 2, active_page_number - 3,
        ];

        for (var pi = 0; pi < number_pages; ++pi) {
            var page_item = links_pagination[pi];
            var px = parseInt(conv_num_to_en(links_pagination[pi].innerText));
            if (px) {
                if (!showed_just_nums.includes(px)) {
                    page_item.style.display = "none";
                    page_item.classList.add("hidden_page_item");
                }
            }

        }
        var links_pagination_hidden = $(".pagination_moopress_participants a.hidden_page_item");
        var links_pagination_hidden_last_index = links_pagination_hidden.length - 1;
        if (links_pagination_hidden[links_pagination_hidden_last_index] && links_pagination_hidden_last_index) {
            links_pagination_hidden[links_pagination_hidden_last_index].style.display = "block";
            links_pagination_hidden[links_pagination_hidden_last_index].innerText = "...";
            links_pagination_hidden[links_pagination_hidden_last_index].href = "javascript:void(0)";
            links_pagination_hidden[links_pagination_hidden_last_index].onclick = (e) => {
                e.preventDefault();
            }
        }

        if (links_pagination_hidden[0]) {
            links_pagination_hidden[0].style.display = "block";
            links_pagination_hidden[0].innerText = "...";
            links_pagination_hidden[0].href = "javascript:void(0)";
            links_pagination_hidden[0].onclick = (e) => {
                e.preventDefault();
            }
        }




        //Pagination Show
        $('.pagination_moopress_participants a').click(function() {
            event.preventDefault();
            var thisa = $(this);
            var current_page = parseInt("<?php echo $paged_num; ?>");
            var gonumber = 1;
            var kw_search = "<?php echo $KeyWord; ?>";
            if (thisa.hasClass('go_this_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.text()));
            }
            if (thisa.hasClass('go_next_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.attr('go-number-page')));
            }
            if (thisa.hasClass('go_prev_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.attr('go-number-page')));
            }
            GetParticipantsCourse(kw_search, gonumber, course_moodle_id)
        });
        //unenroll from course
        $('#tbl_moodle_participants .unenroll_participant').click(function(e) {
            var role_id = $(this).attr('role-id');
            var user_id = $(this).attr('user-id');
            var course_id = $(this).attr('course-id');
            var fullname = $(this).attr('fullname');

            Swal.fire({
                title: `اخطار`,
                text: `آیا برای حذف کاربر ${fullname} از این درس مطمئن هستید ؟`,
                allowOutsideClick: true,
                showCancelButton: true,
                showConfirmButton: false,
                showDenyButton: true,
                denyButtonText: 'حذف',
                cancelButtonText: 'انصراف',
            }).then((result) => {
                if (result.isDenied) {
                    var ajax_moopress_url = cmb2_l10.ajaxurl;
                    var moopress_csrf_token = $('#Moopress_Csrf_Token').val();
                    $.ajax({
                        url: ajax_moopress_url,
                        type: "POST",
                        data: {
                            action: "unenroll_participants_moodle",
                            moopress_csrf_token,
                            role_id,
                            user_id,
                            course_id,
                        },
                        beforeSend: function() {

                        },
                        complete: function(res) {
                            GetParticipantsCourse('', 1, course_moodle_id)
                        },
                        error: function(res) {
                            console.log(res)

                            var status_code = res.status;

                            if (status_code != 200) {
                                var msg = res.responseJSON.data;
                                Swal.fire({
                                    title: 'توجه !',
                                    text: msg,
                                    icon: 'error',
                                    confirmButtonText: 'بستن'
                                })
                            }
                        }
                    });
                }
            });
        });
    });
</script>