<?php
/*
Plugin Name: Moopress Lmskaran
Plugin URI: https://lmskaran.com/
Description: This plugin is the best wordpress application for create connection between moodle and wordpress via woocommenrce !
Version: 1.0.0
Author: lmskaran
Author URI: https://lmskaran.com/
License: MIT
License URI: https://opensource.org/licenses/MIT
Text Domain: lmskaran-moopress
Domain Path: /assets/lang
Requires PHP: 5.4
*/
//------------------------------------------------------------
//
// NOTE:
//
// Try NOT to add any code line in this file.
//
// Use "app\Main.php" to add your hooks.
//
//------------------------------------------------------------
define('MOOPRESS_PLUGIN_FILE_MAIN', (__FILE__));
require_once( __DIR__ . '/app/Boot/bootstrap.php' );