<?php
/*
Plugin Name: ماژول آزمون تعیین سطح
Description: این ماژول جهت مدیریت آزمون تعیین سطح الزامی است که نصب و فعال باشد.
Version: 1.0
Author: Hamed Azaddana
*/
if (!function_exists('add_action')) {
    echo "I'm just a simple plugin !";
    exit();
}

if (!defined('ABSPATH')) {
    exit;
}
define('utec_quiz_version', '1.0.0');
define('utec_quiz_plugin_dir', (__DIR__ ));
define('utec_quiz_plugin_url', trailingslashit(plugin_dir_url(__FILE__) . ""));
define('utec_quiz_views_path', trailingslashit(plugin_dir_path(__FILE__) . "Views/"));
define('utec_quiz_temp_path', trailingslashit(plugin_dir_path(__FILE__) . "Temp/"));
define('utec_quiz_assets_path', trailingslashit(plugin_dir_path(__FILE__) . "assets/"));
define('utec_quiz_assets_url', trailingslashit(plugin_dir_url(__FILE__) . "assets/"));
define('utec_quiz_plugin_file', (__FILE__ ));


require_once __DIR__ . "/vendor/autoload.php";

use Utec\Quiz\Controllers\UtecQuizLoader;

if (defined('utec_auth_env_path')) {
    (new UtecQuizLoader())->initiate();  
}

