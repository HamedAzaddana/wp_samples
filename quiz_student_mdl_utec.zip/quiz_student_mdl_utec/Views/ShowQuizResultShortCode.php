<?php

if (is_user_logged_in()) {
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $username = $user->data->user_login;
    if (isset($_GET['code'])) {
        $code_id = sanitize_text_field($_GET['code']);
        $result_id = base64_decode($code_id);
        global $wpdb;
        $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
        $usr_id = get_current_user_id();
        $quiz_results = $wpdb->get_results("SELECT * FROM `$tbl_result` WHERE `id` = '$result_id' AND `user_id` = '$usr_id' ");
        if ($quiz_results) {
?>
            <div id="utec-All-Result-Container">
                <?php
                //get settings
                $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
                $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
                $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');

                $args_query_prod_cate = array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false,
                );
                $args_query_prod_skill = array(
                    'taxonomy' => 'skill-category',
                    'hide_empty' => false,
                );
                $product_cates_all = get_terms($args_query_prod_cate);
                $product_skills = get_terms($args_query_prod_skill);

                $product_cates = [];

                foreach ($product_cates_all as $cate) {
                    if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                        $product_cates[] = $cate;
                    }
                }
                $utec_level_results_intervals = unserialize(get_option("utec_level_results_intervals", "")) ?
                    unserialize(get_option("utec_level_results_intervals", "")) : [];
                $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
                    unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];

                //the rest
                date_default_timezone_set('Asia/Tehran');
                $quiz_results = $quiz_results[0];
                $result_array = unserialize(base64_decode($quiz_results->results));
                // utec_dd($result_array);
                $date = $quiz_results->date;
                $date_pers = utec_auth_sanitize_to_fa(jdate("Y/m/d", $date));
                ?>
                <h2>نتیجه این آزمون تعیین سطح :
                    <span style="font-size:18px;color:#534747;"> (تاریخ : <?php echo $date_pers; ?>)</span>
                </h2>
                <br>
                <?php
                $Courses_Ids = [];
                foreach ($product_cates as $level) {
                    $level_id = $level->term_id;
                    $level_title = $level->name;
                    $level_desc = term_description($level_id);
                    $level_color = get_term_meta($level_id, "color_level", true);

                    $key_settingsLevel = "settings_level_" . $level_id;
                    $level_settings = [];
                    foreach ($utec_settings_quiz as $Key_setting => $itemSetting) {
                        if ($Key_setting == $key_settingsLevel) {
                            $level_settings = $itemSetting;
                        }
                    }
                    $method_grading_level = $level_settings['method_grading_level'];
                    $skill_garades_for_the_level = [];
                    $level_grade_user = 0;
                    $level_grade_user_final = 0;
                    foreach ($result_array as $result_item) {
                        if ($result_item['level_term_id'] == $level_id) {
                            $level_grade_user = $level_grade_user + $result_item['grade'];
                        }
                    }
                    if ($method_grading_level == "sum") {
                        $level_grade_user_final = $level_grade_user;
                    }
                    if ($method_grading_level == "avg") {
                        $numberOfSkills = count($product_skills);
                        $level_grade_user_final = ($level_grade_user / $numberOfSkills);
                    }
                    $utec_level_results_intervals_level = [];
                    foreach ($utec_level_results_intervals as $item) {
                        if ($item['level_term_id'] == $level_id) {
                            $utec_level_results_intervals_level[] = $item;
                        }
                    }
                    usort($utec_level_results_intervals_level, function ($first, $second) {
                        return intval($first['int_down']) > intval($second['int_down']);
                    });
                    $text_show_Level = "";

                    foreach ($utec_level_results_intervals_level as $interval_level) {
                        $intDown = $interval_level['int_down'];
                        $intUp = $interval_level['int_up'];
                        $text_level_result_item = $interval_level['txt_result_level_int'];
                        if ($intUp > $level_grade_user_final && $intDown <= $level_grade_user_final) {
                            $text_show_Level = $text_level_result_item;
                        }
                    }
                    $style_table_all = "border: 1px solid $level_color;
                    border-radius: 20px;text-align: center;vertical-align:middle;border-collapse:initial;";
                ?>
                    <div class="utec-result-all-container">
                        <h3 class="utec-result-header-level" style="color:<?php echo $level_color; ?>;">
                            <?php echo $level_title;  ?> : <span class="utec-level-desc-rs-show"> <?php echo $level_desc; ?> </span>
                        </h3>
                       
                        <table style="width:100%;<?php echo $style_table_all ?>" class="utec-table-result">
                            <tr>
                                <th style="width:20%;<?php echo $style_table_all ?>font-weight:bolder;font-size:19px;">رده مهارتی</th>
                                <th style="<?php echo $style_table_all ?>font-weight:bolder;font-size:19px;">نتیجه ارزیابی</th>
                            </tr>
                            <?php
                            foreach ($product_skills as $skill) {
                                $utec_level_results_intervals_skill = [];
                                $skill_id = $skill->term_id;
                                $skill_title = $skill->name;
                                $skill_img = get_term_meta($skill_id, "featured_cate_skill_img", true);
                                $skill_grade_user = 0;
                                $skill_grade_user_final = 0;
                                $segment_grade = 0;
                                $segment_status_pass = "fail";
                                foreach ($result_array as $result_item) {
                                    if (
                                        $result_item['level_term_id'] == $level_id
                                        && $result_item['skill_term_id'] == $skill_id
                                    ) {
                                        $segment_grade = $result_item['grade'];
                                        $segment_status_pass = $result_item['status_pass'];
                                    }
                                }
                                foreach ($quiz_new_skills_rs_already as $item) {
                                    if (
                                        $item['level_term_id'] == $level_id
                                        && $item['skill_term_id'] == $skill_id
                                    ) {
                                        $utec_level_results_intervals_skill[] = $item;
                                    }
                                }
                                usort($utec_level_results_intervals_skill, function ($first, $second) {
                                    return intval($first['int_down']) > intval($second['int_down']);
                                });
                                $text_show_Skill = "";
                                foreach ($utec_level_results_intervals_skill as $interval_skill) {
                                    $intDown = $interval_skill['int_down'];
                                    $intUp = $interval_skill['int_up'];
                                    $product_ids = $interval_skill['product_ids'];

                                    $text_skill_result_item = $interval_skill['txt_result_skill_int'];
                                    if ($intUp > $segment_grade && $intDown <= $segment_grade && $product_ids) {
                                        $Courses_Ids = array_merge($Courses_Ids, $product_ids);
                                        $text_show_Skill = $text_skill_result_item;
                                        // utec_dd($Courses_Ids);
                                    }
                                }
                            ?>

                                <tr>
                                    <td style="<?php echo $style_table_all ?>">
                                        <h3>
                                            <div style="display: flex;justify-content: center;" class="utec-skill-div-all-result">
                                                <div style="margin-top:20%;" class="utec-skill-title-result">
                                                    <?php echo $skill_title  ?>
                                                </div>
                                                <div style="display: flex;flex-direction:column;">
                                                    <div>
                                                        <?php if ($segment_status_pass == "success") {
                                                        ?>
                                                            <i class="fa fa-check-circle-o " style="color:#40d040;font-size:40px;"></i>
                                                        <?php
                                                        } ?>
                                                        <?php if ($segment_status_pass == "fail") {
                                                        ?>
                                                            <i class="fa fa-times-circle-o " style="color:#d94747;font-size:40px;"></i>
                                                        <?php
                                                        } ?>
                                                    </div>
                                                    <div>
                                                        <img class="utec-skill-img-result" style="width:50px ;height:50px;margin:10px;" src="<?php echo $skill_img ?>" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                        </h3>
                                    </td>
                                    <td style="<?php echo $style_table_all ?>padding:15px;">
                                        <?php
                                        echo do_shortcode(stripslashes(urldecode($text_show_Skill)));
                                        ?>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </table>
                    </div>
                <?php
                }
                $Courses_Ids = array_unique($Courses_Ids);
                if ($Courses_Ids) :
                ?>
                    <div class="utec-result-courses-level">
                        <h3 class="utec-result-courses-header-level">
                            <i class="fa fa-graduation-cap"></i> دوره های پیشنهادی برای شما
                        </h3>
                        <div>
                            <div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid vc_custom_1559222878118 vc_row-has-fill" style="position: relative; left: -1px; box-sizing: border-box;  padding-left: 0px; padding-right: 0px;">
                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                    <div class="vc_column-inner">
                                        <div class="wpb_wrapper">
                                            <div class="vc_row wpb_row vc_inner vc_row-fluid">
                                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-xs-12">
                                                    <div class="vc_column-inner">
                                                        <div class="wpb_wrapper">
                                                            <div class="products grid-view courses-3-columns">
                                                                <?php
                                                                foreach ($Courses_Ids as $cid) {
                                                                    $prefix = '_studiare_';
                                                                    $cid = intval($cid);
                                                                    $product = wc_get_product($cid);
                                                                    $rating_count = $product->get_rating_count();
                                                                    $review_count = $product->get_review_count();
                                                                    $average      = $product->get_average_rating();
                                                                    $price = $product->get_price() ? $product->get_price() : 0;
                                                                    $Course_Obj = get_post($cid);
                                                                    $course_permalink =  get_permalink($cid);
                                                                    $course_featured_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAflBMVEX///9ERERAQED19fUtLS0+Pj5qamr8/Pzr6+s6OjpFRUU3Nzfe3t74+PhNTU1JSUliYmKjo6Pk5ORXV1dRUVGysrJoaGiNjY2cnJyoqKjFxcW7u7t8fHxdXV3q6urY2NiFhYWTk5N0dHTR0dF+fn7JycmdnZ22trYoKCgwMDCAG/qfAAAL5klEQVR4nN1daYOiOhCEsOEQOVVQERXQ8c3//4Mv6M6OkAQI5gDq4x6aMqEr3dUJmiYVxiE5GHK/UiYs+7B1gesfbEv1UITAine5q9dw8128QI7rgwmB/gKA5mGtekCcsY5M/Yffk6NuRkviaH8lDX4vjsmXrXpgnGBEOcbvxTGPlhBXjch3SPxez6M/d45IH3yXQu+FeWuHFT823fyeHDez1Y71LqGuz8ZadZLdHOMq0j8whN+TI5ifdpD0oZOjnuzPqgfNACMKmfi9OIaziatGtB28PhscwXYOHJ/6MIbfk6MbTF07UP6w7deHLrjbKWuHhfRh9Pz9ziPSjolyZNGHTo5gmrnV+ctkjp9Ujrr5Fasm1II9Qh+6OYbRlHIrI9pwWZ9NjpupaAfSh+Dj+ELk6AbRBLTDOn+qD11A2nFWyxHpQyhk/n4A3FCpdrzXz4RxVFiXiyN++tDJUTcjFdrBWx+6OcrXDlr9TBxHuXU5OxKjD50c3ZWseeyvn4mCnLrcr7+ihKN4T0eGPnRBtHa0/RUlHAV6Oqz1M1EQ5enI1ocuiNAOI/KVPn9tcPZ01OlDF/hpxzB/RQU4eTpD/RUV4OHp8KqficKndTl7r17/+vCJpzPGX1GBsZ7OWH9FBUZ4OsLqZ6LA6Ol87q+owHBPh4u/ogJD63JT14cuDNGOmKO/ogJ9no7M+pkodNXljGgze341KJ7O7PShCwRPR6y/ogJNTwfpn1h/RQXetUN1/UwUfupyU6ificKrLpdBR/VABMJxMs26JN+LnUM3udSPovXYLJMi2Ox+wmmcbqHq4XAH3Kbve9SsXFg4BbDMWlvuaLOkiONscGPcqq6zzZraAOB6JyWKxmOzjKcRbh6U7MI6XxcgHOD71tVldJ9PgY0MALZ3Or3nUi1mLY5gW/SXFatbMFeOILhVvfwQ7F0yT+Fwkt1Qb3hdzFD/gVMweDTGPZlbyu+GR7bC/jkCcxJHCL7YDajLfDJ/lM1fmPnV2OXzmEaY70bxQ4ivM8iq4Pba3GQz9dpYWTnxPQ4A5aO5R1unjNMYTXo7DttZkvEIHTaGmlfdpqv/zq3yGqO9pD7UGRminyWbqHBA8GhJ4C6v/5yZIXp2TxMsiQO3bMUUo3xVfkcwRFnV1Gw3oIfH5hCtzP271EYx1Oz9pLIqsNk3J9CKr//CxTiGKKu6TmYa6zpMc3BGFv7GirEMNfuRTyOqOnk7S7oU7zntaIb1B01gGoFetDehXtgI9h8w1Iyj8uTYIWRJxn+Nf/IJwzriQJXiCJ2CsO00/jT+0WcM0b5Pnd8IdJOYxnNmqGlRrmY7DvKIPCDuDNH2XUFW1fKSxDJE8iM7q0JZUkatwwhgiLKqgy9zGmFw6GjmEsJQ89bltzSCbrn2OsbCi2Hb7jAeKzni6Oi79gJtjoUXQ/PY/pOzjK0q0K9YofBoCmGY/EkxtT2KFkckgdgPa6d/EiEMTQDxHZP9JdQddzZYpdc4hhCImUMT6CDAvYG7uKUK9BtmBq6LAOriGKKwbT7aEcfehWKm0QkxL8l6mLVIiWSoQz9trxtrLSKrQlkS1pd+Tl8qLJQh4hhm7b/y7tyTY2dzxCTwXyIvmCExflsF13IccAqs28BO/60U0QzRD7zFf+BLyc0dB0GJeUne8S1oi2dINFy9Q8iJYHjAfr+4eD8FKYFhffgfryZcCg7bcehjdRikgc1rDqQw1MEKn0bjWH7qjrsl/sut960HQA7D+nsyfDUdVp9MI9TxjjsvI3yzHIY6wLVRsy4fTKNbXrAQijQQ/2JZDOseJGxfrBm7YNw0wgDLktDenuQmSGSogz83fFTn6wjhAAGusppx+0P8VokMaxuW0MiSsV6hAUCC7ZRQ4KIkLnIZEoOqdt4zNXLAnHAge12saF8pl+Ez4cCCqnW/0saHD1gn9PR6rzRiGgzrhAOfRvsxcBphTujpXacduwf5DOuE44H9BytOB/Qcg++UcEI5C7t+HRUM61CIT4R1D/rE0Q0ITed22h2MlTCsE44MH6vX3nC1f5c9Xgi1sm1PtqmIIUo4UkJhujpROYLgROjpjdPey1QEMSz7nymHkHCgPU5CfqZgQtjDtNMIMsNSCMN0QPAHzp5gEF0KHecIcbdaq9OIIT2foNm7xothNkjeoEnwiLxj2X6yHJM03RldAxsMm/sfXgy9YMiXo8046WmMo8Z2HAakCzvjdDtskxA0wxM37ykdWk/L8S1mnVX9BhDXrAjHWrJ84Oc7rQZLbgyNoYkfcEqSm7n7m+gBn9TTa5SD76NyW5/Ozz+MBhdFYYAX4+oOQMQR+CdCO4V3DAZ/uNO28/kxNChhnwAAUtJNKlkZtE8+1rDWxXDXHCbtBcLRAz4OCzZ/B0Iy3uMHIcIY2fCfDoUZrKzAkaGxZxgJDNJhZwQuXWkE/rF7vCeKo48fl0x5bTjkmMCDZQJ1WOKLgGunArEwRAVKOPruqWas6YANXvri3ItxWDGMpx4RIbC8IWNszF0dCB/CudukYCwxuR3TGF8ZHStQkD6GM0PvxGgVOhtKNxO1lEb/qBOxrYZ3x9CZKTLo1JOB64L1Uk2YkA+oce+JunTWUEhwcG1EaQSrbQxDivrw7/qqmA+1gXYxbk1wI/oI5rRDvgL62tg044VGMe7BbqaSLBJxDLWMeQZ0oJ9+VqpxYu/dAD5ddoT0Jo6ZReg+i3HW0WX3pohKL5Qhs1Q/4VxjLx6cSDcIdm0cxDDUjmM6oWHyxao1z//WNYPCGGr3MceEwZiLpWHefdeFKIZaxaxo4+CYPXdBCGOoXbAaoRCCePuQNIZazLpHHUPw1HuXgECGmiX6rBfQi64edvEMUb7Irv0sBH1SPiiXoZYJvHkBkmrL0hlq1UkURUgy3xQw1GJqz8RHAKti4MvIhDPUjIeAk15wS3AXVTFEysi/CzrHW9xUMtSslOttNgCmDG8fkcKwjqkcKQ6LoZIZDvc3+0D2WDsgi2FdXOLyxmOST94JTxbD+trlka2lv4CrL+YXx6ybJyGFvkTQq8zPzl24ZsX8RpV7a+ncxl2LNRT2wx8vHI5Pu5ezA1n7FiQY9lwO+SlsUvfMEECddJ1AH45YfAP0yiovxFf2S0IB3F7HvLmJWIB3TOEvn62uG6YdAICbYddWtmEUxGfCjfqzyk9xL/LBHNGyKjqLaR1f45M/MZDwlmSvihJnyAMJnSSqRv7klClEk7jny4YMb52Vbk/1EDhumXUetu9ETKtLA1/S27zty37TUcOH7ra4fCLQFbVN61vay7wto0qDbwd7JgF0voO0Mj76qa0dlaE7+rbIUYgPt3zrBzoAEEIkJIG/zW9dN10MhEd7DJFgEB1/oYjvu316PZ1O13S/O/LRKy+lPgHwyuUbVKOLIeMVmBOFReyWfHb8YA2MM8WRFGlWNdyRW4ipYU1aoC+Gkl41Lxo2qZOwJghMSYovHBnhQVzSIiW3g9ZTSGw0nycyvMC3Wum+4CxfJow91g660lfcX72uEjbhtNKYasiEYZxaFIMBb/GYFWzMTmDxPGYAqz2F6EGUmzkJhrXH1QJsFhRKyS2EpCMLc8WafGDRSZcSbIwrJUEEQ7pUZgArolbyAtGFfTm40/jVHalLWKdeV5cLvKkeHgd09w0uQBWPPeX0ZO6SYfR2Dexnvnvb9R1oBeG846mN70fbgBJcRIHIyM5hcxKl2TMCYNDL3b9wsetkZ4SKeqLlraoB2i/bmRMeNC0EyRt1ON9latO23Dp8P1HvHma7TNfUTkj33RcG5WwZVtQNGzTeu9zAXPffdHsbmNp7p+K32B43caBrhRM1GEq28/mBvidFk/bOcLZWsE1VQ99oMGzdCjYf2LS7K+CpyVAPVQ91JGxaoEECaDUYblUPdSRs2htgnEprMgxUD3UkaAxBHrcYrlQPdSRoDOHNXjjDeh+6bIb6XVs2Q1DffrJohrC+B9f6b8kM62a2Rc/h8/6TJTMEZp0rLZnhK5FYMEOweda4FxxpwOuMxXIZun/fQ7FYhu7PDSELZQjhv+sJlsgQOO7b3dkLZOib+/fbCVoM/wcho9t6L4Ib1wAAAABJRU5ErkJggg==";
                                                                    $course_title = $Course_Obj->post_title;
                                                                    if (has_post_thumbnail($cid)) {
                                                                        $course_featured_img = wp_get_attachment_image_src(get_post_thumbnail_id($cid), 'single-post-thumbnail')[0];
                                                                    }
                                                                    $courses_cart_loop = true;
                                                                    $courses_teacher_loop = true;
                                                                    $course_students = true;
                                                                    $courses_rating_loop = true;
                                                                    $teacher_id = get_post_meta($cid, $prefix . 'course_teacher', true);
                                                                    if (class_exists('Redux')) {
                                                                        $course_students = codebean_option('course_students');
                                                                        $course_video_loop = codebean_option('course_video_loop');
                                                                        $courses_rating_loop = codebean_option('courses_rating_loop');
                                                                        $courses_teacher_loop = codebean_option('courses_teacher_loop');
                                                                        $courses_cart_loop = codebean_option('courses_cart_loop');
                                                                    }
                                                                ?>
                                                                    <div class="vc_col-sm-12 utec_vc_course_box vc_col-xs-12 course-item utec-certif-course-item post-<?php echo $cid; ?> product type-product status-publish has-post-thumbnail product_cat-quiz_section first instock virtual purchasable product-type-simple">
                                                                        <a href="<?php echo $course_permalink; ?>" target="_blank">
                                                                            <div class="course-item-inner ">
                                                                                <div class="course-thumbnail-holder">
                                                                                    <img style="width:100%;height:200px;" title="<?php echo $course_title; ?>" alt="<?php echo $course_title; ?>" src="<?php echo $course_featured_img; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail">
                                                                                </div>
                                                                                <div class="course-content-holder">
                                                                                    <div class="course-content-main" style="height: 80px;">
                                                                                        <div class="course-top-content">
                                                                                            <h3 class="course-title">
                                                                                                <?php echo $course_title; ?>
                                                                                                <br>
                                                                                            </h3>
                                                                                        </div>
                                                                                        <div class="course-rating-teacher">
                                                                                            <?php if ($courses_rating_loop) : ?>
                                                                                                <div class="average-rating-stars">
                                                                                                    <div class="woocommerce-product-rating">
                                                                                                        <div class="star-rating" title="<?php printf(esc_html__('Rated %s out of 5', 'studiare'), $average); ?>">
                                                                                                            <span style="width:<?php echo (($average / 5) * 100); ?>%">
                                                                                                                <strong class="rating"><?php echo esc_html($average); ?></strong>
                                                                                                                <?php printf(_n('based on %s customer rating', 'based on %s customer ratings', $rating_count, 'studiare'), '<span class="rating">' . $rating_count . '</span>'); ?>
                                                                                                            </span>
                                                                                                        </div>

                                                                                                    </div>
                                                                                                </div>
                                                                                            <?php endif; ?>
                                                                                            <?php if (!empty($teacher_id) && $teacher_id != 'no-teacher' && $courses_teacher_loop) : ?>
                                                                                                <div class="teacher-box">
                                                                                                    <i class="fal fa-chalkboard-teacher" title="مدرس دوره"></i>
                                                                                                    <a href="<?php echo esc_url(get_the_permalink($teacher_id)); ?>" class="course_loop_teacher"><?php echo esc_attr(get_the_title($teacher_id)); ?></a>
                                                                                                </div>
                                                                                            <?php else : ?>
                                                                                                <div class="teacher-box"></div>
                                                                                            <?php endif; ?>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="course-content-bottom" style="display:-webkit-box;">
                                                                                        <div class="course-students">
                                                                                            <?php if ($course_students) : ?>
                                                                                                <i class="fal fa-users"></i><span><?php $count = get_post_meta($cid, 'total_sales', true);
                                                                                                                                    $text = sprintf(_n('%s', '%s', $count, 'wpdocs_textdomain'), number_format_i18n($count));
                                                                                                                                    echo $text;  ?>
                                                                                                <?php endif; ?>
                                                                                        </div>
                                                                                        <div class="course-price">
                                                                                            <span class="price" style="color:#6c648b;"><span class="amount"><?php echo number_format($price); ?> تومان</span></span>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </a>
                                                                    </div>

                                                                <?php
                                                                }
                                                                ?>
                                                                <?php
                                                                ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php
                endif;
                ?>
                <?php
                $user_id = get_current_user_id();
                $user = get_user_by('id', $user_id);
                $username = $user->data->user_login;
                $first_name = get_user_meta($user->ID, 'first_name', true);
                $last_name = get_user_meta($user->ID, 'last_name', true);
                $full_name = $first_name . " " . $last_name;

                if ((utec_quiz_is_answers_exist_temp() && isset($_GET['End']))) :
                    $answers_array_swal = utec_quiz_get_answers_temp();
                    utec_quiz_delete_answers_temp();
                    // $answers_array_swal = $result_array;
                ?>
                    <div id="utec-after-quiz-passes-msg-swal" style="display: none;">
                        <?php
                        $swal_segment_passed = [];
                        $has_passed = 0;
                        $FirstLevelId = $answers_array_swal[0]['level_term_id'];
                        $FirstLevelSwalName = get_term_by('id', $FirstLevelId, 'product_cat')->name;
                        $FirstLevelSwalName_color = get_term_meta($FirstLevelId, "color_level", true);
                        foreach ($answers_array_swal as $ans_swal) {
                            $level_term_id = $ans_swal['level_term_id'];
                            $level_term_color = get_term_meta($level_term_id, "color_level", true);
                            $skill_term_id = $ans_swal['skill_term_id'];
                            $status_pass = $ans_swal['status_pass'];
                            $LevelSwalName = get_term_by('id', $level_term_id, 'product_cat')->name;
                            $SkillSwalName = get_term_by('id', $skill_term_id, 'skill-category')->name;
                            if ($status_pass == "success") {
                                $has_passed = 1;
                                $swal_segment_passed[] = "<div class='utec-span-after-end-msg-skill-success'>*<span style='padding:5px;'>$SkillSwalName</span> در سطح <span style='color:$level_term_color;padding:5px;'>$LevelSwalName</span></div>";
                            }
                        }
                        if ($swal_segment_passed) {
                            $swal_segment_passed = array_unique($swal_segment_passed);
                        }
                        ?>
                        <?php
                        $iconSwal = "";
                        if ($has_passed == 1 && $swal_segment_passed) {
                            $iconSwal = "success";
                        ?>
                            <h3 style="padding: 10px;line-height:1.2;">
                                تبریک <?php echo $first_name ?> عزیز؛ در رده های مهارتی زیر پذیرفته شدی!
                            </h3>
                            <center>
                            <div class="utec-span-Container-after-end-msg-skill-success">
                                
                                    <?php
                                    foreach ($swal_segment_passed as $swalSeg) {
                                        echo $swalSeg;
                                    }
                                    ?>
                                
                            </div>
                            </center>
                        <?php
                        } else {
                            $iconSwal = "error";
                        ?>
                            <h3>
                                <?php echo $first_name ?> عزیز! همین الان از سطح <span style='color:<?php echo $FirstLevelSwalName_color; ?>;padding:5px;'><?php echo $FirstLevelSwalName; ?></span> شروع کن.
                            </h3>
                        <?php
                        }
                        ?>
                    </div>
                    <script>
                        jQuery(document).ready(function($) {
                            var utec_after_quiz_msg_html = $('#utec-after-quiz-passes-msg-swal').html()
                            var utec_after_quiz_msg_div = document.createElement("div");
                            utec_after_quiz_msg_div.innerHTML = utec_after_quiz_msg_html;
                            swal({
                                content: utec_after_quiz_msg_div,
                                icon: "<?php echo $iconSwal; ?>",
                                button: "متوجه شدم",
                                closeOnClickOutside: false,
                            });
                        });
                    </script>
                <?php endif; ?>
            </div>
        <?php
        } else {
        ?>
            <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #d83d3d;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
                <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> مجاز به دیدن این صفحه نیستید !
            </div>
        <?php
        }
    } else {
        ?>
        <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
            <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> دسترسی به این صفحه را ندارید !
        </div>
    <?php
    }
} else {
    ?>
    <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
        <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> باید ابتدا وارد شوید !
    </div>
<?php
}
