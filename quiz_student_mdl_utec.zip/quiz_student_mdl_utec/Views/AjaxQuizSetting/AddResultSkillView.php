<p class="utec-quiz-header-mfp-title">
    افزودن بازه های نتیجه گیری <?php
                                $level_title = get_term_by('id', $level_term_id, "product_cat")->name;
                                $skill_title = get_term_by('id', $skill_term_id, "skill-category")->name;
                                echo $level_title; ?>
    , رده <?php echo $skill_title; ?>
</p>

<p style="color: red;">* دقت کنید که بازه های تعریف شده هر بخش با هم اشتراک نداشته باشند و بازه تکراری تعریف نکنید !</p>
<p style="color: red;">* همیشه در هر بازه، کران بالا جزء آن نیست و کران پایین جزء آن بازه نتیجه گیری خواهد بود .</p>
<br><br>
بازه نتیجه گیری بر اساس نمره رده در سطح :
<br><br>
<div class="not_long_input">
    از <input type="number" id="int_down" name="int_down"> تا <input type="number" id="int_up" name="int_up">
</div>
<br><br>
<label for="">انتخاب دوره : </label>
<select class="select2" multiple name="product_ids" id="product_ids" style="width: 100%;">
    <option value="0" disabled>*انتخاب دوره ها*</option>
    <?php foreach ($courses as $course) { ?>
        <option value="<?php echo $course->ID; ?>"><?php echo $course->post_title; ?></option>
    <?php } ?>
</select>
<br><br>
<p style="color: red;">* اگر متن داخل ویرایش گر دیده نمی شود یکبار روی "متن" و سپس روی "دیداری" کلیک کنید . </p>
<p style="color: red;">* اگر پرونده چند رسانه ای به متن اضافه نشد، یک بار کل این صفحه ویرایش آزمون را رفرش کرده و مجدد تلاش کنید . </p>

<?php
wp_editor('', 'txt_result_skill_int', array('editor_class' => 'add_skill_rs_editor'));
?>
<br><br>
<input type="hidden" id="level_term_id" name="level_term_id" value="<?php echo $level_term_id; ?>">
<input type="hidden" id="skill_term_id" name="skill_term_id" value="<?php echo $skill_term_id; ?>">
<button type="button" class="btn-go-add-ajax add-level-result-btn"><i class="fa fa-paper-plane-o"></i></button>
<br><br>
<?php
utec_quiz_load_tinyMceSettingsJs("add_skill_rs_editor");
?>
<script>
    jQuery(document).ready(function($) {
        var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
        $(".select2").select2({
            maximumDisplayOptionsLength: 3,
            placeholder: "نام دوره مورد نظر را سرچ کنید",
            dir: "rtl"
        });
        //function ajax
        function Utec_Request_Ajax(wp_data, wp_action, wp_container = null, wp_url = '', prelaod_msg = '') {
            var final_data = {
                ...wp_data,
                action: wp_action
            }
            $.ajax({
                url: wp_url,
                type: "POST",
                data: final_data,
                beforeSend: function() {
                    if (wp_container) {
                        wp_container.html(`<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>${prelaod_msg} </span></center>`);
                    }
                },
                complete: function(res) {
                    if (wp_container) {
                        wp_container.html(`<button title="Close (Esc)" type="button" class="mfp-close">×</button><br>` + res.responseText);
                    }
                },
                error: function(res) {
                    if (wp_container) {
                        wp_container.html(res.responseText);
                    }
                }
            });
        }
        //save Result
        $('.add-level-result-btn').click(function() {
            var level_term_id = $('#level_term_id').val();
            var skill_term_id = $('#skill_term_id').val();
            var int_down = $('#int_down').val();
            var int_up = $('#int_up').val();
            var product_ids = ($('select#product_ids').val());
            var txt_result_skill_int = tinymce.get("txt_result_skill_int").getContent();
            if (!int_down || !int_up || !level_term_id || !skill_term_id || !product_ids) {
                alert('تمامی فیلد ها ضروری اند !');
                return;
            }
            var post_data = {
                level_term_id: level_term_id,
                skill_term_id: skill_term_id,
                int_down: int_down,
                int_up: int_up,
                product_ids: product_ids,
                txt_result_skill_int:txt_result_skill_int
            }
            Utec_Request_Ajax(post_data,
                "utec_quiz_set_interval_skill_save",
                $('#Modal_Quiz_Container'),
                ajax_url,
                "در حال ذخیره نتیجه گیری ..."
            );
        });
    });
</script>