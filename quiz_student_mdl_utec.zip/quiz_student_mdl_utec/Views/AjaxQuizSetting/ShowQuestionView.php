<p class="utec-quiz-header-mfp-title">
     سوالات <?php $level_title = get_term_by('id', $level_term_id, "product_cat")->name;
    echo $level_title; ?>
</p>
<?php

if ($questions_all_spec) {
    $all_quiz_sections_array = $questions_all_spec;
    $all_quiz_sections_array = array_reverse($questions_all_spec);
    $list_score_opts = [];
    $list_txt_opts = [];
    
    usort($questions_all_spec, function ($first, $second) {
        return intval($first['skill_term_id']) > intval($second['skill_term_id']);
    });
    usort($questions_all_spec, function ($first, $second) {
        return intval($first['order_ques']) > intval($second['order_ques']);
    });
    
    foreach ($questions_all_spec as $ques) {
        $options_array = [];
        $opt_str = $ques['options_array'];
        $pieces = [];
        if ($opt_str) {
            $pieces = explode("@", $opt_str);
            $pieces = array_filter($pieces, function ($var) {
                return $var;
            });
        }
        if ($pieces) {
            $ind_opt = 0;
            foreach ($pieces as $piece_opt) {
                $opt_self_pieces = explode("*", $piece_opt);
                $opt_txt = $opt_self_pieces[0];
                $opt_score = $opt_self_pieces[1];
                if ($opt_score) {
                    $list_score_opts[] = $opt_score;
                }
                if ($opt_txt) {
                    $list_txt_opts[] = $opt_txt;
                }
            }
        }
    }
    $index_ques = 1;
?>
    <b>
        سوال <span id="current_ques">1</span> از <span id="cnt_all_queses"></span>
    </b>
    <br>
    <div style="text-align: center;">
        <span class="go-arrow go-prev-ques" title="قبلی">&laquo;</span>
        <span class="go-arrow go-next-ques" title="بعدی">&raquo;</span>
    </div>
    <br>
    <?php
    foreach ($questions_all_spec as $ques) {
    ?>
        <div class="question-box" data-index="<?php echo $index_ques; ?>" data-hash="<?php echo $ques['ques_salt']; ?>">
            <input type="hidden" id="level_term_id" name="level_term_id" value="<?php echo $level_term_id; ?>">
            <label for="">متن سوال : </label>
            <input type="text" value="<?php echo $ques['title_ques']; ?>" id="title_ques" name="title_ques" placeholder="مثلا: سوال اول">
            <br><br>
            <label for="">رده مهارتی مربوطه : </label>
            <select name="skill_term_id" id="skill_term_id" class="skill_term_dropdown">
                <option value="0" selected>*یک مورد را انتخاب کنید*</option>
                <?php
                foreach ($product_skills as $skill) {
                    $term_id = $skill->term_id;
                    $term_title = $skill->name;
                    $selected = ($term_id == $ques['skill_term_id']) ? "selected" : "";
                ?>
                    <option value="<?php echo $term_id; ?>" <?php echo $selected; ?>><?php echo $term_title; ?></option>
                <?php
                }
                ?>
            </select>
            <br><br>
            <label for="">ترتیب سوال در رده این سطح: </label>
            <input type="number" value="<?php echo $ques['order_ques']; ?>" id="order_ques" name="order_ques" placeholder="مثلا: 12">
            <br><br>

            <?php
            $options_array = [];
            $opt_str = $ques['options_array'];
            $pieces = [];
            if ($opt_str) {
                $pieces = explode("@", $opt_str);
                $pieces = array_filter($pieces, function ($var) {
                    return $var;
                });
            }
            ?>
            <div class="repeat-options-edit" id="Options_Section">
                <table class="wrapper" width="100%">
                    <thead>

                    </thead>
                    <tbody class="container">
                        <tr class="template row" style="margin-bottom:10px;margin-top:10px;padding:10px;">
                            <td width="10%"><span class="move"><i class="fa fa-arrows"></i></span></td>
                            <td width="70%">
                                <div class="opt_class_box">
                                    <br>
                                    <label>متن گزینه : </label>
                                    <input autocomplete="off" list="opt_txt" type="text" class="options_txt" name="option_txt[{{row-count-placeholder}}]" id="option_txt[{{row-count-placeholder}}]" placeholder="مثلا: گزینه اول">
                                    <br>
                                    <label>نمره گزینه : </label>
                                    <input autocomplete="off" list="opt_score" type="number" class="options_score" name="option_score[{{row-count-placeholder}}]" id="option_score[{{row-count-placeholder}}]" placeholder="مثلا: 5">
                                </div>
                            </td>
                            <td width="10%"><span class="remove remove-opt btn-go-delete-ajax"><i class="fa fa-trash-o"></i></span></td>
                        </tr>
                        <?php
                        if ($pieces) {
                            $ind_opt = 0;
                            foreach ($pieces as $piece_opt) {
                                $opt_self_pieces = explode("*", $piece_opt);
                                $opt_txt = $opt_self_pieces[0];
                                $opt_score = $opt_self_pieces[1];
                        ?>
                                <tr class="row" style="margin-bottom:10px;margin-top:10px;padding:10px;">
                                    <td width="10%"><span class="move"><i class="fa fa-arrows"></i></span></td>
                                    <td width="70%">
                                        <div class="opt_class_box">
                                            <br>
                                            <label>متن گزینه : </label>
                                            <input autocomplete="off" list="opt_txt" type="text" value="<?php echo $opt_txt; ?>" class="options_txt" name="option_txt[<?php echo $ind_opt; ?>]" id="option_txt[<?php echo $ind_opt; ?>]" placeholder="مثلا: گزینه اول">
                                            <br>
                                            <label>نمره گزینه : </label>
                                            <input autocomplete="off" list="opt_score" type="number" value="<?php echo $opt_score; ?>" class="options_score" name="option_score[<?php echo $ind_opt; ?>]" id="option_score[<?php echo $ind_opt; ?>]" placeholder="مثلا: 5">
                                        </div>
                                    </td>
                                    <td width="10%"><span class="remove remove-opt btn-go-delete-ajax"><i class="fa fa-trash-o"></i></span></td>
                                </tr>
                        <?php
                                $ind_opt++;
                            }
                        }
                        ?>
                    </tbody>
                    <tr>
                        <td width="10%" colspan="4"><span class="add open-add-mag">افزودن گزینه+</span></td>
                    </tr>
                </table>
            </div>
            <br><br>
            <button type="button" title="ویرایش" class="btn-go-edit-ajax edit-ques-btn"> <i class="fa fa-pencil-square-o"></i> </button>
            <button type="button" title="حذف" class="btn-go-delete-ajax delete-ques-btn"> <i class="fa fa-trash"></i> </button>
            <button type="button" title="کپی این سوال به عنوان سوال آخر رده" class="btn-go-copy-ajax copy-ques-btn"> <i class="fa fa-clone"></i> </button>
            <input type="hidden" id="quiz_id" name="quiz_id" value="<?php echo $post_id; ?>">
            <br><br>
            <span class="msg-edit-question-scc" style="color: green;"></span>
            <br>
        </div>
    <?php
        $index_ques++;
    }
    ?>
    <br>
    <div style="text-align: center;">
        <span class="go-arrow go-prev-ques" title="قبلی">&laquo;</span>
        <span class="go-arrow go-next-ques" title="بعدی">&raquo;</span>
    </div>
    <script>
        jQuery(document).ready(function($) {
            var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
            //Pagination
            var number_queses = $('.question-box[data-index]').length;
            if (number_queses == 1) {
                $('.go-next-ques').hide();
            }
            $('.go-prev-ques').hide();
            $('.question-box[data-index!=1]').hide();
            $('.question-box[data-index=1]').addClass('active-ques');
            $("#cnt_all_queses").text(number_queses);
            $('.go-next-ques').click(function() {
                var active_ques = $('.active-ques');
                var index_ques = parseInt(active_ques.attr('data-index'));
                var next_index_ques = index_ques + 1;
                var next_ques = $('.question-box[data-index="' + next_index_ques + '"]');
                active_ques.removeClass('active-ques').hide();
                next_ques.addClass('active-ques').fadeIn();
                $("#current_ques").text(next_index_ques);
                if (next_index_ques == number_queses) {
                    $('.go-prev-ques').show();
                    $('.go-next-ques').hide();
                } else if (next_index_ques == 1) {
                    $('.go-prev-ques').hide();
                    $('.go-next-ques').show();
                } else {
                    $('.go-prev-ques').show();
                    $('.go-next-ques').show();
                }

            });
            $('.go-prev-ques').click(function() {
                var active_ques = $('.active-ques');
                var index_ques = parseInt(active_ques.attr('data-index'));
                var next_index_ques = index_ques - 1;
                var next_ques = $('.question-box[data-index="' + next_index_ques + '"]');
                active_ques.removeClass('active-ques').hide();
                next_ques.addClass('active-ques').fadeIn();
                $("#current_ques").text(next_index_ques);
                if (next_index_ques == number_queses) {
                    $('.go-prev-ques').show();
                    $('.go-next-ques').hide();
                } else if (next_index_ques == 1) {
                    $('.go-prev-ques').hide();
                    $('.go-next-ques').show();
                } else {
                    $('.go-prev-ques').show();
                    $('.go-next-ques').show();
                }
            });
            $('.repeat-options-edit').each(function() {
                $(this).repeatable_fields();
            });
            //get order question
            $('.skill_term_dropdown').change(function() {

                var ques_salt = $(this).parent().attr('data-hash');
                var order_elem = $('div[data-hash="' + ques_salt + '"] #order_ques');
                var level_term_id = $('div[data-hash="' + ques_salt + '"] #level_term_id').val();
                var skill_term_id = parseInt($('div[data-hash="' + ques_salt + '"] #skill_term_id').val());

                var loadin_phrase = "<center class='loading_icon_status_certif' style='padding:0px;'><i style='font-size:14px' class='fa fa-2x fa-spin fa-spinner'></i></center>"

                // $.ajax({
                //     url: ajax_url,
                //     type: "POST",
                //     data: {
                //         action: "utec_quiz_get_order_ques_ajax",
                //         skill_term_id: skill_term_id,
                //         level_term_id: level_term_id
                //     },
                //     beforeSend: function() {
                //         order_elem.attr('disabled', 'disabled');
                //         $(loadin_phrase).insertAfter(order_elem);
                //     },
                //     complete: function(res) {
                //         $('.loading_icon_status_certif').remove();
                //         order_elem.removeAttr('disabled');
                //         order_elem.val(res.responseText)
                //     },
                //     error: function(res) {
                //         $('.loading_icon_status_certif').remove();
                //         order_elem.removeAttr('disabled');
                //     }
                // });
            });
            //edit question
            $('.edit-ques-btn').click(function() {

                var ques_salt = $(this).parent().attr('data-hash');

                var title_ques = $('div[data-hash="' + ques_salt + '"] #title_ques').val();
                var level_term_id = $('div[data-hash="' + ques_salt + '"] #level_term_id').val();
                var skill_term_id = parseInt($('div[data-hash="' + ques_salt + '"] #skill_term_id').val());
                var order_ques = $('div[data-hash="' + ques_salt + '"] #order_ques').val();

                var options_txt = $('div[data-hash="' + ques_salt + '"] .options_txt');
                var options_score = $('div[data-hash="' + ques_salt + '"] .options_score');
                var options_txt_array = [];
                var options_score_array = [];
                var options_array = "";
                options_txt.each(function() {
                    if ($(this).val() != "") {
                        options_txt_array.push($(this).val());
                    }

                })
                options_score.each(function() {
                    if ($(this).val() != "") {
                        options_score_array.push($(this).val());
                    }
                })
                var cnt_opt = options_txt_array.length - 1;
                var i = 0;
                for (i = 0; i <= cnt_opt; i++) {
                    options_array = options_array + options_txt_array[i] + "*" + options_score_array[i] + "@";
                }
                if (!options_array || !title_ques || !order_ques || !level_term_id || skill_term_id == 0) {
                    alert('تمامی فیلد ها ضروری اند !');
                    $('.msg-edit-question-scc').html('');
                    return;
                }
                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_edit_questions_ajax",
                        title_ques: title_ques,
                        order_ques: order_ques,
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id,
                        options_array: options_array,
                        ques_salt: ques_salt
                    },
                    beforeSend: function() {
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                        $('div[data-hash="' + ques_salt + '"] .edit-ques-btn').html("در حال ارسال " + "<i class='fa fa-spin fa-spinner'></i>");
                        $('div[data-hash="' + ques_salt + '"] .edit-ques-btn').css({
                            'background': 'orange'
                        });
                    },
                    complete: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .edit-ques-btn').html("<i class='fa fa-pencil-square-o'></i>")
                        $('div[data-hash="' + ques_salt + '"] .edit-ques-btn').css({
                            'background': '#dbc81f'
                        });
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('با موفقیت ویرایش شد .');
                        setTimeout(function() {
                            $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                        }, 10000)
                    },
                    error: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                    }
                });
            });
            //copy question
            $('.copy-ques-btn').click(function() {

                var ques_salt = $(this).parent().attr('data-hash');

                var title_ques = $('div[data-hash="' + ques_salt + '"] #title_ques').val();
                var level_term_id = $('div[data-hash="' + ques_salt + '"] #level_term_id').val();
                var skill_term_id = parseInt($('div[data-hash="' + ques_salt + '"] #skill_term_id').val());
                var order_ques = $('div[data-hash="' + ques_salt + '"] #order_ques').val();

                var options_txt = $('div[data-hash="' + ques_salt + '"] .options_txt');
                var options_score = $('div[data-hash="' + ques_salt + '"] .options_score');
                var options_txt_array = [];
                var options_score_array = [];
                var options_array = "";
                options_txt.each(function() {
                    if ($(this).val() != "") {
                        options_txt_array.push($(this).val());
                    }

                })
                options_score.each(function() {
                    if ($(this).val() != "") {
                        options_score_array.push($(this).val());
                    }
                })
                var cnt_opt = options_txt_array.length - 1;
                var i = 0;
                for (i = 0; i <= cnt_opt; i++) {
                    options_array = options_array + options_txt_array[i] + "*" + options_score_array[i] + "@";
                }
                if (!options_array || !title_ques || !order_ques || !level_term_id || skill_term_id == 0) {
                    alert('تمامی فیلد ها ضروری اند !');
                    $('.msg-edit-question-scc').html('');
                    return;
                }

                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_copy_questions_ajax",
                        title_ques: title_ques,
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id,
                        options_array: options_array,
                    },
                    beforeSend: function() {

                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                        $('div[data-hash="' + ques_salt + '"] .copy-ques-btn').html("در حال ارسال " + "<i class='fa fa-spin fa-spinner'></i>");
                        $('div[data-hash="' + ques_salt + '"] .copy-ques-btn').css({
                            'background': '#15a78c'
                        });
                    },
                    complete: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .copy-ques-btn').html("<i class='fa fa-clone'></i>")
                        $('div[data-hash="' + ques_salt + '"] .copy-ques-btn').css({
                            'background': '#1f50db'
                        });
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('با موفقیت افزوده شد .');
                        setTimeout(function() {
                            $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                        }, 10000)
                        $('.mfp-close').click();
                        // $(`a.Open_Modal_Quiz_Container.open-edit-mag[level-term-id="${level_term_id}"]`).click();

                    },
                    error: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                    }
                });
            });
            //delete question
            $('.delete-ques-btn').click(function() {
                var ques_salt = $(this).parent().attr('data-hash');
                var level_term_id = $('div[data-hash="' + ques_salt + '"] #level_term_id').val();
                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_delete_questions_ajax",
                        ques_salt: ques_salt
                    },
                    beforeSend: function() {
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                        $('div[data-hash="' + ques_salt + '"] .delete-ques-btn').html("<i class='fa fa-spin fa-spinner'></i>");
                        $('div[data-hash="' + ques_salt + '"] .delete-ques-btn').css({
                            'background': '#eb837c'
                        });
                    },
                    complete: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .delete-ques-btn').html("<i class='fa fa-pencil-square-o'></i>")
                        $('div[data-hash="' + ques_salt + '"] .delete-ques-btn').css({
                            'background': '#db2c1f'
                        });
                  
                        $('div[data-hash="' + ques_salt + '"]').fadeOut();
                        $('div[data-hash="' + ques_salt + '"]').remove();
                        $('.mfp-close').click();
                        // $(`a.Open_Modal_Quiz_Container.open-edit-mag[level-term-id="${level_term_id}"]`).click();
                    },
                    error: function(res) {
                        $('div[data-hash="' + ques_salt + '"] .msg-edit-question-scc').html('');
                    }
                });
            });
        });
    </script>
<?php
} else {
?>
    <h4 style="color: red;text-align:center;"> سوالی برای این سطح تا به حال تعریف نکرده اید ! </h4>
<?php
}
