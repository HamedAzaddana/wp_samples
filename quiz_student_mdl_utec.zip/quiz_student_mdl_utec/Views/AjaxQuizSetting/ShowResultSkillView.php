<p class="utec-quiz-header-mfp-title">
    افزودن بازه های نتیجه گیری <?php
                                $level_title = get_term_by('id', $level_term_id, "product_cat")->name;
                                $skill_title = get_term_by('id', $skill_term_id, "skill-category")->name;
                                echo $level_title; ?>
    , رده <?php echo $skill_title; ?>
</p>
<?php
if ($utec_level_results_intervals_skill) {
    $index_mr = 1;
?>
    <b>
        بازه <span id="current_mr">1</span> از <span id="cnt_all_mrs"></span>
    </b>
    <br>
    <div style="text-align: center;">
        <span class="go-arrow go-prev-mr" title="قبلی">&laquo;</span>
        <span class="go-arrow go-next-mr" title="بعدی">&raquo;</span>
    </div>
    <br>
    <?php
    foreach ($utec_level_results_intervals_skill as $int_skill) {
        $result_prod_ids = $int_skill['product_ids'];
    ?>
        <div class="make-res-elem-quiz" data-index="<?php echo $index_mr;  ?>" data-hash="<?php echo $int_skill['result_skill_salt']; ?>">
            <p style="color: red;">* دقت کنید که بازه های تعریف شده هر بخش با هم اشتراک نداشته باشند و بازه تکراری تعریف نکنید !</p>
            <p style="color: red;">* همیشه در هر بازه، کران بالا جزء آن نیست و کران پایین جزء آن بازه نتیجه گیری خواهد بود .</p>
            <br><br>
            بازه نتیجه گیری بر اساس نمره رده در سطح :
            <br><br>
            <div class="not_long_input">
                از <input value="<?php echo $int_skill['int_down']; ?>" type="number" id="int_down" name="int_down"> تا <input type="number" value="<?php echo $int_skill['int_up']; ?>" id="int_up" name="int_up">
            </div>
            <br><br>
            <label for="">انتخاب دوره : </label>
            <select class="select2" multiple name="product_ids" id="product_ids" style="width: 100%;">
                <option value="0" disabled>*انتخاب دوره ها*</option>
                <?php foreach ($courses as $course) {
                    $cid = $course->ID;
                    $selected = (in_array("$cid", $result_prod_ids)) ? ("selected") : ("");
                ?>
                    <option <?php echo $selected; ?> value="<?php echo $cid; ?>"><?php echo $course->post_title; ?></option>
                <?php } ?>
            </select>
            <br><br>
            <p style="color: red;">* اگر متن داخل ویرایش گر دیده نمی شود یکبار روی "متن" و سپس روی "دیداری" کلیک کنید . </p>
            <p style="color: red;">* اگر پرونده چند رسانه ای به متن اضافه نشد، یک بار کل این صفحه ویرایش آزمون را رفرش کرده و مجدد تلاش کنید . </p>
            <?php
            wp_editor(do_shortcode(stripslashes(urldecode($int_skill['txt_result_skill_int']))), $int_skill['result_skill_salt'], array('editor_class' => 'editing_rs_editor_skill'));
            ?>
            <br><br>
            <input type="hidden" id="level_term_id" name="level_term_id" value="<?php echo $level_term_id; ?>">
            <input type="hidden" id="skill_term_id" name="skill_term_id" value="<?php echo $skill_term_id; ?>">
            <input type="hidden" id="result_skill_salt" name="result_skill_salt" value="<?php echo $int_level['result_skill_salt']; ?>">
            <button type="button" title="ویرایش" class="btn-go-edit-ajax edit-mr-btn"> <i class="fa fa-pencil-square-o"></i> </button>
            <button type="button" title="حذف" class="btn-go-delete-ajax delete-mr-btn"> <i class="fa fa-trash"></i> </button>
            <br>
            <span class="msg-for-edit-delete" style="color: green; padding:10px;"></span>
            <br>
        </div>
    <?php
        $index_mr++;
    }
    ?>
    <!-- paginator  -->
    <br>
    <div style="text-align: center;">
        <span class="go-arrow go-prev-mr" title="قبلی">&laquo;</span>
        <span class="go-arrow go-next-mr" title="بعدی">&raquo;</span>
    </div>
    <?php
    utec_quiz_load_tinyMceSettingsJs("editing_rs_editor_skill");
    ?>
    <script>
        jQuery(document).ready(function($) {
            var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
            $(".select2").select2({
                maximumDisplayOptionsLength: 3,
                placeholder: "نام دوره مورد نظر را سرچ کنید",
                dir: "rtl"
            });
            var number_mrs = $('.make-res-elem-quiz[data-index]').length;
            if (number_mrs == 1) {
                $('.go-next-mr').hide();
            }
            $('.go-prev-mr').hide();
            $('.make-res-elem-quiz[data-index!=1]').hide();
            $('.make-res-elem-quiz[data-index=1]').addClass('active-mr');

            // current_sec
            $("#cnt_all_mrs").text(number_mrs);
            $('.go-next-mr').click(function() {
                var active_mr = $('.active-mr');
                var index_mr = parseInt(active_mr.attr('data-index'));
                var next_index_mr = index_mr + 1;
                var next_mr = $('.make-res-elem-quiz[data-index="' + next_index_mr + '"]');
                active_mr.removeClass('active-mr').hide();
                next_mr.addClass('active-mr').fadeIn();
                $("#current_mr").text(next_index_mr);
                if (next_index_mr == number_mrs) {
                    $('.go-prev-mr').show();
                    $('.go-next-mr').hide();
                } else if (next_index_mr == 1) {
                    $('.go-prev-mr').hide();
                    $('.go-next-mr').show();
                } else {
                    $('.go-prev-mr').show();
                    $('.go-next-mr').show();
                }

            });
            $('.go-prev-mr').click(function() {
                var active_mr = $('.active-mr');
                var index_mr = parseInt(active_mr.attr('data-index'));
                var next_index_mr = index_mr - 1;
                var next_mr = $('.make-res-elem-quiz[data-index="' + next_index_mr + '"]');
                active_mr.removeClass('active-mr').hide();
                next_mr.addClass('active-mr').fadeIn();
                $("#current_mr").text(next_index_mr);
                if (next_index_mr == number_mrs) {
                    $('.go-prev-mr').show();
                    $('.go-next-mr').hide();
                } else if (next_index_mr == 1) {
                    $('.go-prev-mr').hide();
                    $('.go-next-mr').show();
                } else {
                    $('.go-prev-mr').show();
                    $('.go-next-mr').show();
                }
            });
            //Edit Result
            $('.edit-mr-btn').click(function() {
                var result_skill_salt = $(this).parent().attr('data-hash');
                var int_down = $('div[data-hash="' + result_skill_salt + '"] #int_down').val();
                var int_up = $('div[data-hash="' + result_skill_salt + '"] #int_up').val();
                var level_term_id = $('div[data-hash="' + result_skill_salt + '"] #level_term_id').val();
                var skill_term_id = $('div[data-hash="' + result_skill_salt + '"] #skill_term_id').val();
                var product_ids = $('div[data-hash="' + result_skill_salt + '"] select#product_ids').val();
                var txt_result_int_skill = tinymce.get(result_skill_salt).getContent();
                if (!product_ids || !result_skill_salt || !level_term_id || !skill_term_id || !int_down || !int_up) {
                    alert('تمامی فیلد ها ضروری اند !');
                    return;
                }
                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_set_interval_skill_edit",
                        int_down: int_down,
                        int_up: int_up,
                        result_skill_salt: result_skill_salt,
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id,
                        product_ids: product_ids,
                        txt_result_skill_int:txt_result_int_skill
                    },
                    beforeSend: function() {
                        $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('');
                        $('div[data-hash="' + result_skill_salt + '"] .edit-mr-btn').html("در حال ارسال " + "<i class='fa fa-spin fa-spinner'></i>");
                        $('div[data-hash="' + result_skill_salt + '"] .edit-mr-btn').css({
                            'background': 'orange'
                        });
                    },
                    complete: function(res) {

                        $('div[data-hash="' + result_skill_salt + '"] .edit-mr-btn').html("<i class='fa fa-pencil-square-o'></i>")
                        $('div[data-hash="' + result_skill_salt + '"] .edit-mr-btn').css({
                            'background': '#dbc81f'
                        });
                        $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('با موفقیت ویرایش شد .');
                        setTimeout(function() {
                            $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('');
                        }, 10000);
                    },
                    error: function(res) {
                        $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('');
                    }
                });
            });
            //Delete Result
            $('.delete-mr-btn').click(function() {
                var result_skill_salt = $(this).parent().attr('data-hash');
                var level_term_id = $('div[data-hash="' + result_skill_salt + '"] #level_term_id').val();
                var skill_term_id = $('div[data-hash="' + result_skill_salt + '"] #skill_term_id').val();

                if (!result_skill_salt) {
                    alert('تمامی فیلد ها ضروری اند !');
                    return;
                }
                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_set_interval_skill_delete",
                        result_skill_salt: result_skill_salt,
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id
                    },
                    beforeSend: function() {
                        $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('');
                        $('div[data-hash="' + result_skill_salt + '"] .delete-mr-btn').html("<i class='fa fa-spin fa-spinner'></i>");
                        $('div[data-hash="' + result_skill_salt + '"] .delete-mr-btn').css({
                            'background': '#eb837c'
                        });
                    },
                    complete: function(res) {
                        $('div[data-hash="' + result_skill_salt + '"] .delete-mr-btn').html("<i class='fa fa-pencil-square-o'></i>")
                        $('div[data-hash="' + result_skill_salt + '"] .delete-mr-btn').css({
                            'background': '#db2c1f'
                        });
                        $('div[data-hash="' + result_skill_salt + '"]').fadeOut();
                        $('div[data-hash="' + result_skill_salt + '"]').remove();
                        $('.mfp-close').click();

                    },
                    error: function(res) {
                        $('div[data-hash="' + result_skill_salt + '"] .msg-for-edit-delete').html('');
                    }
                });


            });

        });
    </script>
<?php
} else {
?>
    <h4 style="color: red;text-align:center;"> تاکنون بازه ای برای نتیجه گیری این سطح تعریف نکرده اید ! </h4>
<?php
}
