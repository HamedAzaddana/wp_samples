<p class="utec-quiz-header-mfp-title">
    افزودن سوالات <?php $level_title = get_term_by('id', $level_term_id, "product_cat")->name;
    echo $level_title; ?>
</p>

<input type="hidden" id="level_term_id" name="level_term_id" value="<?php echo $level_term_id; ?>">
<label for="">متن سوال : </label>
<input type="text" id="title_ques" name="title_ques" placeholder="مثلا: سوال اول">
<br><br>
<label for="">رده مهارتی مربوطه : </label>
<select name="skill_term_id" id="skill_term_id">
    <option value="0" selected>*یک مورد را انتخاب کنید*</option>
    <?php
    foreach ($product_skills as $skill) {
        $term_id = $skill->term_id;
        $term_title = $skill->name;
    ?>
        <option value="<?php echo $term_id; ?>"><?php echo $term_title; ?></option>
    <?php
    }
    ?>
</select>
<br><br>
<label for="">ترتیب سوال در رده این سطح: </label>
<input type="number" value="1" id="order_ques" name="order_ques" placeholder="مثلا: 12">
<br><br>

<div class="repeat-options" id="Options_Section">
    <table class="wrapper" width="100%">
        <thead>
        </thead>
        <tbody class="container">
            <tr class="template row" style="margin-bottom:10px;margin-top:10px;padding:10px;">

                <td width="10%"><span class="move"><i class="fa fa-arrows"></i></span></td>

                <td width="70%">
                    <div class="opt_class_box">
                        <br>
                        <label>متن گزینه : </label>
                        <input autocomplete="off" list="opt_txt" type="text" class="options_txt" name="option_txt[{{row-count-placeholder}}]" id="option_txt[{{row-count-placeholder}}]" placeholder="مثلا: گزینه اول">
                        <br>
                        <label>نمره گزینه : </label>
                        <input autocomplete="off" list="opt_score" type="number" class="options_score" name="option_score[{{row-count-placeholder}}]" id="option_score[{{row-count-placeholder}}]" placeholder="مثلا: 5">
                    </div>
                </td>

                <td width="10%"><span class="remove remove-opt btn-go-delete-ajax"><i class="fa fa-trash-o"></i></span></td>
            </tr>
        </tbody>
        <tr>
            <td width="10%" colspan="4"><span class="add open-add-mag">افزودن گزینه+</span></td>
        </tr>
    </table>
</div>

<button type="button" id="add-ques-btn-post" class="btn-go-add-ajax"><i class="fa fa-paper-plane-o"></i></button>
<br><br>
<span class="msg-add-question-scc" style="color: red;"></span>
<br>
<script>
    jQuery(document).ready(function($) {
        var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
        //function ajax
        function Utec_Request_Ajax(wp_data, wp_action, wp_container = null, wp_url = '', prelaod_msg = '') {
            var final_data = {
                ...wp_data,
                action: wp_action
            }
            $.ajax({
                url: wp_url,
                type: "POST",
                data: final_data,
                beforeSend: function() {
                    if (wp_container) {
                        wp_container.html(`<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>${prelaod_msg} </span></center>`);
                    }
                },
                complete: function(res) {
                    if (wp_container) {
                        wp_container.html(`<button title="Close (Esc)" type="button" class="mfp-close">×</button><br>`+res.responseText);
                    }
                },
                error: function(res) {
                    if (wp_container) {
                        wp_container.html(res.responseText);
                    }
                }
            });
        }
        //repeating fields
        $('.repeat-options').each(function() {
            $(this).repeatable_fields();
        });
        //get order question
        $('#skill_term_id').change(function() {
            var order_elem = $('#order_ques');
            var level_term_id = $('#level_term_id').val();
            var skill_term_id = parseInt($('#skill_term_id').val());
            var loadin_phrase = "<center class='loading_icon_status_certif' style='padding:0px;'><i style='font-size:14px' class='fa fa-2x fa-spin fa-spinner'></i></center>"
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: {
                    action:"utec_quiz_get_order_ques_ajax",
                    skill_term_id:skill_term_id,
                    level_term_id:level_term_id
                },
                beforeSend: function() {
                    order_elem.attr('disabled','disabled');
                    $(loadin_phrase).insertAfter(order_elem);
                },
                complete: function(res) {
                    $('.loading_icon_status_certif').remove();
                    order_elem.removeAttr('disabled');
                    order_elem.val(res.responseText)
                },
                error: function(res) {
                    $('.loading_icon_status_certif').remove();
                    order_elem.removeAttr('disabled');
                }
            });
        });
        //save quesution
        $('#add-ques-btn-post').click(function() {
            var title_ques = $('#title_ques').val();
            var level_term_id = $('#level_term_id').val();
            var skill_term_id = parseInt($('#skill_term_id').val());
            var order_ques = $('#order_ques').val();
            var options_txt = $("#Options_Section .options_txt");
            var options_score = $("#Options_Section .options_score");
            var options_txt_array = [];
            var options_score_array = [];
            var options_array = "";
            options_txt.each(function() {
                if ($(this).val() != "") {
                    options_txt_array.push($(this).val());
                }

            })
            options_score.each(function() {
                if ($(this).val() != "") {
                    options_score_array.push($(this).val());
                }
            })

            var cnt_opt = options_txt_array.length - 1;
            var i = 0;
            for (i = 0; i <= cnt_opt; i++) {
                options_array = options_array + options_txt_array[i] + "*" + options_score_array[i] + "@";
            }

            // console.log(options_array, skill_term_id, level_term_id,order_ques);
            if (!title_ques || !options_array || skill_term_id == 0 || !order_ques || !level_term_id) {
                alert('تمامی فیلد ها ضروری اند !');
                $('.msg-add-question-scc').html('');
                return;
            }
            var post_data = {
                title_ques: title_ques,
                level_term_id:level_term_id,
                order_ques: order_ques,
                skill_term_id: skill_term_id,
                options_array: options_array
            }
            Utec_Request_Ajax(post_data,
                "utec_quiz_save_question_ajax",
                $('#Modal_Quiz_Container'),
                ajax_url,
                "در حال ذخیره سوال ..."
            );

        })
    });
</script>