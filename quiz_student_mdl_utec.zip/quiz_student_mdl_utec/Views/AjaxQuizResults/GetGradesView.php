<h2 class="mfp-header-modal">نتیجه آزمون تعیین سطح کاربر <?php echo  $full_name; ?> , تاریخ <?php echo  $date_pers; ?></h2>
<?php
if ($quiz_results_row) {
?>
    <div id="utec-All-Result-Container">
        <?php
        //get settings
        $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
        $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
        $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');

        $args_query_prod_cate = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );
        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_cates_all = get_terms($args_query_prod_cate);
        $product_skills = get_terms($args_query_prod_skill);

        $product_cates = [];

        foreach ($product_cates_all as $cate) {
            if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                $product_cates[] = $cate;
            }
        }
        $utec_level_results_intervals = unserialize(get_option("utec_level_results_intervals", "")) ?
            unserialize(get_option("utec_level_results_intervals", "")) : [];
        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];

        //the rest
        date_default_timezone_set('Asia/Tehran');
        $quiz_results_row = $quiz_results_row[0];
        $result_array = unserialize(base64_decode($quiz_results_row->results));
        // utec_dd($result_array);
        $date = $quiz_results_row->date;
        $date_pers = utec_auth_sanitize_to_fa(jdate("Y/m/d", $date));
        ?>
        <?php
        $Courses_Ids = [];
        foreach ($product_cates as $level) {
            $level_id = $level->term_id;
            $level_title = $level->name;
            $level_color = get_term_meta($level_id, "color_level", true);

            $key_settingsLevel = "settings_level_" . $level_id;
            $level_settings = [];
            foreach ($utec_settings_quiz as $Key_setting => $itemSetting) {
                if ($Key_setting == $key_settingsLevel) {
                    $level_settings = $itemSetting;
                }
            }
            $method_grading_level = $level_settings['method_grading_level'];
            $skill_garades_for_the_level = [];
            $level_grade_user = 0;
            $level_grade_user_final = 0;
            foreach ($result_array as $result_item) {
                if ($result_item['level_term_id'] == $level_id) {
                    $level_grade_user = $level_grade_user + $result_item['grade'];
                }
            }
            if ($method_grading_level == "sum") {
                $level_grade_user_final = $level_grade_user;
            }
            if ($method_grading_level == "avg") {
                $numberOfSkills = count($product_skills);
                $level_grade_user_final = ($level_grade_user / $numberOfSkills);
            }
            $utec_level_results_intervals_level = [];
            foreach ($utec_level_results_intervals as $item) {
                if ($item['level_term_id'] == $level_id) {
                    $utec_level_results_intervals_level[] = $item;
                }
            }
            usort($utec_level_results_intervals_level, function ($first, $second) {
                return intval($first['int_down']) > intval($second['int_down']);
            });
            $text_show_Level = "";

            foreach ($utec_level_results_intervals_level as $interval_level) {
                $intDown = $interval_level['int_down'];
                $intUp = $interval_level['int_up'];
                $text_level_result_item = $interval_level['txt_result_level_int'];
                if ($intUp > $level_grade_user_final && $intDown <= $level_grade_user_final) {
                    $text_show_Level = $text_level_result_item;
                }
            }
            $style_table_all = "border: 1px solid $level_color;
                                border-radius: 20px;text-align: center;vertical-align:middle;border-collapse:initial;";
        ?>
            <div class="utec-result-all-container">
                <h3 class="utec-result-header-level" style="color:<?php echo $level_color; ?>;">
                    <?php echo $level_title  ?>
                </h3>
                <table style="width:100%;<?php echo $style_table_all ?>" class="utec-table-result">
                    <tr>
                        <th style="width:20%;<?php echo $style_table_all ?>font-weight:bolder;font-size:19px;">رده مهارتی</th>
                        <th style="<?php echo $style_table_all ?>font-weight:bolder;font-size:19px;">نتیجه ارزیابی</th>
                    </tr>
                    <?php
                    foreach ($product_skills as $skill) {
                        $utec_level_results_intervals_skill = [];
                        $skill_id = $skill->term_id;
                        $skill_title = $skill->name;
                        $skill_img = get_term_meta($skill_id, "featured_cate_skill_img", true);
                        $skill_grade_user = 0;
                        $skill_grade_user_final = 0;
                        $segment_grade = 0;
                        $segment_status_pass = "fail";
                        foreach ($result_array as $result_item) {
                            if (
                                $result_item['level_term_id'] == $level_id
                                && $result_item['skill_term_id'] == $skill_id
                            ) {
                                $segment_grade = $result_item['grade'];
                                $segment_status_pass = $result_item['status_pass'];
                            }
                        }
                        foreach ($quiz_new_skills_rs_already as $item) {
                            if (
                                $item['level_term_id'] == $level_id
                                && $item['skill_term_id'] == $skill_id
                            ) {
                                $utec_level_results_intervals_skill[] = $item;
                            }
                        }
                        usort($utec_level_results_intervals_skill, function ($first, $second) {
                            return intval($first['int_down']) > intval($second['int_down']);
                        });
                        $text_show_Skill = "";
                        foreach ($utec_level_results_intervals_skill as $interval_skill) {
                            $intDown = $interval_skill['int_down'];
                            $intUp = $interval_skill['int_up'];
                            $product_ids = $interval_skill['product_ids'];

                            $text_skill_result_item = $interval_skill['txt_result_skill_int'];
                            if ($intUp > $segment_grade && $intDown <= $segment_grade && $product_ids) {
                                $Courses_Ids = array_merge($Courses_Ids, $product_ids);
                                $text_show_Skill = $text_skill_result_item;
                            }
                        }
                    ?>

                        <tr>
                            <td style="<?php echo $style_table_all ?>">
                                <h3>
                                    <div style="display: flex;justify-content: center;" class="utec-skill-div-all-result">
                                        <div style="margin-top:20%;" class="utec-skill-title-result">
                                            <?php echo $skill_title  ?>
                                        </div>
                                        <div style="display: flex;flex-direction:column;">
                                            <div>
                                                <?php if ($segment_status_pass == "success") {
                                                ?>
                                                    <i class="fa fa-check-circle-o " style="color:#40d040;font-size:40px;"></i>
                                                <?php
                                                } ?>
                                                <?php if ($segment_status_pass == "fail") {
                                                ?>
                                                    <i class="fa fa-times-circle-o " style="color:#d94747;font-size:40px;"></i>
                                                <?php
                                                } ?>
                                            </div>
                                            <div>
                                                <img class="utec-skill-img-result" style="width:50px ;height:50px;margin:10px;" src="<?php echo $skill_img ?>" alt="">
                                            </div>
                                        </div>
                                    </div>
                                </h3>
                            </td>
                            <td style="<?php echo $style_table_all ?>padding:15px;">
                                <?php
                                echo do_shortcode(stripslashes(urldecode($text_show_Skill)));
                                ?>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </table>
            </div>
        <?php
        }
        $Courses_Ids = array_unique($Courses_Ids);
  
} else {
?>
    <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #d83d3d;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
        <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> مجاز به دیدن این صفحه نیستید !
    </div>
<?php
}
