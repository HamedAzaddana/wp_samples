<?php if ($quiz_results_filtered) {
?>
    <table class="wp-list-table widefat fixed striped" id="tbl_users_bought_course">
        <thead style="position:sticky;top:30px;background-color:#B8B3B3;font-weight:bolder;text-align: center;">
            <tr style="text-align: center;">
                <th style="text-align: center;">نام و نام خانوادگی</th>
                <th style="text-align: center;">نام کاربری</th>
                <th style="text-align: center;">مشاهده نتایج</th>
                <th style="text-align: center;">تاریخ</th>
                <th style="text-align: center;">حذف</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($quiz_results_filtered as $qrs) {
                $user_id = intval($qrs->user_id);
                $user = get_user_by('id', $user_id);
                $username = $user->data->user_login;
                $first_name = get_user_meta($user->ID, 'first_name', true);
                $last_name = get_user_meta($user->ID, 'last_name', true);
                $full_name = $first_name . " " . $last_name;
            ?>
                <tr style="text-align: center;vertical-align:middle;" data-row="<?php echo $qrs->id; ?>">
                    <td style="text-align: center;vertical-align:middle;">
                        <?php echo $full_name; ?>
                    </td>
                    <td style="text-align: center;vertical-align:middle;">
                        <a href="<?php echo admin_url() . "user-edit.php?user_id=" . $user_id; ?>" target="_blank">
                            <?php
                            echo $username;
                            ?>
                        </a>
                    </td>
                    <td title="مشاهده نمرات آزمون" style="text-align: center;vertical-align:middle;">
                        <a href="#Modal-box-utec" data-result-id="<?php echo $qrs->id; ?>" style="background: #33bb71;border-color: #33bb71;" type="button" class="button button-primary button-large show-result-grades-utec">
                            <i class="fa fa-bar-chart  "></i>
                        </a>
                    </td>
                    <td style="text-align: center;vertical-align:middle;">
                        <?php $date = $qrs->date;
                        $date_pers = utec_auth_sanitize_to_fa(jdate("Y/m/d", $date));
                        echo $date_pers;
                        ?>
                    </td>
                    <td>
                        <button data-id="<?php echo $qrs->id; ?>" style="" type="button" title="حذف" class="btn-go-delete-ajax delete-title-btn"> <i class="fa fa-trash"></i> </button>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
        <tfoot>
            <tr style="text-align: center;">
                <th style="text-align: center;">نام و نام خانوادگی</th>
                <th style="text-align: center;">نام کاربری</th>
                <th style="text-align: center;">مشاهده نتایج</th>
                <th style="text-align: center;">تاریخ</th>
                <th style="text-align: center;">حذف</th>
            </tr>
        </tfoot>
    </table>
    <center style="margin:10px ;">
        تعداد نتایج : <?php echo $cnt_results; ?>
        <br>
        <div class="pagination_utec_customers" style="padding:10px;">

            <a class="pagins go_prev_page" go-number-page="<?php echo $paged_num - 1; ?>" href="#page-prev-<?php echo $paged_num - 1; ?>" <?php if ($paged_num == 1) {
                                                                                                                                                echo " style='display:none;' ";
                                                                                                                                            } ?>>&raquo;</a>
            <?php

            for ($i = 1; $i <= $links_num; $i++) :
            ?>
                <a href="#page-<?php echo $i; ?>" class="pagins go_this_page  <?php if ($paged_num == $i) {
                                                                                    echo "active";
                                                                                } ?>">
                    <?php echo $i; ?>
                </a>
            <?php endfor;  ?>
            <a class="pagins go_next_page" go-number-page="<?php echo $paged_num + 1; ?>" href="#page-next-<?php echo $paged_num + 1; ?>" <?php if ($paged_num == $last_num_paged) {
                                                                                                                                                echo " style='display:none;' ";
                                                                                                                                            } ?>>&laquo;</a>
        </div>
    </center>
<?php
} else {
?>
    <center>
        <h3 style="color:red;">نتیجه ای یافت نشد !</h3>
    </center>
<?php
}
?>
<div id="Modal-box-utec" class="white-popup mfp-hide">

</div>
<script>
    jQuery(document).ready(function($) {

        //Fuctions 
        function conv_num_to_en(txt) {
            txt = txt.replaceAll("۱", "1");
            txt = txt.replaceAll("۲", "2");
            txt = txt.replaceAll("۳", "3");
            txt = txt.replaceAll("۴", "4");
            txt = txt.replaceAll("۵", "5");
            txt = txt.replaceAll("۶", "6");
            txt = txt.replaceAll("۷", "7");
            txt = txt.replaceAll("۸", "8");
            txt = txt.replaceAll("۹", "9");
            txt = txt.replaceAll("۰", "0");
            return txt;
        }

        function GetResults(KeyWord = '', paged_num = 1) {
            var utec_customers_container = $('#utec_customers_container');
            $.ajax({
                url: <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>,
                type: "POST",
                data: {
                    action: "utec_quiz_get_user_results",
                    KeyWord: KeyWord,
                    paged_num: paged_num
                },
                beforeSend: function() {
                    utec_customers_container.html("<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>در حال دریافت اطلاعات ...</span></center>");
                },
                complete: function(res) {
                    utec_customers_container.html(res.responseText);
                },
                error: function(res) {
                    utec_customers_container.html(res.responseText);
                }
            });
        }
        //Pagination Hide Links

        var links_pagination = $(".pagination_utec_customers a");

        var number_pages = links_pagination.length;
        var last_page_num = links_pagination.length - 2;
        var active_link = $(".pagination_utec_customers a.active");
        var active_page_number = parseInt(conv_num_to_en(active_link.text()));
        var showed_just_nums = [1, 2, 3, last_page_num, last_page_num - 1, last_page_num - 2, last_page_num - 3, active_page_number, active_page_number + 1, active_page_number + 2, active_page_number + 3,
            active_page_number - 1, active_page_number - 2, active_page_number - 3,
        ];

        for (var pi = 0; pi < number_pages; ++pi) {
            var page_item = links_pagination[pi];
            var px = parseInt(conv_num_to_en(links_pagination[pi].innerText));
            if (px) {
                if (!showed_just_nums.includes(px)) {
                    page_item.style.display = "none";
                    page_item.classList.add("hidden_page_item");
                }
            }

        }
        var links_pagination_hidden = $(".pagination_utec_customers a.hidden_page_item");
        var links_pagination_hidden_last_index = links_pagination_hidden.length - 1;
        if (links_pagination_hidden[links_pagination_hidden_last_index] && links_pagination_hidden_last_index) {
            links_pagination_hidden[links_pagination_hidden_last_index].style.display = "block";
            links_pagination_hidden[links_pagination_hidden_last_index].innerText = "...";
            links_pagination_hidden[links_pagination_hidden_last_index].href = "javascript:void(0)";
            links_pagination_hidden[links_pagination_hidden_last_index].onclick = (e) => {
                e.preventDefault();
            }
        }

        if (links_pagination_hidden[0]) {
            links_pagination_hidden[0].style.display = "block";
            links_pagination_hidden[0].innerText = "...";
            links_pagination_hidden[0].href = "javascript:void(0)";
            links_pagination_hidden[0].onclick = (e) => {
                e.preventDefault();
            }
        }




        //Pagination Show
        $('.pagination_utec_customers a').click(function() {
            event.preventDefault();
            var thisa = $(this);
            var current_page = parseInt("<?php echo $paged_num; ?>");
            var gonumber = 1;
            var kw_search = "<?php echo $KeyWord; ?>";
            if (thisa.hasClass('go_this_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.text()));
            }
            if (thisa.hasClass('go_next_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.attr('go-number-page')));
            }
            if (thisa.hasClass('go_prev_page')) {
                gonumber = parseInt(conv_num_to_en(thisa.attr('go-number-page')));
            }
            GetResults(kw_search, gonumber);
        })

        //Show Modal Grades
        $('.show-result-grades-utec').magnificPopup({
            type: 'inline',
            midClick: true
        });
        $('.show-result-grades-utec').click(function() {
            var result_id = $(this).attr('data-result-id');
            var Modal_container = $('#Modal-box-utec');
            $.ajax({
                url: <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>,
                type: "POST",
                data: {
                    action: "utec_quiz_get_user_results_grades",
                    result_id: result_id
                },
                beforeSend: function() {
                    Modal_container.html("<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>در حال دریافت اطلاعات ...</span></center>");
                },
                complete: function(res) {
                    Modal_container.html(res.responseText);
                },
                error: function(res) {
                    Modal_container.html(res.responseText);
                }
            });
        });
        //Delete Result
        $('.delete-title-btn').click(function() {
            var this_btn_delete = $(this);
            var btn_data_delete_id = $(this).attr('data-id');
            var IdResult = btn_data_delete_id;
            var tr_row_delete = $('tr[data-row="' + btn_data_delete_id + '"]');
            if (!confirm('آیا برای حذف این نتیجه آزمون مطمئنید ؟')) {
                return;
            }
            $.ajax({
                url: <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>,
                type: "POST",
                data: {
                    action: "utec_quiz_delete_single_rs_quiz",
                    IdResult: IdResult
                },
                beforeSend: function() {
                    this_btn_delete.html("<i class='fa fa-spin fa-spinner'></i>");
                },
                complete: function(res) {
                    this_btn_delete.html("<i class='fa fa-trash'></i>");
                    tr_row_delete.fadeOut();
                },
                error: function(res) {
                    this_btn_delete.html("<i class='fa fa-trash'></i>");
                }
            });
        });

    });
</script>