<h3>تنظیمات و تعریف آزمون تعیین سطح</h3>
<?php
$utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
$parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
$term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');

$args_query_prod_cate = array(
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
);
$args_query_prod_skill = array(
    'taxonomy' => 'skill-category',
    'hide_empty' => false,
);
$product_cates_all = get_terms($args_query_prod_cate);
$product_skills = get_terms($args_query_prod_skill);

$product_cates = [];

foreach ($product_cates_all as $cate) {
    if ($cate->parent && $cate->parent == $term_parent['term_id']) {
        $product_cates[] = $cate;
    }
}

?>
<script>
    function OpenTabContentQuiz(evt, cityName) {
        // Declare all variables
        var i, tabcontent, tablinks;

        // Get all elements with class="tabcontent" and hide them
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }

        // Get all elements with class="tablinks" and remove the class "active"
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }

        // Show the current tab, and add an "active" class to the button that opened the tab
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<div id="utec-quiz-settings">
    <?php if ($product_cates) { ?>
        <div class="tab">
            <?php $i = 1;
            foreach ($product_cates as $prod_cate) {
                $term_id = $prod_cate->term_id;
                $term_title = $prod_cate->name;
                $active_class = ($i == 1) ? ("active") : ("");
            ?>
                <button class="tablinks <?php echo $active_class; ?>" onclick="OpenTabContentQuiz(event, '<?php echo 'level-id-' . $term_id; ?>')"> <i class="fa fa-cubes "></i> <?php echo $term_title; ?></button>
            <?php $i++;
            } ?>
            <button class="tablinks" onclick="OpenTabContentQuiz(event, 'Overall-Settings')"> <i class="fa fa-cog "></i> عمومی</button>
        </div>
        <!-- Tab content -->
        <?php $j = 1;
        foreach ($product_cates as $prod_cate) {
            $term_id = $prod_cate->term_id;
            $term_title = $prod_cate->name;
            $display = ($j == 1) ? ("block") : ("none");
            $key_level = "settings_level_" . $term_id;
            $order_level_show = 1;
            $shuffle_questions = 0;
            $grading_skill = [];
            if ($utec_settings_quiz && isset($utec_settings_quiz["$key_level"])) {
                $settings_for_level =  $utec_settings_quiz["$key_level"];
                $grading_skill = $settings_for_level['grading_skill'];
                $order_level_show = $settings_for_level['order_level_show'];
                $shuffle_questions = $settings_for_level['shuffle_questions'];
                $method_grading_level = $settings_for_level['method_grading_level'];
            }
            $checked_shuffle = ($shuffle_questions) ? ("checked") : ("");

            $selected_sum_method_grading_level = ($method_grading_level == "sum") ? ("selected") : ("");
            $selected_avg_method_grading_level = ($method_grading_level == "avg") ? ("selected") : ("");
        ?>
            <div style="display:<?php echo $display; ?>;" id="<?php echo 'level-id-' . $term_id; ?>" class="tabcontent">
                <br>
                <div class="utec_level_settings_form" level-id="<?php echo $term_id; ?>">
                    <label for="order_level_show">ترتیب نمایش سطح در سوالات آزمون : </label>
                    <input min="1" level-id="<?php echo $term_id; ?>" value="<?php echo $order_level_show; ?>" type="number" name="order_level_show" id="order_level_show">
                    <br><br>
                    <label for="shuffle_questions">ترتیب نمایش سوالات به صورت تصادفی شود </label>
                    <input <?php echo $checked_shuffle; ?> level-id="<?php echo $term_id; ?>" value="1" type="checkbox" name="shuffle_questions" id="shuffle_questions">
                    <br><br>
                    <label for="method_grading_level">شیوه محاسبه نمره سطح : </label>
                    <select level-id="<?php echo $term_id; ?>" name="method_grading_level" class="method_grading_level">
                        <option <?php echo $selected_sum_method_grading_level; ?> value="sum">جمع نمرات رده ها</option>
                        <option <?php echo $selected_avg_method_grading_level; ?> value="avg">میانگین نمرات رده ها</option>
                    </select>
                    <br><br>
                    <?php foreach ($product_skills as $prod_skill) {
                        $term_id_skill = $prod_skill->term_id;
                        $term_title_skill = $prod_skill->name;
                        $method_grading = "sum";
                        $min_grade = "1";
                        $order_skill_in_level = "1";
                        if ($grading_skill) {
                            foreach ($grading_skill as $gk) {
                                if ($gk['skill_id'] == $term_id_skill) {
                                    $method_grading = $gk['method_grading'];
                                    $min_grade = $gk['min_grade'];
                                    $order_skill_in_level = $gk['order_skill_in_level'];
                                }
                            }
                        }
                        $selected_sum = ($method_grading == "sum") ? ("selected") : ("");
                        $selected_avg = ($method_grading == "avg") ? ("selected") : ("");

                    ?>
                        <h4><i class="fa fa-cube"></i> رده <?php echo $term_title_skill; ?> : </h4>
                        <label for="method_grading_skill">شیوه محاسبه نمره رده در این سطح : </label>
                        <select skill-id="<?php echo $term_id_skill; ?>" level-id="<?php echo $term_id; ?>" name="method_grading_skill" class="method_grading_skill">
                            <option <?php echo  $selected_sum; ?> value="sum">جمع</option>
                            <option <?php echo  $selected_avg; ?> value="avg">میانگین</option>
                        </select>
                        <br><br>
                        <label for="min_grade_skill">حداقل نمره قبولی رده در این سطح : </label>
                        <input min="1" skill-id="<?php echo $term_id_skill; ?>" level-id="<?php echo $term_id; ?>" value="<?php echo $min_grade; ?>" type="number" name="min_grade_skill" class="min_grade_skill">
                        <br><br>

                        <label for="order_skill_in_level"> ترتیب نمایش سوالات رده در این سطح : </label>
                        <input min="1" skill-id="<?php echo $term_id_skill; ?>" level-id="<?php echo $term_id; ?>" value="<?php echo $order_skill_in_level; ?>" type="number" name="order_skill_in_level" class="order_skill_in_level">
                        <br><br>

                        <table class="table tbl-questions">
                            <thead>
                                <tr>
                                    <td style="width: 35%;font-size: 15px;">
                                        مدیریت نتایج رده <?php echo $term_title_skill; ?> در این سطح:
                                    </td>
                                    <td>
                                        <a style="background:#59b957;" skill-id="<?php echo $term_id_skill; ?>" level-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-add-mag Open_Modal_Quiz_Container add-skill-interval"><i class="fa fa-paper-plane "></i> افزودن بازه نتیجه گیری +</a>
                                    </td>
                                    <td>
                                        <a style="background:#5296e1;" skill-id="<?php echo $term_id_skill; ?>" level-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-edit-mag Open_Modal_Quiz_Container show-skill-interval-btn"><i class="fa fa-bars "></i> بازه های تعریف شده</a>
                                    </td>
                                </tr>
                            </thead>
                        </table>

                    <?php } ?>
                    <button level-id="<?php echo $term_id; ?>" type="button" class="button button-primary button-large set-settings">ذخیره تنظیمات این سطح</button>
                </div>

                <table class="table tbl-questions">
                    <thead>
                        <tr>
                            <td style="width: 35%;font-size: 15px;">
                                مدیریت سوالات <?php echo $term_title; ?>:
                            </td>
                            <td>
                                <a level-term-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-add-mag Open_Modal_Quiz_Container " id="add-ques"><i class="fa fa-paper-plane "></i> افزودن سوال +</a>
                            </td>
                            <td>
                                <a level-term-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-edit-mag Open_Modal_Quiz_Container " id="show-ques-btn"><i class="fa fa-bars "></i> سوالات تعریف شده</a>
                            </td>
                        </tr>
                    </thead>
                </table>
                <!-- <table class="table tbl-questions">
                    <thead>
                        <tr>
                            <td style="width: 35%;font-size: 15px;">
                                مدیریت نتایج <?php echo $term_title; ?>:
                            </td>
                            <td>
                                <a level-term-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-add-mag Open_Modal_Quiz_Container " id="add-level-interval"><i class="fa fa-paper-plane "></i> افزودن بازه نتیجه گیری +</a>
                            </td>
                            <td>
                                <a level-term-id="<?php echo $term_id; ?>" href="#Modal_Quiz_Container" class="open-edit-mag Open_Modal_Quiz_Container " id="show-level-interval-btn"><i class="fa fa-bars "></i> بازه های تعریف شده</a>
                            </td>
                        </tr>
                    </thead>
                </table> -->
            </div>
        <?php $j++;
        } ?>
        <div style="display:none;" id="Overall-Settings" class="tabcontent">
            <br>
            <label for="" style="font-size: 15px;font-weight:bold;">توضیحات قبل شروع آزمون : </label>
            <br><br>
            <?php
            $utec_before_quiz_description = "";
            if (get_option("utec_before_quiz_description", "")) {
                $utec_before_quiz_description = stripslashes(urldecode(get_option("utec_before_quiz_description", "")));
            }
            wp_editor($utec_before_quiz_description, 'utec_before_quiz_description');
            ?>
            <br>
            <label for="" style="font-size: 15px;font-weight:bold;">متن اخطار نمایشی ابتدای آزمون : </label>
            <br><br>
            <?php
            $utec_begin_quiz_alert = "";
            if (get_option("utec_begin_quiz_alert", "")) {
                $utec_begin_quiz_alert = stripslashes(urldecode(get_option("utec_begin_quiz_alert", "")));
            }
            wp_editor($utec_begin_quiz_alert, 'utec_begin_quiz_alert');
            ?>
            <br><br>
            <?php
            $number_of_max_go_quiz_valid = intval(get_option("number_of_max_go_quiz_valid", 1));
            ?>
            <label for="number_of_max_go_quiz_valid">حداکثر تعداد دفعات مجاز شرکت در آزمون : </label>
            <input min="1" value="<?php echo $number_of_max_go_quiz_valid; ?>" type="number" name="number_of_max_go_quiz_valid" id="number_of_max_go_quiz_valid">
            <br><br>
            <h3>تصویر نمایشی برای آزمون تعیین سطح : </h3>
            <?php
            add_action('admin_enqueue_scripts', function () {
                if (is_admin())
                    wp_enqueue_media();
            });
            ?>
            <?php
            $utec_icon_show_result_list = get_option("utec_icon_show_result_list", "");
            $display_icon_img = ($utec_icon_show_result_list) ? "block" : "none";
            ?>
            <p>
                <input type="hidden" value="<?php echo $utec_icon_show_result_list; ?>" class="regular-text process_custom_images" id="utec_icon_show_result_list" name="utec_icon_show_result_list">
                <button type="button" class="set_custom_images button"><i class="fa fa-file-image-o"></i>انتخاب تصویر</button>
                <button type="button" class="button" id="delete-utec_icon_show_result_list"><i class="fa fa-trash"></i> حذف تصویر</button>
            </p>
            <center>
                <img id="logo-result-icon-section" src="<?php echo $utec_icon_show_result_list; ?>" style="display:<?php echo $display_icon_img; ?>;width: 210px; height:210px;border-radius:15px;border:1px solid gray;" alt="">
            </center>
            <br><br>
            <button type="button" id="set-overall-settings" class="button button-primary button-large">ذخیره تنظیمات</button>
        </div>
    <?php } ?>
    <div id="Modal_Quiz_Container" class="white-popup-quiz mfp-hide">

    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        function Utec_Request_Ajax(wp_data, wp_action, wp_container = null, wp_url = '', prelaod_msg = '') {
            var final_data = {
                ...wp_data,
                action: wp_action
            }
            $.ajax({
                url: wp_url,
                type: "POST",
                data: final_data,
                beforeSend: function() {
                    if (wp_container) {
                        wp_container.html(`<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>${prelaod_msg} </span></center>`);
                    }
                },
                complete: function(res) {
                    if (wp_container) {
                        wp_container.html(`<button title="Close (Esc)" type="button" class="mfp-close">×</button><br>` + res.responseText);
                    }
                },
                error: function(res) {
                    if (wp_container) {
                        wp_container.html(res.responseText);
                    }
                }
            });
        }
        var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
        $('.Open_Modal_Quiz_Container').magnificPopup({
            type: 'inline',
            midClick: true
        });
        $('.Open_Modal_Quiz_Container').click(function() {
            var modal_id = $(this).attr('id');
            var level_term_id = $(this).attr('level-term-id');

            //Add Question
            if (modal_id == "add-ques") {
                Utec_Request_Ajax({
                        level_term_id: level_term_id
                    },
                    "utec_quiz_add_question_ajax",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری فرم ..."
                );
            }
            //Show Question
            if (modal_id == "show-ques-btn") {
                Utec_Request_Ajax({
                        level_term_id: level_term_id
                    },
                    "utec_quiz_show_questions_ajax",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری سوالات ..."
                );
            }
            //Add Level Interval
            if (modal_id == "add-level-interval") {
                Utec_Request_Ajax({
                        level_term_id: level_term_id
                    },
                    "utec_quiz_set_interval_level",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری فرم نتایج ..."
                );
            }
            //Show Level Intervals
            if (modal_id == "show-level-interval-btn") {
                Utec_Request_Ajax({
                        level_term_id: level_term_id
                    },
                    "utec_quiz_set_interval_level_show",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری نتایج ..."
                );
            }
            //Add Skill Interval
            if ($(this).hasClass('add-skill-interval')) {
                var level_term_id = $(this).attr('level-id');
                var skill_term_id = $(this).attr('skill-id');
                Utec_Request_Ajax({
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id
                    },
                    "utec_quiz_set_interval_skill",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری نتایج ..."
                );
            }

            //Show Skill Interval
            if ($(this).hasClass('show-skill-interval-btn')) {
                var level_term_id = $(this).attr('level-id');
                var skill_term_id = $(this).attr('skill-id');
                Utec_Request_Ajax({
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id
                    },
                    "utec_quiz_set_interval_skill_show",
                    $('#Modal_Quiz_Container'),
                    ajax_url,
                    "در حال بارگذاری نتایج ..."
                );
            }

        });
        //Set Settings
        $('.set-settings').click(function() {
            var btn_save = $(this);
            var btn_save_text = btn_save.text();
            var level_id = $(this).attr('level-id');
            var form_parent = $(this).parent();
            var order_level_show = form_parent.find('#order_level_show').val();
            var shuffle_questions = form_parent.find('#shuffle_questions:checked').val();
            if (!shuffle_questions) {
                shuffle_questions = 0;
            }

            var method_grading_skill_all = form_parent.find('.method_grading_skill');
            var min_grade_skill_all = form_parent.find('.min_grade_skill');
            var order_skill_in_level_all = form_parent.find('.order_skill_in_level');
            var method_grading_level = form_parent.find('.method_grading_level').val();


            var method_grading_skill_str = "";
            var min_grade_skill_str = "";
            var order_skill_in_level_str = "";

            order_skill_in_level_all.each(function() {
                var item = $(this);
                var skill_id = item.attr('skill-id');
                var _val = item.val();
                order_skill_in_level_str = order_skill_in_level_str +
                    `${skill_id}_${_val}` +
                    "@";
            });

            method_grading_skill_all.each(function() {
                var item = $(this);
                var skill_id = item.attr('skill-id');
                var _val = item.val();
                method_grading_skill_str = method_grading_skill_str +
                    `${skill_id}_${_val}` +
                    "@";
            });

            min_grade_skill_all.each(function() {
                var item = $(this);
                var skill_id = item.attr('skill-id');
                var _val = item.val();
                min_grade_skill_str = min_grade_skill_str +
                    `${skill_id}_${_val}` +
                    "@";
            });
            var loadin_phrase = "<center class='loading_settings' style='padding:0px;'><i style='font-size:14px' class='fa fa-2x fa-spin fa-spinner'></i></center>"
            //Set Settings ajax
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: {
                    action: "utec_quiz_set_level_settings",
                    level_term_id: level_id,
                    order_level_show: order_level_show,
                    shuffle_questions: shuffle_questions,
                    min_grade_skill_str: min_grade_skill_str,
                    method_grading_skill_str: method_grading_skill_str,
                    order_skill_in_level_str: order_skill_in_level_str,
                    method_grading_level: method_grading_level
                },
                beforeSend: function() {
                    btn_save.html(loadin_phrase)

                },
                complete: function(res) {
                    btn_save.html(btn_save_text)
                },
                error: function(res) {
                    btn_save.html(btn_save_text)
                }
            });
        });
        //delete logo icon result
        $('#delete-utec_icon_show_result_list').click(function() {
            $('#logo-result-icon-section').attr('src', '');
            $('#logo-result-icon-section').hide();
            $('#utec_icon_show_result_list').val('');
        });
        //set logo icon result
        if ($('.set_custom_images').length > 0) {
            if (typeof wp !== 'undefined' && wp.media && wp.media.editor) {
                $('.set_custom_images').on('click', function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var id = button.prev();
                    wp.media.editor.send.attachment = function(props, attachment) {
                        var size_img = (attachment.filesizeInBytes) / (1024);

                        if (!attachment.mime.includes('image')) {
                            event.preventDefault();
                            alert('فرمت فایل تصویری نیست !')
                            return;
                        }
                        id.val(attachment.url);
                        $('#logo-result-icon-section').attr('src', attachment.url);
                        $('#logo-result-icon-section').show();
                    };
                    wp.media.editor.open(button);
                    return false;
                });
            }
        }
        //set Overall Settings
        $('#set-overall-settings').click(function() {
            var btn_save = $(this);
            var btn_save_text = btn_save.text();
            var icon_result_img = $('#utec_icon_show_result_list').val();
            var number_of_max_go_quiz_valid = $('#number_of_max_go_quiz_valid').val();
            var utec_before_quiz_description = tinymce.get("utec_before_quiz_description").getContent();
            var utec_begin_quiz_alert = tinymce.get("utec_begin_quiz_alert").getContent();
            var loadin_phrase = "<center class='loading_settings' style='padding:0px;'><i style='font-size:14px' class='fa fa-2x fa-spin fa-spinner'></i></center>"
            $.ajax({
                url: ajax_url,
                type: "POST",
                data: {
                    action: "utec_quiz_set_overall_settings",
                    utec_before_quiz_description: utec_before_quiz_description,
                    utec_begin_quiz_alert: utec_begin_quiz_alert,
                    icon_result_img: icon_result_img,
                    number_of_max_go_quiz_valid:number_of_max_go_quiz_valid
                },
                beforeSend: function() {
                    btn_save.html(loadin_phrase)
                },
                complete: function(res) {
                    btn_save.html(btn_save_text)
                },
                error: function(res) {
                    btn_save.html(btn_save_text)
                }
            });
        });
    });
</script>