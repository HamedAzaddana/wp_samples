<?php

if (is_user_logged_in()) {
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $username = $user->data->user_login;
    global $wpdb;
    $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
    $usr_id = get_current_user_id();
    $quiz_results = $wpdb->get_results("SELECT * FROM `$tbl_result` WHERE `user_id` = '$usr_id' order by `date` desc");
    $count_quiz_results = count($quiz_results);
    $number_of_max_go_quiz_valid = intval(get_option("number_of_max_go_quiz_valid", 1));
    $salt_nonce_go_quiz = "user_gonna_go_quiz" . $username . "*(E@Eh38*38r";
?>
    <!-- Go Quiz Btn -->
    <h3><i class="fa fa-users"></i> شرکت در آزمون تعیین سطح</h3>
    <?php if ($count_quiz_results >= $number_of_max_go_quiz_valid) {
    ?>
        <div style="padding: 15px;">
            <center>
                <button class="button-82-pushable" role="button" type="submit">
                    <span class="button-82-shadow"></span>
                    <span class="button-82-edge"></span>
                    <span class="button-82-front text">
                        شما قبلا در آزمون تعیین سطح شرکت کردی! <i class="fa fa-cube"></i>
                    </span>
                </button>
            </center>
        </div>
    <?php
    } else {
    ?>
        <div id="quiz_go" style="padding: 15px;">
            <form action="<?php echo site_url(); ?>/quiz_do" method="POST">
                <?php wp_nonce_field($salt_nonce_go_quiz, 'Go_Quiz_PlaceMent'); ?>
                <input type="hidden" name="go_quiz" value="1">
                <input type="hidden" name="show_before_desc" value="1">
                <center>
                    <button class="button-82-pushable" role="button" type="submit">
                        <span class="button-82-shadow"></span>
                        <span class="button-82-edge"></span>
                        <span class="button-82-front text">
                            شروع کنید ! <i class="fa fa-cube"></i>
                        </span>
                    </button>
                </center>
            </form>
        </div>
    <?php
    } ?>


    <!-- Quiz Results -->
    <h3><i class="fa fa-check-circle"></i> نتایج آزمون های تعیین سطح</h3>
    <br>
    <?php
    if ($quiz_results) {
        date_default_timezone_set('Asia/Tehran');
    ?>
        <div id="list_result_container">
            <div data-vc-full-width="true" data-vc-full-width-init="true" class="vc_row wpb_row vc_row-fluid vc_custom_1559222878118 vc_row-has-fill" style="position: relative; left: -1px; box-sizing: border-box;  padding-left: 0px; padding-right: 0px;">
                <div class="wpb_column vc_column_container vc_col-sm-12">
                    <div class="vc_column-inner">
                        <div class="wpb_wrapper">
                            <div class="vc_row wpb_row vc_inner vc_row-fluid">
                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-xs-12">
                                    <div class="vc_column-inner">
                                        <div class="wpb_wrapper">
                                            <div class="products grid-view courses-4-columns">
                                                <?php
                                                foreach ($quiz_results as $qrs) {
                                                    $CodeId  = base64_encode($qrs->id);
                                                    $url_redirect = site_url() . "/quiz_result/?code=" . $CodeId;
                                                    $date = $qrs->date;
                                                    $date_pers = utec_auth_sanitize_to_fa(jdate("Y/m/d", $date));
                                                    $icon_url = get_option("utec_icon_show_result_list", "https://armanienglish.com/wp-content/uploads/2019/04/taein-sath-1-300x259.jpg");
                                                ?>
                                                    <div class="utec_vc_result_box vc_col-sm-12 vc_col-xs-12 course-item utec-certif-course-item post-<?php echo $CodeId; ?> product type-product status-publish has-post-thumbnail product_cat-quiz_section first instock virtual purchasable product-type-simple">
                                                        <a href="<?php echo $url_redirect; ?>" target="_blank">
                                                            <div class="course-item-inner ">
                                                                <div class="course-thumbnail-holder">
                                                                    <img style="width:100%;height:200px;" src="<?php echo $icon_url; ?>" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail">
                                                                </div>
                                                                <div class="course-content-holder">
                                                                    <div class="course-content-main" style="height: 80px !important;">
                                                                        <div class="course-top-content">
                                                                            <h3 class="course-title">
                                                                                <i class="fal fa-cubes " style="font-size:20px;color:#470ead;"></i>&nbsp;
                                                                                مشاهده نتیجه آزمون تعیین سطح
                                                                                <br>
                                                                            </h3>
                                                                        </div>
                                                                    </div>
                                                                    <div class="course-content-bottom">
                                                                        <br>
                                                                        <div class="course-students">
                                                                            تاریخ آزمون :
                                                                            <?php
                                                                            echo $date_pers;
                                                                            ?>
                                                                        </div>
                                                                        <div class="course-price">
                                                                            <span class="price"><span class="amount"></span></span>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                <?php
                                                }
                                                ?>
                                                <?php
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    } else {
    ?>
        <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
            <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i>آزمونی تا به حال شرکت نکرده اید !
        </div>
    <?php
    } ?>
<?php
} else {
?>
    <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
        <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> باید ابتدا وارد شوید !
    </div>
<?php
}
