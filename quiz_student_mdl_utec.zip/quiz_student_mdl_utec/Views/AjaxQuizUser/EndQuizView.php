<div id="utec_end_quiz_elem_div" style="display: none;">
    <h3 style="padding:10px;font-size:19px;line-height:1.4;">
        <i class="fa fa-check-circle-o"></i>
        آزمون به اتمام رسید. برای ذخیره پاسخ ها و مشاهده نتیجه آزمون، روی دکمه زیر کلیک کنید.
    </h3>
    <?php
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $username = $user->data->user_login;

    $salt_nonce_end_quiz = "user_gonna_end_quiz" . $username . "QPPOEJf*@73jfMnxc";
    wp_nonce_field($salt_nonce_end_quiz, 'Quiz_Submission_Token');
    ?>
</div>
<script>
    jQuery(document).ready(function($) {
        var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
        $('footer').hide();
        $('.page-title').hide();
        $('.UtecALertsQuiz').hide();
        var utec_end_quiz_elem_div = document.createElement("div");
        utec_end_quiz_elem_div.innerHTML = $('#utec_end_quiz_elem_div').html();
        setTimeout(function() {
            swal({
                    content: utec_end_quiz_elem_div,
                    icon: "success",
                    closeOnClickOutside: false,
                    buttons: {
                        endQuiz: {
                            text: "اتمام آزمون",
                            value: "endQuiz",
                        },
                    },
                })
                .then((value) => {
                    if (value == "endQuiz") {
                        var Quiz_Submission_Token = $('#Quiz_Submission_Token').val();
                        var loading_btn_html = `در حال ذخیره سازی ... <i class="fa fa-spin fa-spinner"></i>`;
                        var complete_btn_html = `پاسخ شما ذخیره شد ... <i class="fa fa-check-circle "></i>`;
                        $.ajax({
                            url: ajax_url,
                            type: "POST",
                            data: {
                                action: "utec_quiz_end_quiz_show_result",
                                submit_all: 1,
                                Quiz_Submission_Token: Quiz_Submission_Token
                            },
                            beforeSend: function() {
                                swal({
                                    title: "در حال هدایت به صفحه ارزیابی آزمون ... ",
                                    closeOnClickOutside: false,
                                    buttons: false
                                });
                            },
                            complete: function(res) {
                                //redirect to result page
                                window.location.replace(res.responseText);
                            },
                            error: function(res) {

                            }
                        });
                    }
                });
        }, 100)


    });
</script>