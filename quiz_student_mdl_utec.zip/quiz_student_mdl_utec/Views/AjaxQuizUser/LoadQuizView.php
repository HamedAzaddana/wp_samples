<?php
$quiz_questions = $current_questions_segment;
$min_grade_pass = $quiz_questions['min_grade'];
$grading_method = $quiz_questions['method_grading'];
$is_shuffle = $quiz_questions['is_shuffle_level'];
$order_skill = $quiz_questions['order_skill'];
$order_level = $quiz_questions['order_level'];
$skill_term_id = $quiz_questions['skill_id'];
$level_term_id = $quiz_questions['level_id'];
$number_of_ques_current_seg = 0;

unset($quiz_questions['min_grade']);
unset($quiz_questions['method_grading']);
unset($quiz_questions['is_shuffle_level']);
unset($quiz_questions['order_skill']);
unset($quiz_questions['order_level']);
unset($quiz_questions['skill_id']);
unset($quiz_questions['level_id']);
if ($is_shuffle) {
    shuffle($quiz_questions);
} else {
    usort($quiz_questions, function ($first, $second) {
        return intval($first['order_ques']) > intval($second['order_ques']);
    });
}
if ($quiz_questions) {
?>

    <?php
    $cnt_questions = count($quiz_questions);
    $ques_counter = 1;
    foreach ($quiz_questions as $key_ques => $ques) {
        if (!$ques['title_ques']) {
            continue;
        }
        $number_of_ques_current_seg++;
        $options_array = [];
        $opt_str = $ques['options_array'];
        $pieces = [];
        if ($opt_str) {
            $pieces = explode("@", $opt_str);
            $pieces = array_filter($pieces, function ($var) {
                return $var;
            });
        }
        $mod3Counter =  $ques_counter % 3;
        switch ($mod3Counter) {
            case 0:
                $bgColorBox = "#fffad1";
                break;
            case 1:
                $bgColorBox = "#e3ffd7";
                break;
            case 2:
                $bgColorBox = "#eeeff9";
                break;
            default:
                $bgColorBox = "white";
        }
    ?>
        <div class="box-user-question" style="background-color:<?php echo $bgColorBox; ?>;" data-index="<?php echo $ques_counter; ?>">
            <h4>
                <b><?php echo $ques_counter . " - "; ?></b>
                <?php echo $ques['title_ques']; ?>
            </h4>
            <?php
            if ($pieces) {
                $ind_opt = 0;

                foreach ($pieces as $piece_opt) {
                    $opt_self_pieces = explode("*", $piece_opt);
                    $opt_txt = $opt_self_pieces[0];
                    $opt_score = $opt_self_pieces[1];
            ?>
                    <div class="box-user-options">
                        <input level-id="<?php echo $ques['level_term_id']; ?>" skill-id="<?php echo $ques['skill_term_id']; ?>" inp-index="<?php echo $ques_counter; ?>" class="user-option-radio option-input-quiwooc radio-quiwooc" type="radio" hash-ques="<?php echo $ques['ques_salt']; ?>" name="options[<?php echo $ques_counter; ?>]" value="<?php echo $opt_score; ?>" id="<?php echo $ind_opt . "_" . $ques['ques_salt']; ?>">
                        <label for="<?php echo $ind_opt . "_" . $ques['ques_salt']; ?>">
                            <?php echo $opt_txt; ?>
                        </label>
                    </div>
            <?php
                    $ind_opt++;
                }
            }
            ?>
        </div>

    <?php
        $ques_counter++;
    }

    ?>
    <center>
        <button type="button" id="go_next_segment" class="btn btn-filled" style="font-size: 18px;background: #2fa764;margin: 30px;border-radius: 30px;">مرحله بعد <i class="fa fa-arrow-left "></i></button>
    </center>
    <script>
        jQuery(document).ready(function($) {
            function request_quiz_questions_next(segment_request = 0, grade = 0, status_pass = "fail",
                level_term_id = 0, skill_term_id = 0, order_level = 0, order_skill = 0, current_segment_index = 0
            ) {
                var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
                var Quiz_Container = $('#Quiz_Container');
                var Loading_Container = $('#Loading_Container');
                $.ajax({
                    url: ajax_url,
                    type: "POST",
                    data: {
                        action: "utec_quiz_load_questions",
                        go_next_and_submit: 1,
                        segment_request: segment_request,
                        grade: grade,
                        status_pass: status_pass,
                        level_term_id: level_term_id,
                        skill_term_id: skill_term_id,
                        order_level: order_level,
                        order_skill: order_skill,
                        current_segment_index: current_segment_index
                    },
                    beforeSend: function() {
                        Quiz_Container.hide();
                        Loading_Container.show();
                        $('footer').hide();
                    },
                    complete: function(res) {
                        setTimeout(function() {
                            Quiz_Container.show("drop");
                            Loading_Container.hide();
                            Quiz_Container.html(res.responseText);
                        }, 1500);
                        setTimeout(function() {
                            $('footer').show();
                        }, 2500);
                    },
                    error: function(res) {
                        Quiz_Container.show();
                        Loading_Container.hide();
                        Quiz_Container.html(res.responseText);
                    }
                });
            }

            var min_grade_pass = parseFloat("<?php echo $min_grade_pass; ?>");
            var grading_method = ("<?php echo $grading_method; ?>");
            var level_term_id = parseInt("<?php echo $level_term_id; ?>");
            var skill_term_id = parseInt("<?php echo $skill_term_id; ?>");
            var order_level = parseInt("<?php echo $order_level; ?>");
            var order_skill = parseInt("<?php echo $order_skill; ?>");
            var current_segment_index = parseInt("<?php echo $current_segment_index; ?>");
            var number_of_ques_current_seg = parseInt("<?php echo $number_of_ques_current_seg; ?>");
            var segment_request = current_segment_index + 1;
            var grade = 0;
            var status_pass = "fail";
            $('.user-option-radio').change(function() {
                var sum_scores = 0;
                var number_anss = 0;
                var final_score = 0;

                var _score = $(this).val();
                var _all_seg_ques = $("input.user-option-radio");
                _all_seg_ques.each(function() {
                    if ($(this).prop("checked")) {
                        number_anss++;
                        sum_scores = sum_scores + parseInt($(this).val());
                    }
                });
                if (grading_method == "sum") {
                    final_score = sum_scores
                }
                if (grading_method == "avg") {
                    final_score = parseFloat((sum_scores) / (number_anss));
                }
                grade = final_score;
                if (grade >= min_grade_pass) {
                    status_pass = "success";
                } else {
                    status_pass = "fail";
                }
            })
            $('#go_next_segment').click(function() {
                var _all_seg_ques = $("input.user-option-radio");
                var number_anss_chk = 0;
                _all_seg_ques.each(function() {
                    if ($(this).prop("checked")) {
                        number_anss_chk++;
                    }
                });
                if (number_of_ques_current_seg != number_anss_chk) {
                    swal({
                        text: "پاسخ به تمام سوالات اجباری است !",
                        icon: "info",
                        button: "باشه",
                    });
                    return;
                }
                request_quiz_questions_next(
                    segment_request, grade, status_pass,
                    level_term_id, skill_term_id, order_level,
                    order_skill, current_segment_index
                );
            });
        })
    </script>
<?php
}
