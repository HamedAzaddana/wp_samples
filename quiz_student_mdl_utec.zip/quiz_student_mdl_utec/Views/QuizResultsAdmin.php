<h2>نتایج ثبت شده آزمون تعیین سطح</h2>
<br>
<input type="text" name="search_keyWord_customer" id="search_keyWord_customer" placeholder="کلمه کلیدی جستجو ..." id="">
<button id="search_keyWord_customer_action" style="background: #22b14a;border-color: #22b14a;" type="button" class="button button-primary button-large">
    <i class="fa fa-search"></i>
</button>
<br><br>
<div id="utec_customers_container" style="margin: 10px;">
</div>
<script>
    jQuery(document).ready(function($) {
        //Get Results Func
        function GetResults(KeyWord = '', paged_num = 1) {
            var utec_customers_container = $('#utec_customers_container');
            $.ajax({
                url: <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>,
                type: "POST",
                data: {
                    action: "utec_quiz_get_user_results",
                    KeyWord: KeyWord,
                    paged_num: paged_num
                },
                beforeSend: function() {
                    utec_customers_container.html("<center><i style='font-size:31px' class='fa fa-2x fa-spin fa-spinner'></i> &nbsp;<span style='font-size:24px'>در حال دریافت اطلاعات ...</span></center>");
                },
                complete: function(res) {
                    utec_customers_container.html(res.responseText);
                },
                error: function(res) {
                    utec_customers_container.html(res.responseText);
                }
            });
        }
        GetResults();
        $('#search_keyWord_customer_action').on('click', function() {
            var kword = $('#search_keyWord_customer').val();
            GetResults(kword);
        });
        $('#search_keyWord_customer').keypress(function(e) {
            var key = e.which;
            if (key == 13) // the enter key code
            {
                $('#search_keyWord_customer_action').click();
                return false;
            }
        });
    });
</script>