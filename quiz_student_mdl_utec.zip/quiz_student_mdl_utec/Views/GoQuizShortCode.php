<?php

if (is_user_logged_in()) {
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $username = $user->data->user_login;
    global $wpdb;
    $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
    $usr_id = get_current_user_id();
    $quiz_results = $wpdb->get_results("SELECT * FROM `$tbl_result` WHERE `user_id` = '$usr_id' order by `date` desc");
    $count_quiz_results = count($quiz_results);
    $number_of_max_go_quiz_valid = intval(get_option("number_of_max_go_quiz_valid", 1));
    if ($count_quiz_results >= $number_of_max_go_quiz_valid) {
       ?>
       <script>
           window.location.replace("<?php echo site_url(); ?>");
       </script>
       <?php
    }
    $salt_nonce_go_quiz = "user_gonna_go_quiz" . $username . "*(E@Eh38*38r";
    $is_verify_nonce = wp_verify_nonce($_POST['Go_Quiz_PlaceMent'], $salt_nonce_go_quiz);
    $utec_before_quiz_description = "";
    if (get_option("utec_before_quiz_description", "")) {
        $utec_before_quiz_description = stripslashes(urldecode(get_option("utec_before_quiz_description", "")));
    }
    $utec_begin_quiz_alert = "";
    if (get_option("utec_begin_quiz_alert", "")) {
        $utec_begin_quiz_alert = stripslashes(urldecode(get_option("utec_begin_quiz_alert", "")));
    }
    if (($_SERVER['REQUEST_METHOD'] !== 'POST') || !$is_verify_nonce) {
?>
        <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
            <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> صفحه را بسته و مجدد دکمه شرکت در آزمون را بزنید !
        </div>
        <?php
    } else {

        if (isset($_POST['show_before_desc'])) {
            $salt_nonce_go_quiz = "user_gonna_go_quiz" . $username . "*(E@Eh38*38r";
        ?>
            <h2>
                توضیحات قبل شروع آزمون
            </h2>
            <br>
            <div>
                <?php echo $utec_before_quiz_description; ?>
            </div>
            <br>
            <form action="<?php echo site_url(); ?>/quiz_do" method="POST">
                <input type="hidden" name="start_now_quiz" value="1">
                <?php wp_nonce_field($salt_nonce_go_quiz, 'Go_Quiz_PlaceMent'); ?>

                <button class="button-82-pushable" role="button" type="submit">
                    <span class="button-82-shadow"></span>
                    <span style="background: hsl(129.6, 50.2%, 46.5%);" class="button-82-edge"></span>
                    <span style="background: hsl(129.6, 50.2%, 46.5%);" class="button-82-front text">
                        شروع می کنم! <i class="fa fa-reply-all "></i>
                    </span>
                </button>
            </form>

        <?php
        }
        if (isset($_POST['start_now_quiz'])) {
        ?>
            <!-- start quiz  -->
            <div id="alert_swal_content" style="display: none;">
                <?php echo $utec_begin_quiz_alert; ?>
            </div>
            <div class="row UtecALertsQuiz">
                <div style="padding: 10px;">
                    <span class="utec-alert-quiz-1">بعد از فشردن دکمه مرحله بعد، امکان بازگشت به مرحله قبل را ندارید !</span>
                </div>
                <div>
                    <button type="button" id="utec_cancel_btn_quiz" class="btn btn-filled utec_cancel_btn_quiz">لغو شرکت در آزمون <i class="fa fa-arrow-right"></i></button>
                </div>
            </div>
            <br>
            <div id="Quiz_Container">
            </div>
            <center>
                <div id="Loading_Container" class="Utec_Loading_Container">
                    <div class='container'>
                        <div class='loader'>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--text'></div>
                        </div>
                    </div>
                    <span style="font-size: 20px;font-weight: bold;">
                        در حال بارگذاری سوالات...
                    </span>
                </div>
            </center>
            <center style="display: none;" id="Loading_Container_redirect">
                <div class="Utec_Loading_Container">
                    <div class='container'>
                        <div class='loader'>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--dot'></div>
                            <div class='loader--text'></div>
                        </div>
                    </div>
                    <span style="font-size: 20px;font-weight: bold;">
                        در حال هدایت به صفحه آزمون های تعیین سطح ...
                    </span>
                </div>
            </center>
            <script>
                jQuery(document).ready(function($) {
                    $('footer').hide();
                    $('.page-title').hide();
                    var Quiz_Container = $('#Quiz_Container');
                    var Loading_Container = $('#Loading_Container');
                    var Loading_Container_Html_Redirect = $('#Loading_Container_redirect').html();
                    var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;

                    function request_quiz_questions(segment_request = 0) {
                        var ajax_url = <?php echo "\"" . admin_url('admin-ajax.php') . "\""; ?>;
                        var Quiz_Container = $('#Quiz_Container');
                        var Loading_Container = $('#Loading_Container');

                        $.ajax({
                            url: ajax_url,
                            type: "POST",
                            data: {
                                action: "utec_quiz_load_questions",
                                segment_request: segment_request,
                            },
                            beforeSend: function() {
                                Quiz_Container.hide();
                                Loading_Container.show();

                            },
                            complete: function(res) {
                                setTimeout(function() {
                                    Quiz_Container.show("drop");
                                    Loading_Container.hide();
                                    Quiz_Container.html(res.responseText);
                                }, 1500);
                                setTimeout(function() {
                                    $('footer').show();
                                }, 2500);
                            },
                            error: function(res) {
                                Quiz_Container.html(res.responseText);
                            }
                        });
                    }
                    $('.main-page-content.default-margin').css({
                        'padding-bottom': '0',
                    })
                    var swal_div_content = $('#alert_swal_content').html()
                    var utec_alert_quiz = document.createElement("div");
                    utec_alert_quiz.innerHTML = swal_div_content;

                    var utec_redirect_content = document.createElement("div");
                    utec_redirect_content.innerHTML = Loading_Container_Html_Redirect;
                    swal({
                        content: utec_alert_quiz,
                        icon: "info",
                        button: "باشه",
                        closeOnClickOutside: false,
                    });
                    $('#utec_cancel_btn_quiz').click(function() {
                        swal({
                                title: "آیا برای لغو آزمون مطمئنید ؟",
                                text: "با این کار، پاسخ های شما ذخیره نخواهند شد !",
                                icon: "warning",
                                buttons: {
                                    continue: {
                                        text: "ادامه آزمون",
                                        value: "continue",
                                    },
                                    confirm: {
                                        text: "لغو آزمون",
                                        value: "confirm",
                                    },
                                },
                                dangerMode: true,
                            })
                            .then((value) => {
                                if (value == "confirm") {
                                    $.ajax({
                                        url: ajax_url,
                                        type: "POST",
                                        data: {
                                            action: "utec_quiz_cancel_quiz",
                                        },
                                        beforeSend: function() {

                                            swal({
                                                content: utec_redirect_content,
                                                icon: "info",
                                                button: false,
                                                closeOnClickOutside: false,
                                            });
                                        },
                                        complete: function(res) {
                                            setTimeout(function() {
                                                window.location.replace("<?php echo site_url(); ?>/quiz_placement");
                                            }, 1100);
                                        },
                                        error: function(res) {

                                        }
                                    });
                                }
                            });
                    });
                    request_quiz_questions(0);
                });
            </script>
    <?php
        }
    }
    ?>
<?php
} else {
?>
    <div class="msg-quiwooc" style="font-size:17px;border-radius:40px;background-color: #1206068c;color: #fff;line-height: 1.5;list-style-type: none;position: relative;margin-bottom: 30px;padding: 20px" role="alert">
        <i class="fa fa-window-close remove-msg-quiwooc" style="font-size: 22px;padding:5px;cursor:pointer;"></i> باید ابتدا وارد شوید !
    </div>
<?php
}
?>