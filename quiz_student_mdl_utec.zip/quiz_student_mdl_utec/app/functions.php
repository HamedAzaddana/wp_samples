<?php

function utec_quiz_view($path, $params = [])
{

    if ($params && is_array($params)) {
        extract($params);
    }

    include(utec_quiz_views_path . "{$path}" . ".php");
}
function utec_quiz_get_view($path, $params = [])
{
    ob_start();
    if ($params && is_array($params)) {
        extract($params);
    }

    include(utec_quiz_views_path . "{$path}" . ".php");
    $contentHtml = ob_get_contents();
    ob_end_clean();
    return $contentHtml;
}
function utec_quiz_make_hash()
{
    $str = time() . "_" . bin2hex(random_bytes(20));
    return $str;
}

function utec_quiz_is_answers_exist_temp()
{
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $user_login = $user->data->user_login;
    $val = $user_login . "IOWIOfffj!)*63jdun" . $user_login;
    $file_name = base64_encode($val);
    $path = utec_quiz_temp_path . "$file_name";
    return file_exists($path);
}
function utec_quiz_delete_answers_temp()
{
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $user_login = $user->data->user_login;
    $val = $user_login . "IOWIOfffj!)*63jdun" . $user_login;
    $file_name = base64_encode($val);
    $path = utec_quiz_temp_path . "$file_name";
    if (file_exists($path)) {
        unlink($path);
    }
}

function utec_quiz_set_answers_temp($answers_skill_array)
{
    $result = [];
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $user_login = $user->data->user_login;

    $val = $user_login . "IOWIOfffj!)*63jdun" . $user_login;
    $file_name = base64_encode($val);
    $path = utec_quiz_temp_path . "$file_name";

    if (file_exists($path)) {
        if (file_get_contents($path)) {
            $last_answers_array = utec_quiz_get_answers_temp();
            $last_answers_array[] = $answers_skill_array;
            $result =  ($last_answers_array);
        }
    } else {
        $result[] =  $answers_skill_array;
    }
    $result_str = base64_encode(serialize($result));
    $content = "";
    $fp = fopen($path, "wb");
    fwrite($fp, $content);
    fclose($fp);
    file_put_contents($path, $result_str);
}

function utec_quiz_get_answers_temp()
{
    $result = [];
    $user = wp_get_current_user();
    $user_id = intval($user->data->ID);
    $user_login = $user->data->user_login;

    $val = $user_login . "IOWIOfffj!)*63jdun" . $user_login;
    $file_name = base64_encode($val);
    $path = utec_quiz_temp_path . "$file_name";
    $results = [];
    if (file_exists($path)) {
        if (file_get_contents($path)) {
            $decode1 = base64_decode(file_get_contents($path));
            $results = unserialize($decode1);
        }
    }
    return $results;
}
function utec_quiz_load_tinyMceSettingsJs($editor_class)
{
?>
    <script>
        tinymce.remove('.<?php echo $editor_class; ?>');
        setInterval(function() {
            tinyMCE.init({
                selector: '.<?php echo $editor_class; ?>',
                toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
                plugins: "charmap,colorpicker,hr,lists,paste,tabfocus,textcolor,fullscreen,wordpress,wpautoresize,wpeditimage,wpemoji,wpgallery,wpdialogs,wptextpattern,wpview,directionality",
                theme: "modern",
                skin: "lightgray",
                language: "fa",
                formats: {
                    alignleft: [{
                        selector: "p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li",
                        styles: {
                            textAlign: "left"
                        }
                    }, {
                        selector: "img,table,dl.wp-caption",
                        classes: "alignleft"
                    }],
                    aligncenter: [{
                        selector: "p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li",
                        styles: {
                            textAlign: "center"
                        }
                    }, {
                        selector: "img,table,dl.wp-caption",
                        classes: "aligncenter"
                    }],
                    alignright: [{
                        selector: "p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li",
                        styles: {
                            textAlign: "right"
                        }
                    }, {
                        selector: "img,table,dl.wp-caption",
                        classes: "alignright"
                    }],
                    strikethrough: {
                        inline: "del"
                    }
                },
                relative_urls: false,
                remove_script_host: false,
                convert_urls: false,
                browser_spellcheck: true,
                fix_list_elements: true,
                entities: "38,amp,60,lt,62,gt",
                entity_encoding: "raw",
                keep_styles: false,
                cache_suffix: "wp-mce-4940-20190515",
                resize: false,
                menubar: false,
                branding: false,

                preview_styles: "font-family font-size font-weight font-style text-decoration text-transform",
                end_container_on_empty_block: true,
                wpeditimage_html5_captions: true,
                wp_lang_attr: "fa-IR",
                wp_keep_scroll_position: true,
                wp_shortcut_labels: {
                    "Heading 1": "access1",
                    "Heading 2": "access2",
                    "Heading 3": "access3",
                    "Heading 4": "access4",
                    "Heading 5": "access5",
                    "Heading 6": "access6",
                    "Paragraph": "access7",
                    "Blockquote": "accessQ",
                    "Underline": "metaU",
                    "Strikethrough": "accessD",
                    "Bold": "metaB",
                    "Italic": "metaI",
                    "Code": "accessX",
                    "Align center": "accessC",
                    "Align right": "accessR",
                    "Align left": "accessL",
                    "Justify": "accessJ",
                    "Cut": "metaX",
                    "Copy": "metaC",
                    "Paste": "metaV",
                    "Select all": "metaA",
                    "Undo": "metaZ",
                    "Redo": "metaY",
                    "Bullet list": "accessU",
                    "Numbered list": "accessO",
                    "Insert\/edit image": "accessM",
                    "Insert\/edit link": "metaK",
                    "Remove link": "accessS",
                    "Toolbar Toggle": "accessZ",
                    "Insert Read More tag": "accessT",
                    "Insert Page Break tag": "accessP",
                    "Distraction-free writing mode": "accessW",
                    "Add Media": "accessM",
                    "Keyboard Shortcuts": "accessH"
                },
                content_css: "<?php echo get_site_url(); ?>/wp-includes/css/dashicons.min.css?ver=5.2.14,<?php echo get_site_url(); ?>/wp-includes/js/tinymce/skins/wordpress/wp-content.css?ver=5.2.14,<?php echo get_site_url(); ?>/wp-content/plugins/wp-jalali/assets/css/wysiwyg.css,<?php echo get_site_url(); ?>/wp-content/plugins/wp-jalali/assets/css/wysiwyg-rtl.css",
                external_plugins: {
                    "msp_shortcodes_button": <?php echo json_encode(get_site_url() . "/wp-content/plugins/master-slider/admin/assets/js/mce-plugin.js"); ?>
                },
                wpautop: true,
                indent: false,
                toolbar1: "formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,wp_more,spellchecker,wp_adv,dfw,|,msp_shortcodes_button,ltr",
                toolbar2: "strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help",
                toolbar3: "",
                toolbar4: "",
                tabfocus_elements: "content-html,save-post",

                body_class: "content post-type-quiz_sectionary post-status-publish page-template-default locale-fa-ir",
                wp_autoresize_on: true,
                add_unload_trigger: false,
                directionality: "rtl",
                rtl_ui: true


            });
        }, 1000);
    </script>
<?php
}
