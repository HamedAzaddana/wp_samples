<?php

namespace Utec\Quiz\Controllers;

class MenuWoocQuiz
{

    public function __construct()
    {
        add_filter('woocommerce_account_menu_items', array($this, 'utec_quiz_add_my_quiz'));
        add_filter('woocommerce_get_endpoint_url', array($this, 'utec_quiz_my_quiz_hook_endpt'), 10, 4);
    }
    public function utec_quiz_add_my_quiz($menu_links)
    {
        // we will hook "womanide-forum" later
        $new = array('my_quizes_acc' => 'آزمون تعیین سطح');

        // or in case you need 2 links
        // $new = array( 'link1' => 'Link 1', 'link2' => 'Link 2' );

        // array_slice() is good when you want to add an element between the other ones
        $menu_links = array_slice($menu_links, 0, 1, true)
            + $new
            + array_slice($menu_links, 1, NULL, true);


        return $menu_links;
    }
    public function utec_quiz_my_quiz_hook_endpt($url, $endpoint, $value, $permalink)
    {
        if ($endpoint === 'my_quizes_acc') {

            // This is where you add the custom URL, it could be external like, in this case, we need to go to my profile on the bbpress froum
            // I will use this function (bp_core_get_username( bp_loggedin_user_id() );) to get my profile user id and add it to the URL as shown below 

            $url = site_url() . "/quiz_placement/";
        }
        return $url;
    }
}
