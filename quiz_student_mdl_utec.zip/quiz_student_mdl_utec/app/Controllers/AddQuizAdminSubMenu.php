<?php

namespace Utec\Quiz\Controllers;

class AddQuizAdminSubMenu
{
    public function __construct()
    {
        add_action('admin_menu', array($this, 'utec_quiz_add_submenu_admin'));
        add_action('admin_menu', array($this, 'utec_quiz_add_submenu_admin_results'), 100);
    }
    public function utec_quiz_add_submenu_admin_results()
    {
        add_submenu_page(
            'edit.php?post_type=product',
            __('نتایج تعیین سطح'),
            __('نتایج تعیین سطح'),
            'manage_options', // Required user capability
            'utec-quiz-placement-results',
            array($this, 'utec_quiz_add_submenu_quiz_results'),
        );
    }
    public function utec_quiz_add_submenu_admin()
    {
        add_menu_page(
            "آزمون تعیین سطح",
            "آزمون تعیین سطح",
            'manage_options',
            'utec_quiz_settings',
            array($this, 'utec_quiz_add_submenu_admin_load'),
            "dashicons-welcome-learn-more",
            6
        );
    }
    public function utec_quiz_add_submenu_admin_load()
    {
        utec_quiz_view("QuizMenuSettings");
    }
    public function utec_quiz_add_submenu_quiz_results()
    {
        utec_quiz_view("QuizResultsAdmin");
    }
}
