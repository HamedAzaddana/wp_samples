<?php

namespace Utec\Quiz\Controllers;

use Utec\Quiz\Controllers\Activate as ActivateUtecQuiz;
use Utec\Quiz\Controllers\Enqueue as EnqueueUtecQuiz;
use Utec\Quiz\Controllers\AddQuizAdminSubMenu;
use Utec\Quiz\Controllers\MenuWoocQuiz;
use Utec\Quiz\Controllers\Session_repository;

use Utec\Quiz\ShortCodes\UtecMyQuizesShortCode;
use Utec\Quiz\ShortCodes\UtecDoQuizShortCode;
use Utec\Quiz\ShortCodes\UtecQuizeResultShortCode;

use Utec\Quiz\Controllers\AjaxQuizSetting\AddQuestionAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\ShowQuestionAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\OperationLevelResultAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\ShowLevelResultAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\OperationQuestionAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\OperationSkillResultAjax;
use Utec\Quiz\Controllers\AjaxQuizSetting\SetSettingsLevelAjax;
use Utec\Quiz\Controllers\AjaxQuizUser\LoadQuizAjax;
use Utec\Quiz\Controllers\AjaxQuizUser\EndQuizAjax;
use Utec\Quiz\Controllers\AjaxQuizResults\GetGradesAjax;
use Utec\Quiz\Controllers\AjaxQuizResults\GetUsersAjax;

class UtecQuizLoader
{

    public function initiate()
    {
        $this->AjaxUserLoader();
        $this->AjaxAdminLoader();
        $this->ShortCodeLoader();
        $this->ControllerRunner();
        $this->ActicateRunner();
    }

    public function ActicateRunner()
    {

        $ActivateUtecQuiz = new ActivateUtecQuiz();
    }

    public function AjaxAdminLoader()
    {
        $GetUsersAjax = new GetUsersAjax();
        $GetGradesAjax = new GetGradesAjax();
        $SetSettingsLevelAjax = new SetSettingsLevelAjax();
        $OperationQuestionAjax = new OperationQuestionAjax();
        $OperationSkillResultAjax = new OperationSkillResultAjax();
        $OperationLevelResultAjax = new OperationLevelResultAjax();
        $AddQuestionAjax = new AddQuestionAjax();
        $ShowQuestionAjax = new ShowQuestionAjax();
        $ShowLevelResultAjax = new ShowLevelResultAjax();
    }
    public function AjaxUserLoader()
    {
        $LoadQuizAjax = new LoadQuizAjax();
        $EndQuizAjax = new EndQuizAjax();
    }
    public function ShortCodeLoader()
    {
        $UtecMyQuizesShortCode = new UtecMyQuizesShortCode();
        $UtecDoQuizShortCode = new UtecDoQuizShortCode();
        $UtecQuizeResultShortCode = new UtecQuizeResultShortCode();
    }
    public function ControllerRunner()
    {
        Session_repository::RemoveCheck();
        $EnqueueUtecQuiz = new EnqueueUtecQuiz();
        $MenuWoocQuiz = new MenuWoocQuiz();
        if (is_admin()) {
            $AddQuizAdminSubMenu = new AddQuizAdminSubMenu();
        }
    }
}
