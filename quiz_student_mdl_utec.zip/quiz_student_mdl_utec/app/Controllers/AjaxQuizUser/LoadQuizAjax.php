<?php

namespace Utec\Quiz\Controllers\AjaxQuizUser;

class LoadQuizAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_load_questions',  array($this, 'utec_quiz_load_questions'));
        add_action('wp_ajax_nopriv_utec_quiz_load_questions',  array($this, 'utec_quiz_load_questions'));
    }
    public function utec_quiz_load_questions()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST') || !is_user_logged_in()) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        $current_questions_segment = [];
        $question_segments = $this->get_questions_in_order();
        $number_of_segments = count($question_segments);
        $numberOfLevels = $this->number_of_prod_cates();
        $numberOfSkills = $this->number_of_skills();
        $LevelsInOrder = $this->get_levels_in_order();

        $current_segment_index = 0;
        $segment_request = intval($_POST['segment_request']);
        $go_next_and_submit = intval($_POST['go_next_and_submit']);
        //fetch first segment
        $first_segment = $question_segments[0];
        $first_segment_level_id = $first_segment['level_id'];
        $first_segment_skill_id = $first_segment['skill_id'];
        $first_segment_order_level = $first_segment['order_level'];
        $first_segment_order_skill = $first_segment['order_skill'];

        if ($segment_request == 0) {
            $current_segment_index =  $segment_request;
            $current_questions_segment = $question_segments[$segment_request];
            utec_quiz_delete_answers_temp();
            utec_quiz_view('AjaxQuizUser/LoadQuizView', compact("current_segment_index", "current_questions_segment", "number_of_segments"));
        }
        if ($go_next_and_submit == 1) {
            $grade = floatval($_POST['grade']);
            $status_pass = ($_POST['status_pass']);
            $level_term_id = intval($_POST['level_term_id']);
            $skill_term_id = intval($_POST['skill_term_id']);
            $order_level = intval($_POST['order_level']);
            $order_skill = intval($_POST['order_skill']);
            $current_segment_index = intval($_POST['current_segment_index']);
            $answers_skill_array = [
                "grade" => $grade,
                "status_pass" => $status_pass,
                "level_term_id" => $level_term_id,
                "skill_term_id" => $skill_term_id,
                "order_level" => $order_level,
                "order_skill" => $order_skill,
                "segment_index" => $current_segment_index,
            ];
            //save answers
            utec_quiz_set_answers_temp($answers_skill_array);
            //check next segment
            $answers_already_array = utec_quiz_get_answers_temp();
            if ($answers_already_array) {
                foreach ($answers_already_array as $key_ans => $ans_item) {
                    LoopBegin:
                    $key_ans = 0;
                    $current_segment_index =  $segment_request;
                    $current_questions_segment = $question_segments[$segment_request];
                    $request_level_id = $current_questions_segment['level_id'];
                    $request_skill_id = $current_questions_segment['skill_id'];
                    $request_order_level = $current_questions_segment['order_level'];
                    $request_order_skill = $current_questions_segment['order_skill'];
                    if ($segment_request >= $number_of_segments) {
                        utec_quiz_view('AjaxQuizUser/EndQuizView');
                        wp_die();
                    }
                    if (
                        $first_segment_level_id  == $request_level_id
                    ) {
                        utec_quiz_view('AjaxQuizUser/LoadQuizView', compact("current_segment_index", "current_questions_segment", "number_of_segments"));
                        wp_die();
                    } else {
                        LoopBeginInner:
                        $prev_level_id = $this->get_prev_level_id($request_level_id);
                        $ans = $answers_already_array[$key_ans];
                        if (!$ans) {
                            $segment_request++;
                            goto LoopBegin;
                        }
                        $status_seg_pass_ans = $ans['status_pass'];
                        $level_seg_term_id_ans = $ans['level_term_id'];
                        $skill_seg_term_id_ans = $ans['skill_term_id'];
                        $order_level_ans = $ans['order_level'];
                        $order_skill_ans = $ans['order_skill'];
                        $segment_index_ans = $ans['segment_index'];
                        if (
                            $prev_level_id == $level_seg_term_id_ans
                            &&  $request_skill_id == $skill_seg_term_id_ans
                        ) {
                            if ($ans && $status_seg_pass_ans && $status_seg_pass_ans == "success") {
                                utec_quiz_view('AjaxQuizUser/LoadQuizView', compact("current_segment_index", "current_questions_segment", "number_of_segments"));
                                wp_die();
                            } else {
                                $segment_request++;
                                goto LoopBegin;
                            }
                        } else {
                            $key_ans++;
                            goto LoopBeginInner;
                        }
                    }
                }
            } else {
                wp_die("<strong>خطا :</strong>" . "مشکلی در سرور پیش آمده است !");
            }
        }
        wp_die();
    }
    private function get_questions_in_order()
    {
        $questions_all = get_option('utec_quiz_questions_all') ? unserialize((get_option('utec_quiz_questions_all'))) : [];
        $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
        $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
        $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');
        $args_query_prod_cate = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );
        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_cates_all = get_terms($args_query_prod_cate);
        $product_cates = [];
        foreach ($product_cates_all as $cate) {
            if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                $key_settings = "settings_level_" . $cate->term_id;
                foreach ($utec_settings_quiz as $k => $usq) {
                    if ($key_settings == $k) {
                        $cate->is_shuffle = $usq['shuffle_questions'];
                        $cate->grading_skill = $usq['grading_skill'];
                        $cate->order_level_show = $usq['order_level_show'];
                        $cate->shuffle_questions = $usq['shuffle_questions'];
                    }
                }
                $product_cates[] = $cate;
            }
        }
        usort($product_cates, function ($first, $second) {
            return intval($first->order_level_show) > intval($second->order_level_show);
        });
        $questions_all_quiz = [];
        foreach ($questions_all as $ques) {
            foreach ($product_cates as $cate) {
                $cate_term_id = $cate->term_id;
                $skill_settings = $cate->grading_skill;
                $order_level = $cate->order_level_show;
                $is_shuffle_level = $cate->shuffle_questions;

                if ($ques['level_term_id'] == $cate_term_id) {
                    $questions_all_quiz["level-" . $ques['level_term_id']]['order_level'] = $order_level;
                }
                foreach ($skill_settings as $skill_setting) {
                    $skill_id = $skill_setting['skill_id'];
                    $order_skill = $skill_setting['order_skill_in_level'];
                    $min_grade = $skill_setting['min_grade'];
                    $method_grading = $skill_setting['method_grading'];

                    if (
                        $ques['skill_term_id'] == $skill_id
                        && $ques['level_term_id'] == $cate_term_id
                    ) {
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['skill_id'] = $skill_id;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['level_id'] = $cate_term_id;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['order_skill'] = $order_skill;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['order_level'] = $order_level;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['is_shuffle_level'] = $is_shuffle_level;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['min_grade'] = $min_grade;
                        $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']]['method_grading'] = $method_grading;
                    }
                }
            }
            $questions_all_quiz["level-" . $ques['level_term_id']]["skill-" . $ques['skill_term_id']][] = $ques;
        }
        $segment_skill_questions = [];
        foreach ($questions_all_quiz as $kq => $item) {

            if (is_array($item)) {
                foreach ($item as $kqs => $sub_item) {
                    if (strpos($kqs, "skill-") !== false) {
                        $segment_skill_questions[] = $sub_item;
                    }
                }
            }
        }
        usort($segment_skill_questions, function ($first, $second) {
            return intval($first['order_skill']) > intval($second['order_skill']);
        });
        // shuffle($segment_skill_questions);
        usort($segment_skill_questions, function ($first, $second) {
            return intval($first['order_level']) > intval($second['order_level']);
        });
        return $segment_skill_questions;
    }
    private function number_of_prod_cates()
    {
        $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
        $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');
        $args_query_prod_cate = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );

        $product_cates_all = get_terms($args_query_prod_cate);
        $product_cates = [];
        foreach ($product_cates_all as $cate) {
            if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                $product_cates[] = $cate;
            }
        }
        return count($product_cates);
    }
    public function get_levels_in_order()
    {
        $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
        $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');
        $args_query_prod_cate = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );
        $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
        $product_cates_all = get_terms($args_query_prod_cate);
        $product_cates = [];
        foreach ($product_cates_all as $cate) {
            if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                $key_settings = "settings_level_" . $cate->term_id;
                foreach ($utec_settings_quiz as $k => $usq) {
                    if ($key_settings == $k) {

                        $cate->is_shuffle = $usq['shuffle_questions'];
                        $cate->grading_skill = $usq['grading_skill'];
                        $cate->order_level_show = $usq['order_level_show'];
                        $cate->shuffle_questions = $usq['shuffle_questions'];
                    }
                }
                $product_cates[] = $cate;
            }
        }

        usort($product_cates, function ($first, $second) {
            return intval($first->order_level_show) > intval($second->order_level_show);
        });
        return $product_cates;
    }
    public function get_prev_level_id($req_level_id)
    {
        $LevelsInOrder = $this->get_levels_in_order();
        $current_index = 0;
        foreach ($LevelsInOrder as $key => $levelOrdered) {
            $level_id = $levelOrdered->term_id;
            if ($level_id == $req_level_id) {
                $current_index = $key;
            }
        }
        $prev_index = $current_index - 1;
        $prev_level_id = $LevelsInOrder[$prev_index]->term_id;
        return $prev_level_id;
    }
    private function number_of_skills()
    {

        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_skills = get_terms($args_query_prod_skill);
        return count($product_skills);
    }
}
