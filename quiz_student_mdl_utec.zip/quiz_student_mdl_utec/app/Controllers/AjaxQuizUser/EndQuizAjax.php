<?php

namespace Utec\Quiz\Controllers\AjaxQuizUser;

class EndQuizAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_end_quiz_show_result',  array($this, 'utec_quiz_end_quiz_show_result'));
        add_action('wp_ajax_nopriv_utec_quiz_end_quiz_show_result',  array($this, 'utec_quiz_end_quiz_show_result'));

        add_action('wp_ajax_utec_quiz_cancel_quiz',  array($this, 'utec_quiz_cancel_quiz'));
        add_action('wp_ajax_nopriv_utec_quiz_cancel_quiz',  array($this, 'utec_quiz_cancel_quiz'));
    }
    public function utec_quiz_cancel_quiz()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST') || !is_user_logged_in()) {
            wp_die("<strong>خطا :</strong>" . "خطایی رخ داد !");
        }
        utec_quiz_delete_answers_temp();
        wp_die();
    }
    public function utec_quiz_end_quiz_show_result()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST') || !is_user_logged_in()) {
            wp_die("<strong>خطا :</strong>" . "خطایی رخ داد !");
        }
        date_default_timezone_set('Asia/Tehran');
        $user = wp_get_current_user();
        $user_id = intval($user->data->ID);
        $username = $user->data->user_login;
        $salt_nonce_end_quiz = "user_gonna_end_quiz" . $username . "QPPOEJf*@73jfMnxc";
        $is_verify_nonce = wp_verify_nonce($_POST['Quiz_Submission_Token'], $salt_nonce_end_quiz);
        if (!$is_verify_nonce) {
            wp_die("<strong>خطا :</strong>" . "خطای عدم اعتبار داده ها !");
        }
        $answers_array = utec_quiz_get_answers_temp();
        $result_hash = "";
        if ($answers_array) {
            $result_hash = base64_encode(serialize($answers_array));
        }
        //save results
        global $wpdb;
        $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
        $wpdb->insert("$tbl_result", array(
            "user_id" => get_current_user_id(),
            "results" => $result_hash,
            "date" => date("Y-m-d H:i:s")
        ));
        $result_id = $wpdb->insert_id;
        $result_id_encode = base64_encode($result_id);
        $url_redirect = site_url() . "/quiz_result/?End=1&code=" . $result_id_encode;
        // utec_quiz_delete_answers_temp();
        wp_die($url_redirect);
    }
}
