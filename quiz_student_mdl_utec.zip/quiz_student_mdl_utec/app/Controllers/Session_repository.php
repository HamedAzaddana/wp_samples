<?php

namespace Utec\Quiz\Controllers;

class Session_repository
{
    public static function RemoveCheck()
    {
        date_default_timezone_set('Asia/Tehran');
        $now_tmp = intval(time());
        $dir = utec_quiz_temp_path;
        if (is_dir($dir)) {
            $files = scandir($dir, 0);
            for ($i = 2; $i < count($files); $i++) {
                if ("index.php" != $files[$i]) {
                    $file_path = utec_quiz_temp_path . $files[$i];
                    if (is_file($file_path)) {
                        $mod_time_tmp = intval(filemtime($file_path));
                        $distance_minute = (($now_tmp) - ($mod_time_tmp)) / (60);
                        if ($distance_minute > 60) {
                            unlink($file_path);
                        }
                    }
                }
            }
        }
    }
}
