<?php

namespace Utec\Quiz\Controllers\AjaxQuizSetting;

class ShowLevelResultAjax
{
    public function __construct()
    {
       
    }
}