<?php

namespace Utec\Quiz\Controllers\AjaxQuizSetting;

class SetSettingsLevelAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_set_level_settings',  array($this, 'utec_quiz_set_level_settings'));
        add_action('wp_ajax_nopriv_utec_quiz_set_level_settings',  array($this, 'utec_quiz_set_level_settings'));

        add_action('wp_ajax_utec_quiz_set_overall_settings',  array($this, 'utec_quiz_set_overall_settings'));
        add_action('wp_ajax_nopriv_utec_quiz_set_overall_settings',  array($this, 'utec_quiz_set_overall_settings'));
    }
    public function utec_quiz_set_level_settings()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به تنظیمات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "به تنظیمات دسترسی ندارید !");
        }
        $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $method_grading_level = (sanitize_text_field($_POST['method_grading_level']));
        $order_level_show = intval(sanitize_text_field($_POST['order_level_show']));
        $shuffle_questions = intval(sanitize_text_field($_POST['shuffle_questions']));
        $min_grade_skill_str = (sanitize_text_field($_POST['min_grade_skill_str']));
        $method_grading_skill_str = (sanitize_text_field($_POST['method_grading_skill_str']));
        $order_skill_in_level_str = (sanitize_text_field($_POST['order_skill_in_level_str']));
        $min_grade_skill_array = [];
        $order_skill_in_level_array = [];
        $grading_skill_array = [];
        $order_skill_in_level_pieces = [];
        if ($order_skill_in_level_str) {
            $order_skill_in_level_pieces = explode("@", $order_skill_in_level_str);
            $order_skill_in_level_pieces = array_filter($order_skill_in_level_pieces, function ($var) {
                return $var;
            });
        }
        $min_grade_skill_pieces = [];
        if ($min_grade_skill_str) {
            $min_grade_skill_pieces = explode("@", $min_grade_skill_str);
            $min_grade_skill_pieces = array_filter($min_grade_skill_pieces, function ($var) {
                return $var;
            });
        }
        $method_grading_skill_pieces = [];
        if ($method_grading_skill_str) {
            $method_grading_skill_pieces = explode("@", $method_grading_skill_str);
            $method_grading_skill_pieces = array_filter($method_grading_skill_pieces, function ($var) {
                return $var;
            });
        }
        foreach ($min_grade_skill_pieces as $mgsp) {
            $mgsp2 = explode("_", $mgsp);
            $piece_elem = [];
            $piece_elem['skill_id'] = intval($mgsp2[0]);
            $piece_elem['min_grade'] = floatval($mgsp2[1]);
            $min_grade_skill_array[] = $piece_elem;
        }
        foreach ($order_skill_in_level_pieces as $oslp) {
            $oslp2 = explode("_", $oslp);
            $piece_elem = [];
            $piece_elem['skill_id'] = intval($oslp2[0]);
            $piece_elem['order_skill_in_level'] = floatval($oslp2[1]);
            $order_skill_in_level_array[] = $piece_elem;
        }
        foreach ($method_grading_skill_pieces as $mgp) {
            $mgp2 = explode("_", $mgp);
            $piece_elem = [];
            $piece_elem['skill_id'] = intval($mgp2[0]);
            $piece_elem['method_grading'] = ($mgp2[1]);
            foreach ($min_grade_skill_array as $mgspn) {
                if ($mgspn['skill_id'] == $piece_elem['skill_id']) {
                    $min_grade =  $mgspn["min_grade"];
                    $piece_elem['min_grade'] = $min_grade;
                }
            }
            foreach ($order_skill_in_level_array as $oslpn) {
                if ($oslpn['skill_id'] == $piece_elem['skill_id']) {
                    $order_skill_in_level =  $oslpn["order_skill_in_level"];
                    $piece_elem['order_skill_in_level'] = $order_skill_in_level;
                }
            }

            $grading_skill_array[] = $piece_elem;
        }
        $settings_for_level = ([
            "grading_skill" => $grading_skill_array,
            "order_level_show" => $order_level_show,
            "shuffle_questions" => $shuffle_questions,
            "method_grading_level"=>$method_grading_level
        ]);
        $key_level = "settings_level_" . $level_term_id;
        $utec_settings_quiz["$key_level"] = $settings_for_level;
        update_option("utec_settings_quiz",serialize($utec_settings_quiz));
        wp_die();
    }
    public function utec_quiz_set_overall_settings()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به تنظیمات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce')) {
            wp_die("<strong>خطا :</strong>" . "به تنظیمات دسترسی ندارید !");
        }
        $utec_before_quiz_description = urlencode(($_POST['utec_before_quiz_description']));
        $utec_begin_quiz_alert = urlencode(($_POST['utec_begin_quiz_alert']));
        $utec_icon_result_img = sanitize_text_field(($_POST['icon_result_img']));
        $number_of_max_go_quiz_valid = intval(sanitize_text_field(($_POST['number_of_max_go_quiz_valid'])));
        update_option("number_of_max_go_quiz_valid",($number_of_max_go_quiz_valid));
        update_option("utec_before_quiz_description",($utec_before_quiz_description));
        update_option("utec_begin_quiz_alert",($utec_begin_quiz_alert));
        update_option("utec_icon_show_result_list",($utec_icon_result_img));
        wp_die();

    }
}
