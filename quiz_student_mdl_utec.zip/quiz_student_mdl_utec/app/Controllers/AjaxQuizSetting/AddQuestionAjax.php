<?php

namespace Utec\Quiz\Controllers\AjaxQuizSetting;

class AddQuestionAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_add_question_ajax',  array($this, 'utec_quiz_add_question_ajax'));
        add_action('wp_ajax_nopriv_utec_quiz_add_question_ajax',  array($this, 'utec_quiz_add_question_ajax'));

        add_action('wp_ajax_utec_quiz_save_question_ajax',  array($this, 'utec_quiz_save_question_ajax'));
        add_action('wp_ajax_nopriv_utec_quiz_save_question_ajax',  array($this, 'utec_quiz_save_question_ajax'));

        add_action('wp_ajax_utec_quiz_get_order_ques_ajax',  array($this, 'utec_quiz_get_order_ques_ajax'));
        add_action('wp_ajax_nopriv_utec_quiz_get_order_ques_ajax',  array($this, 'utec_quiz_get_order_ques_ajax'));
    }
    public function utec_quiz_add_question_ajax()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $questions_all = get_option('utec_quiz_questions_all') ? unserialize((get_option('utec_quiz_questions_all'))) : [];

        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );

        $product_skills = get_terms($args_query_prod_skill);


        utec_quiz_view('AjaxQuizSetting/AddQuestionView', compact('product_skills', 'questions_all', 'level_term_id'));
        wp_die();
    }
    public function utec_quiz_save_question_ajax()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        $questions_all = get_option('utec_quiz_questions_all') ? unserialize((get_option('utec_quiz_questions_all'))) : [];
      
        $ques_salt = utec_quiz_make_hash();
        $title_ques = (sanitize_text_field($_POST['title_ques']));
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $order_ques = intval(sanitize_text_field($_POST['order_ques']));
        $options_array = (($_POST['options_array']));
        $quiz_new_ques = [];
        $quiz_new_ques['ques_salt'] = $ques_salt;
        $quiz_new_ques['title_ques'] = $title_ques;
        $quiz_new_ques['order_ques'] = $order_ques;
        $quiz_new_ques['level_term_id'] = $level_term_id;
        $quiz_new_ques['skill_term_id'] = $skill_term_id;
        $quiz_new_ques['options_array'] = $options_array;

        $quiz_questions_array = [];
        if ($questions_all) {
            $last_quiz_questions_array = $questions_all;
            $last_quiz_questions_array[] = $quiz_new_ques;
            $quiz_questions_array = $last_quiz_questions_array;
        } else {
            $quiz_questions_array[] = $quiz_new_ques;
        }
        update_option("utec_quiz_questions_all", serialize($quiz_questions_array));


        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_skills = get_terms($args_query_prod_skill);
      
        utec_quiz_view('AjaxQuizSetting/AddQuestionView', compact('product_skills', 'questions_all', 'level_term_id'));
        wp_die();
    }
    public function utec_quiz_get_order_ques_ajax()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $questions_all = get_option('utec_quiz_questions_all') ? unserialize((get_option('utec_quiz_questions_all'))) : [];
        $questions_all_spec = [];
        if (!$questions_all) {
            wp_die(1);
        } else {
            foreach ($questions_all as $ques) {
                if ($ques['level_term_id'] == $level_term_id && $ques['skill_term_id'] == $skill_term_id) {
                    $questions_all_spec[] = $ques;
                }
            }
        }


        if ($questions_all_spec) {
            $bef_questions = $questions_all_spec;
            $max_order = 1;
            $orders_nums = [];
            foreach ($bef_questions as $bques) {
                $orders_nums[] = intval($bques['order_ques']);
            }
            $max_order = max($orders_nums) + 1;
        } else {
            $max_order = 1;
        }

        wp_die($max_order);
    }
}
