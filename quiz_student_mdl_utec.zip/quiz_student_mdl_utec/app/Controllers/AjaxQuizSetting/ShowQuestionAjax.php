<?php

namespace Utec\Quiz\Controllers\AjaxQuizSetting;

class ShowQuestionAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_show_questions_ajax',  array($this, 'utec_quiz_show_questions_ajax'));
        add_action('wp_ajax_nopriv_utec_quiz_show_questions_ajax',  array($this, 'utec_quiz_show_questions_ajax'));

    }
    public function utec_quiz_show_questions_ajax(){
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $questions_all = get_option('utec_quiz_questions_all') ? unserialize((get_option('utec_quiz_questions_all'))) : [];
        $questions_all_spec = [];
        if ($questions_all) {
            foreach ($questions_all as $ques) {
                if ($ques['level_term_id'] == $level_term_id) {
                    $questions_all_spec[] = $ques;
                }
            }
        }
        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_skills = get_terms($args_query_prod_skill);

        utec_quiz_view('AjaxQuizSetting/ShowQuestionView', compact('product_skills', 'questions_all_spec', 'level_term_id'));
        wp_die();
    }
}