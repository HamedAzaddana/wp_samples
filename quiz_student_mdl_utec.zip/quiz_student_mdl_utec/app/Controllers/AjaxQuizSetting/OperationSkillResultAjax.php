<?php
// utec_skill_in_level_results_intervals
namespace Utec\Quiz\Controllers\AjaxQuizSetting;

class OperationSkillResultAjax
{
    public function __construct()
    {
        //add
        add_action('wp_ajax_utec_quiz_set_interval_skill',  array($this, 'utec_quiz_set_interval_skill'));
        add_action('wp_ajax_nopriv_utec_quiz_set_interval_skill',  array($this, 'utec_quiz_set_interval_skill'));

        add_action('wp_ajax_utec_quiz_set_interval_skill_save',  array($this, 'utec_quiz_set_interval_skill_save'));
        add_action('wp_ajax_nopriv_utec_quiz_set_interval_skill_save',  array($this, 'utec_quiz_set_interval_skill_save'));
        //edit & show
        add_action('wp_ajax_utec_quiz_set_interval_skill_show',  array($this, 'utec_quiz_set_interval_skill_show'));
        add_action('wp_ajax_nopriv_utec_quiz_set_interval_skill_show',  array($this, 'utec_quiz_set_interval_skill_show'));

        add_action('wp_ajax_utec_quiz_set_interval_skill_edit',  array($this, 'utec_quiz_set_interval_skill_edit'));
        add_action('wp_ajax_nopriv_utec_quiz_set_interval_skill_edit',  array($this, 'utec_quiz_set_interval_skill_edit'));

        //delete
        add_action('wp_ajax_utec_quiz_set_interval_skill_delete',  array($this, 'utec_quiz_set_interval_skill_delete'));
        add_action('wp_ajax_nopriv_utec_quiz_set_interval_skill_delete',  array($this, 'utec_quiz_set_interval_skill_delete'));
    }
    public function utec_quiz_set_interval_skill_delete()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id']) || !isset($_POST['skill_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $result_skill_salt = (sanitize_text_field($_POST['result_skill_salt']));
        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        if ($quiz_new_skills_rs_already) {
            $quiz_new_skills_rs_already_filtered = [];
            foreach ($quiz_new_skills_rs_already as $item) {
                if ($item['result_skill_salt'] != $result_skill_salt) {
                    $quiz_new_skills_rs_already_filtered[] = $item;
                }
            }
        }
        update_option("utec_skill_in_level_results_intervals", serialize($quiz_new_skills_rs_already_filtered));

        $courses = $this->utec_quiz_get_courses();
        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        $utec_level_results_intervals_skill = [];
        foreach ($quiz_new_skills_rs_already as $item) {
            if (
                $item['level_term_id'] == $level_term_id
                && $item['skill_term_id'] == $skill_term_id
            ) {
                $utec_level_results_intervals_skill[] = $item;
            }
        }
        usort($utec_level_results_intervals_skill, function ($first, $second) {
            return intval($first['int_down']) > intval($second['int_down']);
        });

        utec_quiz_view('AjaxQuizSetting/ShowResultSkillView', compact('courses', 'utec_level_results_intervals_skill', 'level_term_id', 'skill_term_id'));
        wp_die();
    }
    public function utec_quiz_set_interval_skill_edit()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id']) || !isset($_POST['skill_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $result_skill_salt = (sanitize_text_field($_POST['result_skill_salt']));
        $int_down = floatval(sanitize_text_field($_POST['int_down']));
        $int_up = floatval(sanitize_text_field($_POST['int_up']));
        $txt_result_skill_int = (urlencode($_POST['txt_result_skill_int']));
        $product_ids = (($_POST['product_ids']));

        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        if ($quiz_new_skills_rs_already) {
            $i = 0;
            $index_edit = 0;
            foreach ($quiz_new_skills_rs_already as $item) {
                if ($item['result_skill_salt'] == $result_skill_salt) {
                    $index_edit = $i;
                    $new_item = [];
                    $new_item['level_term_id'] = $level_term_id;
                    $new_item['skill_term_id'] = $skill_term_id;
                    $new_item['int_down'] = $int_down;
                    $new_item['int_up'] = $int_up;
                    $new_item['txt_result_skill_int'] = $txt_result_skill_int;
                    $new_item['product_ids'] = $product_ids;
                    $new_item['result_skill_salt'] = $result_skill_salt;
                }
                $i++;
            }
        }
        $quiz_new_skills_rs_already[$index_edit] = $new_item;
        update_option("utec_skill_in_level_results_intervals", serialize($quiz_new_skills_rs_already));
        wp_die();
    }
    public function utec_quiz_set_interval_skill_show()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id']) || !isset($_POST['skill_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));

        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        $utec_level_results_intervals_skill = [];
        foreach ($quiz_new_skills_rs_already as $item) {
            if (
                $item['level_term_id'] == $level_term_id
                && $item['skill_term_id'] == $skill_term_id
            ) {
                $utec_level_results_intervals_skill[] = $item;
            }
        }
        usort($utec_level_results_intervals_skill, function ($first, $second) {
            return intval($first['int_down']) > intval($second['int_down']);
        });
        $courses = $this->utec_quiz_get_courses();
        utec_quiz_view('AjaxQuizSetting/ShowResultSkillView', compact('courses', 'utec_level_results_intervals_skill', 'level_term_id', 'skill_term_id'));
        wp_die();
    }
    public function utec_quiz_set_interval_skill_save()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id']) || !isset($_POST['skill_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }

        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $product_ids = ($_POST['product_ids']);
        $int_down = floatval(sanitize_text_field($_POST['int_down']));
        $int_up = floatval(sanitize_text_field($_POST['int_up']));
        $txt_result_skill_int = (urlencode($_POST['txt_result_skill_int']));
        $result_skill_salt = utec_quiz_make_hash();

        $quiz_new_skill_rs = [];
        $quiz_new_skill_rs['level_term_id'] = $level_term_id;
        $quiz_new_skill_rs['skill_term_id'] = $skill_term_id;
        $quiz_new_skill_rs['int_down'] = $int_down;
        $quiz_new_skill_rs['int_up'] = $int_up;
        $quiz_new_skill_rs['txt_result_skill_int'] = $txt_result_skill_int;
        $quiz_new_skill_rs['product_ids'] = $product_ids;
        $quiz_new_skill_rs['result_skill_salt'] = $result_skill_salt;
        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        $quiz_new_skills_rs_already[] = $quiz_new_skill_rs;
        update_option("utec_skill_in_level_results_intervals", serialize($quiz_new_skills_rs_already));
        $courses = $this->utec_quiz_get_courses();
        utec_quiz_view('AjaxQuizSetting/AddResultSkillView', compact('courses', 'level_term_id', 'skill_term_id'));
        wp_die();
    }
    public function utec_quiz_set_interval_skill()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['level_term_id'])) {
            wp_die("<strong>خطا :</strong>" . "خطای دسترسی رخ داد !");
        }
        $level_term_id = intval(sanitize_text_field($_POST['level_term_id']));
        $skill_term_id = intval(sanitize_text_field($_POST['skill_term_id']));
        $courses = $this->utec_quiz_get_courses();

        utec_quiz_view('AjaxQuizSetting/AddResultSkillView', compact('courses', 'level_term_id', 'skill_term_id'));
        wp_die();
    }
    public function utec_quiz_get_courses()
    {
        $args_prods = array(
            'post_type' => 'product',
            'numberposts' => -1,
            'post_status'    => 'publish'
        );
        $products_all = get_posts($args_prods);
        $products_all_filtered = [];
        foreach ($products_all as $course) {
            $has_ended_this_course = utec_auth_ended_course($course->ID);
            if (!$has_ended_this_course) {
                $products_all_filtered[] = $course;
            }
        }
        return $products_all_filtered;
    }
}
