<?php

namespace Utec\Quiz\Controllers;

class Activate
{
    public function __construct()
    {
        register_activation_hook(utec_quiz_plugin_file,  [$this, 'utec_quiz_activation']);
        register_deactivation_hook(utec_quiz_plugin_file,  [$this, 'utec_quiz_deactivation']);
    }
    public  function activate_now()
    {
        $this->utec_quiz_activation();
    }
    public function utec_quiz_activation()
    {
        $this->make_tables();
        $this->make_pages();
        flush_rewrite_rules();
    }
    public function utec_quiz_deactivation()
    {
        flush_rewrite_rules();
    }
    public function make_tables()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wc_quiz_placement_results';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table_name(
        `id`  BIGINT NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT NOT NULL , 
        `results` LONGTEXT NOT NULL , 
        `date` TIMESTAMP NULL DEFAULT NULL , 
        PRIMARY KEY (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function make_pages()
    {
        // Page Overall

        $page_title = 'آزمون تعیین سطح';
        $page = array(
            'post_title'    => ($page_title),
            'post_content'  => '[utec_quiz_overall]',
            'post_status'   => 'publish',
            "post_name" => "quiz_placement",
            'post_author'   => 0,
            'post_type'     => 'page',
        );
        if (!post_exists($page_title, '', '', '')) {
            wp_insert_post($page, true);
        }

        // Quiz Participate

        $page_title = 'شرکت در آزمون تعیین سطح';
        $page = array(
            'post_title'    => ($page_title),
            'post_content'  => '[utec_quiz_do]',
            'post_status'   => 'publish',
            "post_name" => "quiz_do",
            'post_author'   => 0,
            'post_type'     => 'page',
        );
        if (!post_exists($page_title, '', '', '')) {
            wp_insert_post($page, true);
        }


        // Quiz Result single

        $page_title = 'نتیجه آزمون تعیین سطح';
        $page = array(
            'post_title'    => ($page_title),
            'post_content'  => '[utec_quiz_result]',
            'post_status'   => 'publish',
            "post_name" => "quiz_result",
            'post_author'   => 0,
            'post_type'     => 'page',
        );
        if (!post_exists($page_title, '', '', '')) {
            wp_insert_post($page, true);
        }
    }
}
