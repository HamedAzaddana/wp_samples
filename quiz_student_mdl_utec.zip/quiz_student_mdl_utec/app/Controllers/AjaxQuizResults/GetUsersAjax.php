<?php

namespace Utec\Quiz\Controllers\AjaxQuizResults;

class GetUsersAjax
{
    public function __construct()
    {
        //Show Table
        add_action('wp_ajax_utec_quiz_get_user_results',  array($this, 'utec_quiz_get_user_results'));
        add_action('wp_ajax_nopriv_utec_quiz_get_user_results',  array($this, 'utec_quiz_get_user_results'));
        //Delete Result
        add_action('wp_ajax_utec_quiz_delete_single_rs_quiz',  array($this, 'utec_quiz_delete_single_rs_quiz'));
        add_action('wp_ajax_nopriv_utec_quiz_delete_single_rs_quiz',  array($this, 'utec_quiz_delete_single_rs_quiz'));
    }
    public function utec_quiz_delete_single_rs_quiz()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['IdResult'])) {
            wp_die("<strong>خطا :</strong>" . "به اطلاعات مشتریان دسترسی ندارید !");
        }
        $IdResult = intval(sanitize_text_field($_POST['IdResult']));
        global $wpdb;
        $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
        $query = "SELECT * FROM $tbl_result WHERE `id` = '$IdResult'";

        $get_last_data = $wpdb->get_results($query);
        if (!$get_last_data) {
            wp_die();
        }
        $wpdb->delete($tbl_result, array('id' => $IdResult));
        wp_die();
    }
    public function utec_quiz_get_user_results()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['KeyWord'])) {
            wp_die("<strong>خطا :</strong>" . "به اطلاعات مشتریان دسترسی ندارید !");
        }
        $KeyWord = $_POST['KeyWord'] ? (sanitize_text_field($_POST['KeyWord'])) : "";
        global $wpdb;
        $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
        $quiz_results = $wpdb->get_results("SELECT * FROM `$tbl_result` order by `date` desc");
        $quiz_results_filtered = [];
        if ($KeyWord) {
            foreach ($quiz_results as $qrs) {
                $user_id = intval($qrs->user_id);
                $user = get_user_by('id', $user_id);
                $username = $user->data->user_login;
                $first_name = get_user_meta($user->ID, 'first_name', true);
                $last_name = get_user_meta($user->ID, 'last_name', true);
                if (
                    strpos($username, $KeyWord) !== false
                    || strpos($first_name, $KeyWord) !== false
                    || strpos($last_name, $KeyWord) !== false
                ) {
                    $quiz_results_filtered[] = $qrs;
                }
            }
        } else {
            $quiz_results_filtered = $quiz_results;
        }
        $cnt_results = count($quiz_results_filtered);
        $per_page = 50;
        $links_num = ceil($cnt_results / $per_page);
        $paged_num = isset($_POST['paged_num']) ? intval($_POST['paged_num']) : 1;
        $last_num_paged =  $links_num;
        $quiz_results_filtered = array_slice($quiz_results_filtered, ($paged_num - 1) * $per_page, $per_page);
        utec_quiz_view('AjaxQuizResults/GetUsersView', compact(
            'quiz_results_filtered',
            'last_num_paged',
            'paged_num',
            'links_num',
            'per_page',
            'cnt_results',
            'KeyWord'
        ));
        wp_die();
    }
}
