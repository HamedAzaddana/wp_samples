<?php

namespace Utec\Quiz\Controllers\AjaxQuizResults;

class GetGradesAjax
{
    public function __construct()
    {
        add_action('wp_ajax_utec_quiz_get_user_results_grades',  array($this, 'utec_quiz_get_user_results_grades'));
        add_action('wp_ajax_nopriv_utec_quiz_get_user_results_grades',  array($this, 'utec_quiz_get_user_results_grades'));
    }
    public function utec_quiz_get_user_results_grades()
    {
        if (($_SERVER['REQUEST_METHOD'] !== 'POST')) {
            wp_die("<strong>خطا :</strong>" . "به سوالات دسترسی ندارید !");
        }
        if (!current_user_can('manage_woocommerce') || !isset($_POST['result_id'])) {
            wp_die("<strong>خطا :</strong>" . "به اطلاعات مشتریان دسترسی ندارید !");
        }
        $result_id = intval(sanitize_text_field($_POST['result_id']));
        global $wpdb;
        $tbl_result = $wpdb->prefix . 'wc_quiz_placement_results';
        $quiz_results = $wpdb->get_results("SELECT * FROM `$tbl_result` WHERE `id` = '$result_id'");
       //get settings
        $utec_settings_quiz = get_option('utec_settings_quiz') ? unserialize((get_option('utec_settings_quiz'))) : [];
        $parent_cate_prod_courses = intval(get_option("parent_cate_prod_courses", 0));
        $term_parent = get_term_by('id', $parent_cate_prod_courses, 'product_cat', 'ARRAY_A');

        $args_query_prod_cate = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );
        $args_query_prod_skill = array(
            'taxonomy' => 'skill-category',
            'hide_empty' => false,
        );
        $product_cates_all = get_terms($args_query_prod_cate);
        $product_skills = get_terms($args_query_prod_skill);

        $product_cates = [];

        foreach ($product_cates_all as $cate) {
            if ($cate->parent && $cate->parent == $term_parent['term_id']) {
                $product_cates[] = $cate;
            }
        }
        $utec_level_results_intervals = unserialize(get_option("utec_level_results_intervals", "")) ?
            unserialize(get_option("utec_level_results_intervals", "")) : [];
        $quiz_new_skills_rs_already = unserialize(get_option("utec_skill_in_level_results_intervals", "")) ?
            unserialize(get_option("utec_skill_in_level_results_intervals", "")) : [];
        if ($quiz_results) {
            $quiz_results_row = $quiz_results;
            $qrs = $quiz_results[0];
            $user_id = intval($qrs->user_id);
            $user = get_user_by('id', $user_id);
            $username = $user->data->user_login;
            $first_name = get_user_meta($user->ID, 'first_name', true);
            $last_name = get_user_meta($user->ID, 'last_name', true);
            $full_name = $first_name . " " . $last_name;
            $date = $qrs->date;
            $date_pers = utec_auth_sanitize_to_fa(jdate("Y/m/d", $date));

            $result_array = unserialize(base64_decode($qrs->results));
            utec_quiz_view('AjaxQuizResults/GetGradesView', compact('quiz_results_row',
            'full_name',
            'date_pers',
            'utec_settings_quiz',
            'product_skills',
            'product_cates',
            'utec_level_results_intervals',
            'quiz_new_skills_rs_already',
        ));
        }

        wp_die();
    }
}
