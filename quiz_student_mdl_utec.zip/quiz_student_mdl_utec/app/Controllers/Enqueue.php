<?php

namespace Utec\Quiz\Controllers;

class Enqueue
{

	public function __construct()
	{
		add_action('admin_enqueue_scripts', array($this, 'utec_quiz_admin_enqueue_scripts'));
		add_action('wp_enqueue_scripts', array($this, 'utec_quiz_enqueue_scripts'));
	}



	public function utec_quiz_admin_enqueue_scripts($hook)
	{

		wp_enqueue_script('utec-quiz-admin-js', $this->utec_quiz_plugins_url('assets/js/utec-quiz-admin.js'), array('jquery', 'wp-color-picker'), "1.0.0", true);
		wp_enqueue_script('utec-quiz-admin-repeating-fields', $this->utec_quiz_plugins_url('assets/js/repeatable-fields.js'), array('jquery', 'wp-color-picker'), "1.0.0", true);
		wp_enqueue_script('utec-quiz-admin-select2', $this->utec_quiz_plugins_url('assets/js/select2-quiz.js'), array('jquery', 'wp-color-picker'), "1.0.0", true);

		wp_enqueue_style('utec-quiz-admin', $this->utec_quiz_plugins_url('assets/css/utec-quiz-admin.css'), array(), utec_quiz_version);
		wp_enqueue_style('utec-quiz-admin-select2', $this->utec_quiz_plugins_url('assets/css/select2-quiz.css'), array(), utec_quiz_version);
	}

	public function utec_quiz_enqueue_scripts()
	{
		wp_enqueue_script('utec-quiz-js', $this->utec_quiz_plugins_url('assets/js/utec-quiz.js'), array(), "1.0.0", true);
		wp_enqueue_script('utec-quiz-jq-ui', "https://code.jquery.com/ui/1.12.1/jquery-ui.min.js?ver=1.12.1", array(), "1.12.1", true);
		wp_enqueue_script('utec-quiz-swal', "https://unpkg.com/sweetalert/dist/sweetalert.min.js", array(), "1.0.0", true);
		wp_enqueue_style('utec-quiz-jq-ui', "https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css?ver=1.12.1", array(), "1.12.1");
		wp_enqueue_style('utec-quiz-css', $this->utec_quiz_plugins_url('assets/css/utec-quiz.css'), array(), utec_quiz_version);
	}

	public function utec_quiz_plugins_url($url)
	{
		return plugins_url('quiz_student_mdl_utec/' . $url);
	}
}
