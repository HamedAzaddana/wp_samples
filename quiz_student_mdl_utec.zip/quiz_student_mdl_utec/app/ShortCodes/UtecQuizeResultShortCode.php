<?php

namespace Utec\Quiz\ShortCodes;

class UtecQuizeResultShortCode{
	public function __construct(){
		add_shortcode('utec_quiz_result',array($this,'utec_quiz_show_single_result_shortcode'));
	}
	
	public function utec_quiz_show_single_result_shortcode($atts){
        utec_quiz_view('ShowQuizResultShortCode',compact('atts'));
	}
}