<?php

namespace Utec\Quiz\ShortCodes;

class UtecMyQuizesShortCode{
	public function __construct(){
		add_shortcode('utec_quiz_overall',array($this,'utec_quiz_my_quizes_shortcode'));
	}
	
	public function utec_quiz_my_quizes_shortcode($atts){
        utec_quiz_view('MyQuizesShortCode',compact('atts'));
	}
}