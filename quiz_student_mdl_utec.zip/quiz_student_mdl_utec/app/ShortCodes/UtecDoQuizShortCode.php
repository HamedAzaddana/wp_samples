<?php

namespace Utec\Quiz\ShortCodes;

class UtecDoQuizShortCode{
	public function __construct(){
		add_shortcode('utec_quiz_do',array($this,'utec_quiz_do_quiz_shortcode'));
	}
	
	public function utec_quiz_do_quiz_shortcode($atts){
        utec_quiz_view('GoQuizShortCode',compact('atts'));
	}
}